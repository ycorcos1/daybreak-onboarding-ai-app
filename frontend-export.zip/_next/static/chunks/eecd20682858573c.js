(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,20979,e=>{"use strict";var a=e.i(64467);let r=a.gql`
  mutation CreateChildAndReferral($childInput: ChildInput!) {
    createChildAndReferral(childInput: $childInput) {
      child {
        id
        name
        grade
        schoolName
        district
      }
      referral {
        id
        status
        lastCompletedStep
        nextStep
      }
      errors
    }
  }
`,t=a.gql`
  mutation UpdateReferralStep(
    $referralId: ID!
    $stepName: String!
    $stepData: JSON
  ) {
    updateReferralStep(
      referralId: $referralId
      stepName: $stepName
      stepData: $stepData
    ) {
      referral {
        id
        status
        lastCompletedStep
        lastUpdatedStepAt
        nextStep
      }
      errors
    }
  }
`,n=a.gql`
  mutation UpdateParentInfo($referralId: ID!, $parentInfo: ParentInfoInput!) {
    updateParentInfo(referralId: $referralId, parentInfo: $parentInfo) {
      user {
        id
        name
        email
        phone
        address
        languagePreference
        relationshipToChild
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,s=a.gql`
  mutation UpdateChildInfo($referralId: ID!, $childInput: ChildInput!) {
    updateChildInfo(referralId: $referralId, childInput: $childInput) {
      child {
        id
        name
        dob
        ageBand
        grade
        schoolName
        district
        state
        primaryLanguage
        pronouns
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,i=a.gql`
  mutation UpdateClinicalIntake($referralId: ID!, $intakeInput: ClinicalIntakeInput!) {
    updateClinicalIntake(referralId: $referralId, intakeInput: $intakeInput) {
      intakeResponse {
        id
        responses
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,l=a.gql`
  mutation UpdateSchedulingPreferences(
    $referralId: ID!
    $schedulingInput: SchedulingPreferenceInput!
  ) {
    updateSchedulingPreferences(referralId: $referralId, schedulingInput: $schedulingInput) {
      schedulingPreference {
        id
        timezone
        locationPreference
        frequency
        clinicianPreferences
        windows
        suggestedWindows
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,o=a.gql`
  mutation SubmitReferral($referralId: ID!) {
    submitReferral(referralId: $referralId) {
      referral {
        id
        status
        packetStatus
        submittedAt
      }
      errors
    }
  }
`,d=a.gql`
  mutation UpdateInsuranceDetails($referralId: ID!, $insuranceInput: InsuranceDetailInput!) {
    updateInsuranceDetails(referralId: $referralId, insuranceInput: $insuranceInput) {
      insuranceDetail {
        id
        insuranceStatus
        insurerName
        planName
        memberId
        groupId
        policyholderName
        coveragePhone
        coverageWebsite
        source
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,c=a.gql`
  mutation AcceptConsents($referralId: ID!, $consents: [ConsentInput!]!) {
    acceptConsents(referralId: $referralId, consents: $consents) {
      consentRecords {
        id
        consentType
        acceptedAt
        ipAddress
        userAgent
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`;e.s(["ACCEPT_CONSENTS",0,c,"CREATE_CHILD_AND_REFERRAL",0,r,"SUBMIT_REFERRAL",0,o,"UPDATE_CHILD_INFO",0,s,"UPDATE_CLINICAL_INTAKE",0,i,"UPDATE_INSURANCE_DETAILS",0,d,"UPDATE_PARENT_INFO",0,n,"UPDATE_REFERRAL_STEP",0,t,"UPDATE_SCHEDULING_PREFERENCES",0,l])},45645,e=>{"use strict";var a=e.i(64467);let r=a.gql`
  mutation StartInsuranceUpload(
    $referralId: ID!
    $frontImageS3Key: String
    $backImageS3Key: String
  ) {
    startInsuranceUpload(
      referralId: $referralId
      frontImageS3Key: $frontImageS3Key
      backImageS3Key: $backImageS3Key
    ) {
      insuranceUpload {
        id
        frontImageS3Key
        backImageS3Key
        ocrStatus
        ocrConfidence
        updatedAt
      }
      errors
    }
  }
`,t=a.gql`
  mutation TriggerInsuranceOcr($referralId: ID!) {
    triggerInsuranceOcr(referralId: $referralId) {
      insuranceUpload {
        id
        ocrStatus
        ocrConfidence
        updatedAt
      }
      errors
    }
  }
`,n=a.gql`
  mutation RecalculateCostEstimate($referralId: ID!) {
    recalculateCostEstimate(referralId: $referralId) {
      costEstimate {
        id
        category
        ruleKey
        explanationText
        updatedAt
      }
      errors
    }
  }
`;e.s(["RECALCULATE_COST_ESTIMATE",0,n,"START_INSURANCE_UPLOAD",0,r,"TRIGGER_INSURANCE_OCR",0,t])},42008,(e,a,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0});var t={VALID_LOADERS:function(){return s},imageConfigDefault:function(){return i}};for(var n in t)Object.defineProperty(r,n,{enumerable:!0,get:t[n]});let s=["default","imgix","cloudinary","akamai","custom"],i={deviceSizes:[640,750,828,1080,1200,1920,2048,3840],imageSizes:[32,48,64,96,128,256,384],path:"/_next/image",loader:"default",loaderFile:"",domains:[],disableStaticImages:!1,minimumCacheTTL:14400,formats:["image/webp"],maximumRedirects:3,dangerouslyAllowLocalIP:!1,dangerouslyAllowSVG:!1,contentSecurityPolicy:"script-src 'none'; frame-src 'none'; sandbox;",contentDispositionType:"attachment",localPatterns:void 0,remotePatterns:[],qualities:[75],unoptimized:!1}},78361,(e,a,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"ImageConfigContext",{enumerable:!0,get:function(){return s}});let t=e.r(1646)._(e.r(73658)),n=e.r(42008),s=t.default.createContext(n.imageConfigDefault)},22890,e=>{"use strict";var a=e.i(41526),r=e.i(22366),t=e.i(9793),n=e.i(39491),s=e.i(73658),i=e.i(83724),l=e.i(53949),o=e.i(93962),d=e.i(50107);let c={no_cost:"You may have little or no out-of-pocket cost",copay:"You may have a copay for sessions",tbd:"We'll confirm your costs before your first session",unknown:"We're still reviewing your information"},u=function({costEstimate:e,loading:t,inputsHint:n}){let s=c[e?.category??"unknown"]||c.unknown,i=e?.explanationText||"We’ll confirm your costs once we review your information.";return(0,a.jsxs)(d.default,{padding:"24px",className:"cost-card",children:[(0,a.jsxs)("div",{className:"jsx-a652ea28e87ae024 header",children:[(0,a.jsx)("p",{className:"jsx-a652ea28e87ae024 eyebrow",children:"Cost estimate"}),n?(0,a.jsx)("p",{className:"jsx-a652ea28e87ae024 hint",children:n}):null]}),(0,a.jsx)("h2",{className:"jsx-a652ea28e87ae024 headline",children:t?"Calculating your estimate…":s}),(0,a.jsx)("p",{className:"jsx-a652ea28e87ae024 body",children:i}),(0,a.jsx)("div",{role:"note",className:"jsx-a652ea28e87ae024 disclaimer",children:"This estimate is not a guarantee of coverage. Final determination will be made by Daybreak and your insurance provider."}),(0,a.jsx)(r.default,{id:"a652ea28e87ae024",children:".cost-card.jsx-a652ea28e87ae024{background:#fffaf6}.header.jsx-a652ea28e87ae024{flex-wrap:wrap;justify-content:space-between;align-items:baseline;gap:12px;display:flex}.eyebrow.jsx-a652ea28e87ae024{color:var(--color-primary-teal);margin:0;font-weight:700}.hint.jsx-a652ea28e87ae024{color:var(--color-muted);margin:0;font-weight:600}.headline.jsx-a652ea28e87ae024{color:var(--color-deep-aqua);margin:8px 0}.body.jsx-a652ea28e87ae024{color:#1f2a38;margin:0 0 12px;font-size:16px;line-height:1.6}.disclaimer.jsx-a652ea28e87ae024{border:1px solid var(--color-border);color:var(--color-muted);background:#fff;border-radius:12px;padding:12px;font-weight:600}"})]})};var p=e.i(56421),f=e.i(76245),m=e.i(45645),I=e.i(20979);function g(){let e=(0,n.useRouter)(),{id:d}=e.query,c=(0,s.useMemo)(()=>d||"",[d]),{referral:g,loading:h,error:x,refetch:S}=(0,p.default)(c),[b]=(0,t.useMutation)(m.RECALCULATE_COST_ESTIMATE),[y]=(0,t.useMutation)(I.UPDATE_REFERRAL_STEP);(0,s.useEffect)(()=>{!c||g?.costEstimate||b({variables:{referralId:c}}).then(()=>S())},[b,S,g?.costEstimate,c]);let j=async()=>{await y({variables:{referralId:c,stepName:"cost",stepData:{completed:!0}}});let a=(0,f.getNextStep)("cost");e.push(`/parent/referrals/${c}/onboarding/${a}`)};if(h)return(0,a.jsx)(i.default,{requireRole:"parent",children:(0,a.jsx)("div",{style:{padding:"48px 24px",textAlign:"center"},children:"Loading cost estimate…"})});if(x||!g)return(0,a.jsx)(i.default,{requireRole:"parent",children:(0,a.jsxs)("div",{style:{padding:"48px 24px",textAlign:"center"},children:[(0,a.jsx)("p",{children:"Unable to load this referral."}),(0,a.jsx)(o.default,{onClick:()=>e.push("/parent/dashboard"),children:"Back to dashboard"})]})});let C=g.costEstimate??null,A=`Based on your district (${g.child.district}) and insurance status (${g.insuranceDetail?.insuranceStatus||"unknown"})`,E=f.ONBOARDING_STEPS.indexOf("cost")+1,$=f.ONBOARDING_STEPS.length;return(0,a.jsx)(i.default,{requireRole:"parent",children:(0,a.jsxs)(l.default,{referralId:g.id,currentStep:"cost",onStepSelect:a=>void e.push(`/parent/referrals/${g.id}/onboarding/${a}`),children:[(0,a.jsx)("div",{className:"jsx-280fba5e91f047d8 step-header",children:(0,a.jsxs)("div",{className:"jsx-280fba5e91f047d8",children:[(0,a.jsxs)("p",{className:"jsx-280fba5e91f047d8 eyebrow",children:["Step ",E," of ",$]}),(0,a.jsx)("h2",{className:"jsx-280fba5e91f047d8",children:"Understand your potential costs"}),(0,a.jsx)("p",{className:"jsx-280fba5e91f047d8 muted",children:"This estimate is informational and may change after we review your details. We’ll confirm before any session."})]})}),(0,a.jsx)(u,{costEstimate:C,loading:!C,inputsHint:A}),(0,a.jsxs)("div",{className:"jsx-280fba5e91f047d8 nav-actions",children:[(0,a.jsx)(o.default,{variant:"ghost",onClick:()=>{let a;a=(0,f.getPreviousStep)("cost"),e.push(`/parent/referrals/${c}/onboarding/${a}`)},children:"Back"}),(0,a.jsx)(o.default,{onClick:()=>void j(),children:"Continue"})]}),(0,a.jsx)(r.default,{id:"280fba5e91f047d8",children:".step-header.jsx-280fba5e91f047d8{flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;margin-bottom:12px;display:flex}.eyebrow.jsx-280fba5e91f047d8{color:var(--color-primary-teal);margin:0;font-weight:700}h2.jsx-280fba5e91f047d8{color:var(--color-deep-aqua);margin:4px 0}.muted.jsx-280fba5e91f047d8{color:var(--color-muted);max-width:720px;margin:0}.nav-actions.jsx-280fba5e91f047d8{flex-wrap:wrap;justify-content:space-between;gap:10px;display:flex}@media (width<=768px){.nav-actions.jsx-280fba5e91f047d8{flex-direction:column}}"})]})})}e.s(["default",()=>g],22890)},67462,(e,a,r)=>{let t="/parent/referrals/[id]/onboarding/cost";(window.__NEXT_P=window.__NEXT_P||[]).push([t,()=>e.r(22890)]),a.hot&&a.hot.dispose(function(){window.__NEXT_P.push([t])})},88853,e=>{e.v(a=>Promise.all(["static/chunks/ca6b9ab451866ae2.js"].map(a=>e.l(a))).then(()=>a(33811)))},91751,e=>{e.v(a=>Promise.all(["static/chunks/b0bbf6aa740a2457.js"].map(a=>e.l(a))).then(()=>a(23428)))}]);