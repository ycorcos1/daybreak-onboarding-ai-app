(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,20979,e=>{"use strict";var r=e.i(64467);let a=r.gql`
  mutation CreateChildAndReferral($childInput: ChildInput!) {
    createChildAndReferral(childInput: $childInput) {
      child {
        id
        name
        grade
        schoolName
        district
      }
      referral {
        id
        status
        lastCompletedStep
        nextStep
      }
      errors
    }
  }
`,t=r.gql`
  mutation UpdateReferralStep(
    $referralId: ID!
    $stepName: String!
    $stepData: JSON
  ) {
    updateReferralStep(
      referralId: $referralId
      stepName: $stepName
      stepData: $stepData
    ) {
      referral {
        id
        status
        lastCompletedStep
        lastUpdatedStepAt
        nextStep
      }
      errors
    }
  }
`,l=r.gql`
  mutation UpdateParentInfo($referralId: ID!, $parentInfo: ParentInfoInput!) {
    updateParentInfo(referralId: $referralId, parentInfo: $parentInfo) {
      user {
        id
        name
        email
        phone
        address
        languagePreference
        relationshipToChild
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,d=r.gql`
  mutation UpdateChildInfo($referralId: ID!, $childInput: ChildInput!) {
    updateChildInfo(referralId: $referralId, childInput: $childInput) {
      child {
        id
        name
        dob
        ageBand
        grade
        schoolName
        district
        state
        primaryLanguage
        pronouns
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,i=r.gql`
  mutation UpdateClinicalIntake($referralId: ID!, $intakeInput: ClinicalIntakeInput!) {
    updateClinicalIntake(referralId: $referralId, intakeInput: $intakeInput) {
      intakeResponse {
        id
        responses
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,n=r.gql`
  mutation UpdateSchedulingPreferences(
    $referralId: ID!
    $schedulingInput: SchedulingPreferenceInput!
  ) {
    updateSchedulingPreferences(referralId: $referralId, schedulingInput: $schedulingInput) {
      schedulingPreference {
        id
        timezone
        locationPreference
        frequency
        clinicianPreferences
        windows
        suggestedWindows
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,s=r.gql`
  mutation SubmitReferral($referralId: ID!) {
    submitReferral(referralId: $referralId) {
      referral {
        id
        status
        packetStatus
        submittedAt
      }
      errors
    }
  }
`,o=r.gql`
  mutation UpdateInsuranceDetails($referralId: ID!, $insuranceInput: InsuranceDetailInput!) {
    updateInsuranceDetails(referralId: $referralId, insuranceInput: $insuranceInput) {
      insuranceDetail {
        id
        insuranceStatus
        insurerName
        planName
        memberId
        groupId
        policyholderName
        coveragePhone
        coverageWebsite
        source
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,c=r.gql`
  mutation AcceptConsents($referralId: ID!, $consents: [ConsentInput!]!) {
    acceptConsents(referralId: $referralId, consents: $consents) {
      consentRecords {
        id
        consentType
        acceptedAt
        ipAddress
        userAgent
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`;e.s(["ACCEPT_CONSENTS",0,c,"CREATE_CHILD_AND_REFERRAL",0,a,"SUBMIT_REFERRAL",0,s,"UPDATE_CHILD_INFO",0,d,"UPDATE_CLINICAL_INTAKE",0,i,"UPDATE_INSURANCE_DETAILS",0,o,"UPDATE_PARENT_INFO",0,l,"UPDATE_REFERRAL_STEP",0,t,"UPDATE_SCHEDULING_PREFERENCES",0,n])},3308,e=>{"use strict";var r=e.i(41526),a=e.i(22366);e.s(["default",0,function({message:e}){return e?(0,r.jsxs)("div",{role:"alert","aria-live":"assertive",className:"jsx-3a06f6b875d5b277 validation-error",children:[e,(0,r.jsx)(a.default,{id:"3a06f6b875d5b277",children:".validation-error.jsx-3a06f6b875d5b277{color:var(--color-accent-red);border:1px solid var(--color-accent-red);background:#ff4b4b1a;border-radius:12px;padding:10px 12px;font-weight:600}"})]}):null}])},91332,e=>{"use strict";var r=e.i(41526),a=e.i(22366);e.s(["default",0,function({id:e,label:t,options:l,helperText:d,error:i,required:n,...s}){let o=d?`${e}-helper`:void 0,c=i?`${e}-error`:void 0,u=l.some(e=>""===e.value);return(0,r.jsxs)("div",{className:"jsx-734334db1d082c81 select-field",children:[(0,r.jsxs)("label",{htmlFor:e,className:"jsx-734334db1d082c81 db-input-label",children:[t,n?(0,r.jsx)("span",{className:"jsx-734334db1d082c81 db-required",children:"*"}):null]}),(0,r.jsxs)("select",{id:e,"aria-invalid":!!i,"aria-describedby":i?c:o,required:n,...s,className:"jsx-734334db1d082c81 "+(s&&null!=s.className&&s.className||`db-select ${i?"db-input-error":""}`),children:[void 0!==s.defaultValue||u?null:(0,r.jsx)("option",{value:"",className:"jsx-734334db1d082c81",children:"Select..."}),l.map(e=>(0,r.jsx)("option",{value:e.value,className:"jsx-734334db1d082c81",children:e.label},e.value))]}),d&&!i?(0,r.jsx)("p",{id:o,className:"jsx-734334db1d082c81 db-input-helper",children:d}):null,i?(0,r.jsx)("p",{id:c,className:"jsx-734334db1d082c81 db-input-error-text",children:i}):null,(0,r.jsx)(a.default,{id:"734334db1d082c81",children:".db-input-label.jsx-734334db1d082c81{color:var(--color-deep-aqua);margin-bottom:6px;font-weight:600;display:block}.db-required.jsx-734334db1d082c81{color:var(--color-accent-red);margin-left:4px}.db-select.jsx-734334db1d082c81{border:1px solid var(--color-border);width:100%;height:46px;color:var(--color-text);background:#fff;border-radius:10px;padding:0 12px;font-size:15px;transition:border-color .12s,box-shadow .12s}.db-select.jsx-734334db1d082c81:focus{border-color:var(--color-primary-teal);outline:none;box-shadow:0 0 0 3px #0096a833}.db-input-error.jsx-734334db1d082c81{border-color:var(--color-accent-red)}.db-input-helper.jsx-734334db1d082c81{color:var(--color-muted);margin-top:6px;font-size:13px}.db-input-error-text.jsx-734334db1d082c81{color:var(--color-accent-red);margin-top:6px;font-size:13px}"})]})}])},97679,e=>{"use strict";var r=e.i(41526),a=e.i(22366);function t({label:e,id:t,helperText:l,error:d,required:i,...n}){let s=l?`${t}-helper`:void 0,o=d?`${t}-error`:void 0;return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsxs)("label",{htmlFor:t,className:"jsx-59fec5f1f0edea5 db-input-label",children:[e,i?(0,r.jsx)("span",{className:"jsx-59fec5f1f0edea5 db-required",children:"*"}):null]}),(0,r.jsx)("input",{id:t,"aria-invalid":!!d,"aria-describedby":d?o:s,required:i,...n,className:"jsx-59fec5f1f0edea5 "+(n&&null!=n.className&&n.className||`db-input ${d?"db-input-error":""}`)}),l&&!d?(0,r.jsx)("p",{id:s,className:"jsx-59fec5f1f0edea5 db-input-helper",children:l}):null,d?(0,r.jsx)("p",{id:o,className:"jsx-59fec5f1f0edea5 db-input-error-text",children:d}):null,(0,r.jsx)(a.default,{id:"59fec5f1f0edea5",children:".db-input-label.jsx-59fec5f1f0edea5{color:var(--color-deep-aqua);margin-bottom:4px;font-weight:600;display:block}.db-required.jsx-59fec5f1f0edea5{color:var(--color-accent-red);margin-left:4px}.db-input.jsx-59fec5f1f0edea5{border:1px solid var(--color-border);width:100%;height:46px;color:var(--color-text);background:#fff;border-radius:10px;padding:0 58px 0 14px;font-size:15px;transition:border-color .12s,box-shadow .12s}.db-input.jsx-59fec5f1f0edea5:focus{border-color:var(--color-primary-teal);outline:none;box-shadow:0 0 0 3px #0096a833}.db-input.jsx-59fec5f1f0edea5::placeholder{color:var(--color-muted)}.db-input-error.jsx-59fec5f1f0edea5{border-color:var(--color-accent-red)}.db-input-helper.jsx-59fec5f1f0edea5{color:var(--color-muted);margin-top:6px;font-size:13px}.db-input-error-text.jsx-59fec5f1f0edea5{color:var(--color-accent-red);margin-top:6px;font-size:13px}"})]})}e.s(["TextInput",()=>t,"default",0,t])},3086,e=>{"use strict";var r=e.i(41526),a=e.i(97679);e.s(["default",0,function(e){return(0,r.jsx)(a.default,{...e})}])},42008,(e,r,a)=>{"use strict";Object.defineProperty(a,"__esModule",{value:!0});var t={VALID_LOADERS:function(){return d},imageConfigDefault:function(){return i}};for(var l in t)Object.defineProperty(a,l,{enumerable:!0,get:t[l]});let d=["default","imgix","cloudinary","akamai","custom"],i={deviceSizes:[640,750,828,1080,1200,1920,2048,3840],imageSizes:[32,48,64,96,128,256,384],path:"/_next/image",loader:"default",loaderFile:"",domains:[],disableStaticImages:!1,minimumCacheTTL:14400,formats:["image/webp"],maximumRedirects:3,dangerouslyAllowLocalIP:!1,dangerouslyAllowSVG:!1,contentSecurityPolicy:"script-src 'none'; frame-src 'none'; sandbox;",contentDispositionType:"attachment",localPatterns:void 0,remotePatterns:[],qualities:[75],unoptimized:!1}},78361,(e,r,a)=>{"use strict";Object.defineProperty(a,"__esModule",{value:!0}),Object.defineProperty(a,"ImageConfigContext",{enumerable:!0,get:function(){return d}});let t=e.r(1646)._(e.r(73658)),l=e.r(42008),d=t.default.createContext(l.imageConfigDefault)},59938,e=>{"use strict";var r=e.i(41526),a=e.i(22366),t=e.i(9793),l=e.i(39491),d=e.i(73658),i=e.i(27941),n=e.i(83724),s=e.i(53949),o=e.i(93962),c=e.i(56421),u=e.i(76245),p=e.i(20979),f=e.i(3086),b=e.i(91332),m=e.i(3308);let h=["Pre-K","K","1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","Not enrolled","Graduated"].map(e=>({value:e,label:e})),x=["5-7","8-10","11-13","14-17","18+"].map(e=>({value:e,label:e})),g=["","AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA","KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT","VA","WA","WV","WI","WY"].map(e=>({value:e,label:e||"Select state"}));function j(){let e=(0,l.useRouter)(),{id:j}=e.query,I=(0,d.useMemo)(()=>j||"",[j]),{referral:v,loading:N,error:S}=(0,c.default)(I),[C]=(0,t.useMutation)(p.UPDATE_CHILD_INFO),[A,y]=(0,d.useState)(""),[D,$]=(0,d.useState)("idle"),P=(0,d.useRef)(!1),{register:w,handleSubmit:T,reset:E,watch:q,setError:_,formState:{errors:R,isDirty:U}}=(0,i.useForm)({mode:"onBlur",defaultValues:{name:"",dob:"",ageBand:"",grade:"",schoolName:"",district:"",state:"",primaryLanguage:"",pronouns:"",howHeard:""}});(0,d.useEffect)(()=>{v?.child&&(E({name:v.child.name??"",dob:v.child.dob??"",ageBand:v.child.ageBand??"",grade:v.child.grade??"",schoolName:v.child.schoolName??"",district:v.child.district??"",state:v.child.state??"",primaryLanguage:v.child.primaryLanguage??"",pronouns:v.child.pronouns??"",howHeard:""}),P.current=!0)},[v,E]);let L=e=>{if(!e.dob&&!e.ageBand)return _("dob",{message:"Enter a date of birth or select an age band"}),_("ageBand",{message:"Enter a date of birth or select an age band"}),!1;if(e.dob){let r=Math.abs(new Date(Date.now()-new Date(e.dob).getTime()).getUTCFullYear()-1970);if(r<3||r>19)return _("dob",{message:"Please enter a valid age between 3 and 19"}),!1}return!0},O=async e=>{if(I){if(!L(e))return void $("error");y(""),$("saving");try{let{data:r}=await C({variables:{referralId:I,childInput:{name:e.name,dob:e.dob||null,ageBand:e.ageBand||null,grade:e.grade,schoolName:e.schoolName,district:e.district,state:e.state,primaryLanguage:e.primaryLanguage,pronouns:e.pronouns}}}),a=r?.updateChildInfo?.errors;if(a?.length){y(a[0]),$("error");return}$("saved"),setTimeout(()=>$("idle"),1200)}catch{y("Unable to save child info right now. Please try again."),$("error")}}},k=q();(0,d.useEffect)(()=>{if(!P.current||!I||!U)return;let e=setTimeout(()=>{O(k)},700);return()=>clearTimeout(e)},[I,JSON.stringify(k),U]);let B=async r=>{if(!L(r))return;await O(r);let a=(0,u.getNextStep)("child-info");e.push(`/parent/referrals/${I}/onboarding/${a}`)};return N?(0,r.jsx)(n.default,{requireRole:"parent",children:(0,r.jsx)("div",{style:{padding:"48px 24px",textAlign:"center"},children:"Loading referral…"})}):S||!v?(0,r.jsx)(n.default,{requireRole:"parent",children:(0,r.jsxs)("div",{style:{padding:"48px 24px",textAlign:"center"},children:[(0,r.jsx)("p",{children:"Unable to load this referral."}),(0,r.jsx)(o.default,{onClick:()=>e.push("/parent/dashboard"),children:"Back to dashboard"})]})}):(0,r.jsx)(n.default,{requireRole:"parent",children:(0,r.jsxs)(s.default,{referralId:v.id,currentStep:"child-info",onStepSelect:r=>"child-info"===r?void 0:void e.push(`/parent/referrals/${v.id}/onboarding/${r}`),children:[(0,r.jsxs)("div",{className:"jsx-b1f5b452cc898663 step-header",children:[(0,r.jsxs)("div",{className:"jsx-b1f5b452cc898663",children:[(0,r.jsx)("p",{className:"jsx-b1f5b452cc898663 eyebrow",children:"Step 2 of 9"}),(0,r.jsx)("h2",{className:"jsx-b1f5b452cc898663",children:"About your child"}),(0,r.jsx)("p",{className:"jsx-b1f5b452cc898663 muted",children:"This helps us tailor support to your child’s context."})]}),(0,r.jsxs)("div",{"aria-live":"polite",className:"jsx-b1f5b452cc898663 save-indicator",children:["saving"===D&&"Saving…","saved"===D&&"Saved","error"===D&&"Save error"]})]}),A?(0,r.jsx)(m.default,{message:A}):null,(0,r.jsxs)("form",{onSubmit:T(B),noValidate:!0,"aria-label":"Child information form",className:"jsx-b1f5b452cc898663 form-grid",children:[(0,r.jsx)(f.default,{id:"name",label:"Child name",required:!0,error:R.name?.message,...w("name",{required:"Child name is required"})}),(0,r.jsx)(f.default,{id:"dob",label:"Date of birth",type:"date",error:R.dob?.message,...w("dob")}),(0,r.jsx)(b.default,{id:"ageBand",label:"Age band (if no DOB)",options:x,error:R.ageBand?.message,...w("ageBand")}),(0,r.jsx)(b.default,{id:"grade",label:"Grade",required:!0,options:h,error:R.grade?.message,...w("grade",{required:"Grade is required"})}),(0,r.jsx)(f.default,{id:"schoolName",label:"School name",required:!0,helperText:"If homeschooled or not enrolled, note that here.",error:R.schoolName?.message,...w("schoolName",{required:"School name is required"})}),(0,r.jsx)(f.default,{id:"district",label:"District",required:!0,error:R.district?.message,...w("district",{required:"District is required"})}),(0,r.jsx)(b.default,{id:"state",label:"State",options:g,error:R.state?.message,...w("state")}),(0,r.jsx)(b.default,{id:"primaryLanguage",label:"Primary language (optional)",options:[{value:"",label:"Select..."},{value:"English",label:"English"},{value:"Spanish",label:"Spanish"},{value:"Other",label:"Other"}],...w("primaryLanguage")}),(0,r.jsx)(f.default,{id:"pronouns",label:"Pronouns (optional)",...w("pronouns")}),(0,r.jsx)(b.default,{id:"howHeard",label:"How did you hear about Daybreak? (optional)",options:[{value:"",label:"Select..."},{value:"School",label:"School"},{value:"Friend",label:"Friend"},{value:"Online search",label:"Online search"},{value:"Other",label:"Other"}],...w("howHeard")}),(0,r.jsxs)("div",{className:"jsx-b1f5b452cc898663 actions",children:[(0,r.jsx)(o.default,{type:"button",variant:"ghost",onClick:()=>{let r=(0,u.getPreviousStep)("child-info");e.push(`/parent/referrals/${I}/onboarding/${r}`)},children:"Back"}),(0,r.jsx)(o.default,{type:"submit",children:"Save & Continue"})]})]}),(0,r.jsx)(a.default,{id:"b1f5b452cc898663",children:".step-header.jsx-b1f5b452cc898663{flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;margin-bottom:12px;display:flex}.eyebrow.jsx-b1f5b452cc898663{color:var(--color-primary-teal);margin:0;font-weight:700}h2.jsx-b1f5b452cc898663{color:var(--color-deep-aqua);margin:4px 0}.muted.jsx-b1f5b452cc898663{color:var(--color-muted);margin:0}.save-indicator.jsx-b1f5b452cc898663{color:var(--color-muted);font-weight:600}.form-grid.jsx-b1f5b452cc898663{grid-template-columns:1fr;row-gap:10px;margin-top:8px;display:grid}.form-grid.jsx-b1f5b452cc898663 .db-input-label{margin-bottom:4px}.form-grid.jsx-b1f5b452cc898663 .db-select,.form-grid.jsx-b1f5b452cc898663 input[type=date].db-input{background-position:right 12px center;height:46px;padding:0 14px;font-size:15px}.form-grid.jsx-b1f5b452cc898663 .db-select{padding-right:36px}.actions.jsx-b1f5b452cc898663{grid-column:1/-1;justify-content:flex-end;gap:12px;margin-top:8px;display:flex}"})]})})}e.s(["default",()=>j])},79105,(e,r,a)=>{let t="/parent/referrals/[id]/onboarding/child-info";(window.__NEXT_P=window.__NEXT_P||[]).push([t,()=>e.r(59938)]),r.hot&&r.hot.dispose(function(){window.__NEXT_P.push([t])})},88853,e=>{e.v(r=>Promise.all(["static/chunks/ca6b9ab451866ae2.js"].map(r=>e.l(r))).then(()=>r(33811)))},91751,e=>{e.v(r=>Promise.all(["static/chunks/b0bbf6aa740a2457.js"].map(r=>e.l(r))).then(()=>r(23428)))}]);