(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,20979,e=>{"use strict";var a=e.i(64467);let r=a.gql`
  mutation CreateChildAndReferral($childInput: ChildInput!) {
    createChildAndReferral(childInput: $childInput) {
      child {
        id
        name
        grade
        schoolName
        district
      }
      referral {
        id
        status
        lastCompletedStep
        nextStep
      }
      errors
    }
  }
`,s=a.gql`
  mutation UpdateReferralStep(
    $referralId: ID!
    $stepName: String!
    $stepData: JSON
  ) {
    updateReferralStep(
      referralId: $referralId
      stepName: $stepName
      stepData: $stepData
    ) {
      referral {
        id
        status
        lastCompletedStep
        lastUpdatedStepAt
        nextStep
      }
      errors
    }
  }
`,t=a.gql`
  mutation UpdateParentInfo($referralId: ID!, $parentInfo: ParentInfoInput!) {
    updateParentInfo(referralId: $referralId, parentInfo: $parentInfo) {
      user {
        id
        name
        email
        phone
        address
        languagePreference
        relationshipToChild
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,n=a.gql`
  mutation UpdateChildInfo($referralId: ID!, $childInput: ChildInput!) {
    updateChildInfo(referralId: $referralId, childInput: $childInput) {
      child {
        id
        name
        dob
        ageBand
        grade
        schoolName
        district
        state
        primaryLanguage
        pronouns
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,l=a.gql`
  mutation UpdateClinicalIntake($referralId: ID!, $intakeInput: ClinicalIntakeInput!) {
    updateClinicalIntake(referralId: $referralId, intakeInput: $intakeInput) {
      intakeResponse {
        id
        responses
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,i=a.gql`
  mutation UpdateSchedulingPreferences(
    $referralId: ID!
    $schedulingInput: SchedulingPreferenceInput!
  ) {
    updateSchedulingPreferences(referralId: $referralId, schedulingInput: $schedulingInput) {
      schedulingPreference {
        id
        timezone
        locationPreference
        frequency
        clinicianPreferences
        windows
        suggestedWindows
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,d=a.gql`
  mutation SubmitReferral($referralId: ID!) {
    submitReferral(referralId: $referralId) {
      referral {
        id
        status
        packetStatus
        submittedAt
      }
      errors
    }
  }
`,c=a.gql`
  mutation UpdateInsuranceDetails($referralId: ID!, $insuranceInput: InsuranceDetailInput!) {
    updateInsuranceDetails(referralId: $referralId, insuranceInput: $insuranceInput) {
      insuranceDetail {
        id
        insuranceStatus
        insurerName
        planName
        memberId
        groupId
        policyholderName
        coveragePhone
        coverageWebsite
        source
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,o=a.gql`
  mutation AcceptConsents($referralId: ID!, $consents: [ConsentInput!]!) {
    acceptConsents(referralId: $referralId, consents: $consents) {
      consentRecords {
        id
        consentType
        acceptedAt
        ipAddress
        userAgent
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`;e.s(["ACCEPT_CONSENTS",0,o,"CREATE_CHILD_AND_REFERRAL",0,r,"SUBMIT_REFERRAL",0,d,"UPDATE_CHILD_INFO",0,n,"UPDATE_CLINICAL_INTAKE",0,l,"UPDATE_INSURANCE_DETAILS",0,c,"UPDATE_PARENT_INFO",0,t,"UPDATE_REFERRAL_STEP",0,s,"UPDATE_SCHEDULING_PREFERENCES",0,i])},3308,e=>{"use strict";var a=e.i(41526),r=e.i(22366);e.s(["default",0,function({message:e}){return e?(0,a.jsxs)("div",{role:"alert","aria-live":"assertive",className:"jsx-3a06f6b875d5b277 validation-error",children:[e,(0,a.jsx)(r.default,{id:"3a06f6b875d5b277",children:".validation-error.jsx-3a06f6b875d5b277{color:var(--color-accent-red);border:1px solid var(--color-accent-red);background:#ff4b4b1a;border-radius:12px;padding:10px 12px;font-weight:600}"})]}):null}])},61502,e=>{"use strict";var a=e.i(41526),r=e.i(22366),s=e.i(93962),t=e.i(50107);let n={terms_of_use:"Terms of Use",privacy_policy:"Privacy Policy",non_emergency_acknowledgment:"Not an emergency service",telehealth_consent:"Telehealth consent",guardian_authorization:"Legal guardian authorization"},l=Object.keys(n);function i({referral:e,missingSections:s=[],onEditStep:t,showEdit:i=!0}){var f;let m=new Set(s),x=e.intakeResponse?.responses||{},h=e.aiScreenerSession?.summaryJsonb||null,j=e.schedulingPreference,g=j?.windows||[],v=j?.suggestedWindows||[],y=e.consentRecords||[],N=y.map(e=>(e.consentType||"").toLowerCase()),I=l.every(e=>N.includes(e));return(0,a.jsxs)("div",{className:"jsx-242efb28197e35b3 review-summary",children:[(0,a.jsx)(d,{title:"Parent information",missing:m.has("Parent info"),onEdit:()=>t("parent-info"),showEdit:i,children:(0,a.jsxs)(c,{children:[(0,a.jsx)(o,{label:"Name",value:e.user?.name}),(0,a.jsx)(o,{label:"Relationship",value:e.user?.relationshipToChild}),(0,a.jsx)(o,{label:"Email",value:e.user?.email}),(0,a.jsx)(o,{label:"Phone",value:e.user?.phone}),(0,a.jsx)(o,{label:"Address",value:e.user?.address}),(0,a.jsx)(o,{label:"Language preference",value:e.user?.languagePreference})]})}),(0,a.jsx)(d,{title:"Child information",missing:m.has("Child info"),onEdit:()=>t("child-info"),showEdit:i,children:(0,a.jsxs)(c,{children:[(0,a.jsx)(o,{label:"Name",value:e.child?.name}),(0,a.jsx)(o,{label:"DOB / Age band",value:e.child?.dob||e.child?.ageBand}),(0,a.jsx)(o,{label:"Grade",value:e.child?.grade}),(0,a.jsx)(o,{label:"School",value:e.child?.schoolName}),(0,a.jsx)(o,{label:"District",value:e.child?.district}),(0,a.jsx)(o,{label:"State",value:e.child?.state}),(0,a.jsx)(o,{label:"Pronouns",value:e.child?.pronouns}),(0,a.jsx)(o,{label:"Primary language",value:e.child?.primaryLanguage})]})}),(0,a.jsx)(d,{title:"AI screener summary",missing:m.has("Clinical intake or screener"),onEdit:()=>t("screener"),showEdit:i,children:h?(0,a.jsx)("ul",{className:"jsx-242efb28197e35b3 plain-list",children:Object.entries(h).map(([e,r])=>(0,a.jsxs)("li",{className:"jsx-242efb28197e35b3",children:[(0,a.jsxs)("strong",{className:"jsx-242efb28197e35b3",children:[b(e),":"]})," ",u(r)]},e))}):(0,a.jsx)("p",{className:"jsx-242efb28197e35b3 muted",children:"No screener summary yet."})}),(0,a.jsx)(d,{title:"Clinical intake",missing:m.has("Clinical intake or screener"),onEdit:()=>t("intake"),showEdit:i,children:Object.keys(x).length?(0,a.jsxs)("ul",{className:"jsx-242efb28197e35b3 plain-list",children:[x.primary_concerns?(0,a.jsxs)("li",{className:"jsx-242efb28197e35b3",children:[(0,a.jsx)("strong",{className:"jsx-242efb28197e35b3",children:"Primary concerns:"})," ",u(x.primary_concerns)]}):null,x.description?(0,a.jsxs)("li",{className:"jsx-242efb28197e35b3",children:[(0,a.jsx)("strong",{className:"jsx-242efb28197e35b3",children:"Description:"})," ",u(x.description)]}):null,x.duration?(0,a.jsxs)("li",{className:"jsx-242efb28197e35b3",children:[(0,a.jsx)("strong",{className:"jsx-242efb28197e35b3",children:"Duration:"})," ",u(x.duration)]}):null,x.impacts?(0,a.jsxs)("li",{className:"jsx-242efb28197e35b3",children:[(0,a.jsx)("strong",{className:"jsx-242efb28197e35b3",children:"Impacts:"})," ",u(x.impacts)]}):null,x.current_supports?(0,a.jsxs)("li",{className:"jsx-242efb28197e35b3",children:[(0,a.jsx)("strong",{className:"jsx-242efb28197e35b3",children:"Supports:"})," ",u(x.current_supports)]}):null,x.safety_concerns?(0,a.jsxs)("li",{className:"jsx-242efb28197e35b3",children:[(0,a.jsx)("strong",{className:"jsx-242efb28197e35b3",children:"Safety:"})," ",u(x.safety_concerns)]}):null,x.parent_goals?(0,a.jsxs)("li",{className:"jsx-242efb28197e35b3",children:[(0,a.jsx)("strong",{className:"jsx-242efb28197e35b3",children:"Goals:"})," ",u(x.parent_goals)]}):null]}):(0,a.jsx)("p",{className:"jsx-242efb28197e35b3 muted",children:"No intake responses yet."})}),(0,a.jsx)(d,{title:"Insurance & cost",missing:m.has("Insurance"),onEdit:()=>t("insurance"),showEdit:i,children:(0,a.jsxs)(c,{children:[(0,a.jsx)(o,{label:"Insurance status",value:e.insuranceDetail?.insuranceStatus}),(0,a.jsx)(o,{label:"Insurer",value:e.insuranceDetail?.insurerName}),(0,a.jsx)(o,{label:"Plan name",value:e.insuranceDetail?.planName}),(0,a.jsx)(o,{label:"Member ID",value:e.insuranceDetail?.memberId}),(0,a.jsx)(o,{label:"Policyholder",value:e.insuranceDetail?.policyholderName}),(0,a.jsx)(o,{label:"Cost estimate",value:(f=e.costEstimate)&&f.category?`${b(f.category)}${f.explanationText?` — ${f.explanationText}`:""}`:"Not calculated yet"})]})}),(0,a.jsx)(d,{title:"Scheduling preferences",missing:m.has("Scheduling"),onEdit:()=>t("scheduling"),showEdit:i,children:j?(0,a.jsxs)("div",{className:"jsx-242efb28197e35b3 scheduling-summary",children:[(0,a.jsxs)(c,{children:[(0,a.jsx)(o,{label:"Location preference",value:j.locationPreference}),(0,a.jsx)(o,{label:"Time zone",value:j.timezone}),(0,a.jsx)(o,{label:"Frequency",value:j.frequency})]}),(0,a.jsxs)("div",{className:"jsx-242efb28197e35b3 windows",children:[(0,a.jsx)("p",{className:"jsx-242efb28197e35b3 subhead",children:"Your windows"}),0===g.length?(0,a.jsx)("p",{className:"jsx-242efb28197e35b3 muted",children:"No windows added."}):(0,a.jsx)("ul",{className:"jsx-242efb28197e35b3 plain-list",children:g.map((e,r)=>{var s;return(0,a.jsxs)("li",{className:"jsx-242efb28197e35b3",children:[(0,a.jsxs)("strong",{className:"jsx-242efb28197e35b3",children:[(s=e.day)?s.charAt(0).toUpperCase()+s.slice(1):"",":"]})," ",p(e.start_time||e.startTime,e.end_time||e.endTime,j?.timezone)]},`${e.day}-${r}`)})})]}),v.length?(0,a.jsxs)("div",{className:"jsx-242efb28197e35b3 windows",children:[(0,a.jsx)("p",{className:"jsx-242efb28197e35b3 subhead",children:"Suggested first-session windows"}),(0,a.jsx)("ul",{className:"jsx-242efb28197e35b3 plain-list",children:v.map((e,r)=>(0,a.jsxs)("li",{className:"jsx-242efb28197e35b3",children:[p(e.start_time,e.end_time,j?.timezone)," ",e.source_profile?`\xb7 ${e.source_profile}`:""]},`${e.start_time}-${r}`))})]}):null]}):(0,a.jsx)("p",{className:"jsx-242efb28197e35b3 muted",children:"No scheduling preferences saved yet."})}),(0,a.jsxs)(d,{title:"Consents",missing:m.has("Consents"),onEdit:()=>t("consent"),showEdit:i,children:[(0,a.jsx)("ul",{className:"jsx-242efb28197e35b3 plain-list",children:l.map(e=>{let r=y.find(a=>(a.consentType||"").toLowerCase()===e);return(0,a.jsxs)("li",{className:"jsx-242efb28197e35b3 "+((r?"":"muted")||""),children:[(0,a.jsxs)("strong",{className:"jsx-242efb28197e35b3",children:[n[e],":"]})," ",r?`Accepted on ${function(e){if(!e)return"Not provided";let a=new Date(e);return Number.isNaN(a.getTime())?e:new Intl.DateTimeFormat("en-US",{month:"short",day:"numeric",year:"numeric"}).format(a)}(r.acceptedAt)}`:"Not accepted"]},e)})}),I?null:(0,a.jsx)("p",{className:"jsx-242efb28197e35b3 db-input-error-text",children:"All required consents must be accepted."})]}),(0,a.jsx)(r.default,{id:"242efb28197e35b3",children:".review-summary.jsx-242efb28197e35b3{flex-direction:column;gap:12px;display:flex}.plain-list.jsx-242efb28197e35b3{gap:6px;margin:0;padding:0;list-style:none;display:grid}.muted.jsx-242efb28197e35b3{color:var(--color-muted)}.windows.jsx-242efb28197e35b3{margin-top:8px}.subhead.jsx-242efb28197e35b3{color:var(--color-deep-aqua);margin:0 0 6px;font-weight:700}"})]})}function d({title:e,onEdit:n,missing:l=!1,children:i,showEdit:d=!0}){return(0,a.jsxs)(t.default,{padding:"16px",className:`summary-card ${l?"summary-card--warning":""}`,children:[(0,a.jsxs)("div",{className:"jsx-1bd53e023b6ddb28 summary-card__header",children:[(0,a.jsxs)("div",{className:"jsx-1bd53e023b6ddb28",children:[(0,a.jsx)("p",{className:"jsx-1bd53e023b6ddb28 summary-eyebrow",children:l?"Needs attention":"Ready"}),(0,a.jsx)("h3",{className:"jsx-1bd53e023b6ddb28",children:e})]}),d?(0,a.jsx)(s.default,{variant:"ghost",size:"sm",onClick:n,children:"Edit"}):null]}),(0,a.jsx)("div",{className:"jsx-1bd53e023b6ddb28 summary-card__body",children:i}),(0,a.jsx)(r.default,{id:"1bd53e023b6ddb28",children:".summary-card.jsx-1bd53e023b6ddb28{border:1px solid var(--color-border);background:#fff;border-radius:14px}.summary-card--warning.jsx-1bd53e023b6ddb28{border-color:var(--color-secondary-gold);background:#fff9f1}.summary-card__header.jsx-1bd53e023b6ddb28{justify-content:space-between;align-items:flex-start;gap:10px;display:flex}.summary-eyebrow.jsx-1bd53e023b6ddb28{color:var(--color-muted);margin:0;font-size:13px;font-weight:700}h3.jsx-1bd53e023b6ddb28{color:var(--color-deep-aqua);margin:4px 0 8px}"})]})}function c({children:e}){return(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)("div",{className:"jsx-fae54475cca71bd5 two-col",children:e}),(0,a.jsx)(r.default,{id:"fae54475cca71bd5",children:".two-col.jsx-fae54475cca71bd5{grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px;display:grid}"})]})}function o({label:e,value:s}){return(0,a.jsxs)("div",{className:"jsx-5b3da39b7ed577aa info-item",children:[(0,a.jsx)("p",{className:"jsx-5b3da39b7ed577aa info-label",children:e}),(0,a.jsx)("p",{className:"jsx-5b3da39b7ed577aa info-value",children:s||"Not provided"}),(0,a.jsx)(r.default,{id:"5b3da39b7ed577aa",children:".info-label.jsx-5b3da39b7ed577aa{color:var(--color-muted);margin:0;font-size:13px}.info-value.jsx-5b3da39b7ed577aa{color:var(--color-text);margin:2px 0 0;font-weight:600}"})]})}function u(e){return Array.isArray(e)?e.join(", "):"object"==typeof e?JSON.stringify(e,null,0):!0===e?"Yes":!1===e?"No":e??"Not provided"}function b(e){return e.replace(/_/g," ").replace(/\b\w/g,e=>e.toUpperCase())}function p(e,a,r){if(!e||!a)return"Time not available";let s=new Date(e),t=new Date(a);if(Number.isNaN(s.getTime())||Number.isNaN(t.getTime()))return`${e} – ${a}`;let n=new Intl.DateTimeFormat("en-US",{weekday:"short",hour:"numeric",minute:"2-digit",timeZoneName:"short",...r?{timeZone:r}:{}});return`${n.format(s)} – ${n.format(t)}`}e.s(["default",()=>i])},42008,(e,a,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0});var s={VALID_LOADERS:function(){return n},imageConfigDefault:function(){return l}};for(var t in s)Object.defineProperty(r,t,{enumerable:!0,get:s[t]});let n=["default","imgix","cloudinary","akamai","custom"],l={deviceSizes:[640,750,828,1080,1200,1920,2048,3840],imageSizes:[32,48,64,96,128,256,384],path:"/_next/image",loader:"default",loaderFile:"",domains:[],disableStaticImages:!1,minimumCacheTTL:14400,formats:["image/webp"],maximumRedirects:3,dangerouslyAllowLocalIP:!1,dangerouslyAllowSVG:!1,contentSecurityPolicy:"script-src 'none'; frame-src 'none'; sandbox;",contentDispositionType:"attachment",localPatterns:void 0,remotePatterns:[],qualities:[75],unoptimized:!1}},78361,(e,a,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"ImageConfigContext",{enumerable:!0,get:function(){return n}});let s=e.r(1646)._(e.r(73658)),t=e.r(42008),n=s.default.createContext(t.imageConfigDefault)},20768,e=>{"use strict";var a=e.i(41526),r=e.i(22366),s=e.i(52254),t=e.i(9793),n=e.i(39491),l=e.i(73658),i=e.i(83724),d=e.i(53949),c=e.i(61502),o=e.i(93962),u=e.i(3308),b=e.i(56421),p=e.i(76245),f=e.i(20979),m=e.i(12190);let x=["terms_of_use","privacy_policy","non_emergency_acknowledgment","telehealth_consent","guardian_authorization"];function h(){let e=(0,n.useRouter)(),x=(0,s.useApolloClient)(),{id:h}=e.query,v=(0,l.useMemo)(()=>h||"",[h]),{referral:y,loading:N,error:I,refetch:w}=(0,b.default)(v,{fetchPolicy:"network-only",nextFetchPolicy:"cache-and-network"});(0,l.useEffect)(()=>{v&&w()},[v,w]),(0,l.useEffect)(()=>{y&&"draft"!==y.status&&e.replace(`/parent/referrals/${y.id}/details`)},[y,e]);let[S]=(0,t.useMutation)(f.SUBMIT_REFERRAL),[_,C]=(0,l.useState)(""),[P,$]=(0,l.useState)([]),[E,A]=(0,l.useState)("idle"),[T,k]=(0,l.useState)(""),D=(0,l.useRef)(null),R=(0,l.useRef)(null);(0,l.useEffect)(()=>()=>{D.current&&clearInterval(D.current),R.current&&clearTimeout(R.current)},[]),(0,l.useEffect)(()=>{y&&$(j(y))},[y]);let U=async()=>{if(!v)return;let{data:a}=await w(),r=a?.referral??y;if(!r)return;let s=j(r);if(s.length){$(s),C("Please complete the highlighted sections before submitting.");return}C(""),k(""),A("submitting");try{let{data:a}=await S({variables:{referralId:v}}),r=a?.submitReferral?.errors;if(r?.length){C(r.join(" | ")),A("idle");return}A("polling"),q(v),e.push(`/parent/referrals/${v}/details`)}catch{C("Unable to submit right now. Please try again."),A("idle")}},q=a=>{D.current&&clearInterval(D.current),R.current&&clearTimeout(R.current),D.current=setInterval(async()=>{let{data:r}=await x.query({query:m.REFERRAL_STATUS_QUERY,variables:{id:a},fetchPolicy:"network-only"}),s=r?.referral?.packetStatus;"complete"===s?(clearInterval(D.current),clearTimeout(R.current),A("complete"),k("We’ve generated your referral packet. Thank you!"),e.push(`/parent/referrals/${a}/details`)):"failed"===s&&(clearInterval(D.current),clearTimeout(R.current),A("idle"),C("Packet generation failed. Our team has been notified."))},2500),R.current=setTimeout(()=>{D.current&&clearInterval(D.current),A("idle"),k("Packet generation is taking longer than expected. We’ll notify you when it’s ready.")},3e4)};if(N)return(0,a.jsx)(i.default,{requireRole:"parent",children:(0,a.jsx)("div",{style:{padding:"48px 24px",textAlign:"center"},children:"Loading review…"})});if(I||!y)return(0,a.jsx)(i.default,{requireRole:"parent",children:(0,a.jsxs)("div",{style:{padding:"48px 24px",textAlign:"center"},children:[(0,a.jsx)("p",{children:"Unable to load this referral."}),(0,a.jsx)(o.default,{onClick:()=>e.push("/parent/dashboard"),children:"Back to dashboard"})]})});let L="submitted"===y.status||"complete"===E;return(0,a.jsx)(i.default,{requireRole:"parent",children:(0,a.jsxs)(d.default,{referralId:y.id,currentStep:"review",onStepSelect:a=>"review"===a?void 0:void e.push(`/parent/referrals/${y.id}/onboarding/${a}`),children:[(0,a.jsx)("div",{className:"jsx-c3b7e58fc15bdaab step-header",children:(0,a.jsxs)("div",{className:"jsx-c3b7e58fc15bdaab",children:[(0,a.jsxs)("p",{className:"jsx-c3b7e58fc15bdaab eyebrow",children:["Step ",9," of ",9]}),(0,a.jsx)("h2",{className:"jsx-c3b7e58fc15bdaab",children:"Review & submit"}),(0,a.jsx)("p",{className:"jsx-c3b7e58fc15bdaab muted",children:"Check each section below. We’ll confirm everything and generate your referral packet."})]})}),_?(0,a.jsx)(u.default,{message:_}):null,T?(0,a.jsx)(g,{tone:"info",message:T}):null,"polling"===E?(0,a.jsx)(g,{tone:"info",message:"Submitting your referral and generating the packet…"}):null,L?(0,a.jsx)(g,{tone:"success",message:"Submitted. We’re preparing next steps."}):null,(0,a.jsx)(c.default,{referral:y,missingSections:P,onEditStep:a=>{v&&e.push(`/parent/referrals/${v}/onboarding/${a}`)}}),"draft"===y.status?(0,a.jsxs)("div",{className:"jsx-c3b7e58fc15bdaab nav-actions",children:[(0,a.jsx)(o.default,{variant:"ghost",onClick:()=>{let a;a=(0,p.getPreviousStep)("review"),e.push(`/parent/referrals/${v}/onboarding/${a}`)},children:"Back"}),(0,a.jsxs)("div",{className:"jsx-c3b7e58fc15bdaab cta-group",children:[(0,a.jsx)(o.default,{variant:"secondary",onClick:()=>void e.push("/parent/dashboard"),children:"Save as draft"}),(0,a.jsx)(o.default,{onClick:()=>void U(),disabled:"submitting"===E||"polling"===E,children:"submitting"===E?"Submitting…":"polling"===E?"Generating packet…":"Submit referral"})]})]}):null,(0,a.jsx)(r.default,{id:"c3b7e58fc15bdaab",children:".step-header.jsx-c3b7e58fc15bdaab{flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;margin-bottom:12px;display:flex}.eyebrow.jsx-c3b7e58fc15bdaab{color:var(--color-primary-teal);margin:0;font-weight:700}h2.jsx-c3b7e58fc15bdaab{color:var(--color-deep-aqua);margin:4px 0}.muted.jsx-c3b7e58fc15bdaab{color:var(--color-muted);margin:0}.nav-actions.jsx-c3b7e58fc15bdaab{flex-wrap:wrap;justify-content:space-between;gap:12px;margin-top:12px;display:flex}.cta-group.jsx-c3b7e58fc15bdaab{flex-wrap:wrap;gap:10px;display:flex}@media (width<=768px){.nav-actions.jsx-c3b7e58fc15bdaab,.cta-group.jsx-c3b7e58fc15bdaab{flex-direction:column}}"})]})})}function j(e){let a=[],r=e.user||{},s=e.child||{},t=e.intakeResponse?.responses||{},n=e.aiScreenerSession?.summaryJsonb,l=e.insuranceDetail?.insuranceStatus,i=e.schedulingPreference,d=(e.consentRecords||[]).map(e=>(e.consentType||"").toLowerCase());r.name&&r.email&&r.phone||a.push("Parent info"),s.name&&(s.dob||s.ageBand)&&s.grade&&s.schoolName&&s.district||a.push("Child info"),t&&(t.primary_concerns?.length||t.description||t.parent_goals)||n||a.push("Clinical intake or screener"),l||a.push("Insurance");let c=i?.windows||[];return i&&i.timezone&&i.locationPreference&&c.length||a.push("Scheduling"),x.every(e=>d.includes(e))||a.push("Consents"),a}function g({tone:e,message:s}){return(0,a.jsxs)("div",{role:"status","aria-live":"polite",className:`jsx-dfd0b7bc93c33242 status-banner status-banner--${e}`,children:[s,(0,a.jsx)(r.default,{id:"dfd0b7bc93c33242",children:".status-banner.jsx-dfd0b7bc93c33242{border-radius:12px;margin-bottom:12px;padding:12px 14px;font-weight:600}.status-banner--info.jsx-dfd0b7bc93c33242{color:var(--color-deep-aqua);background:#f4fbfd;border:1px solid #b5e5ed}.status-banner--success.jsx-dfd0b7bc93c33242{color:#1a7f49;background:#f1fbf5;border:1px solid #b7e8c7}"})]})}e.s(["default",()=>h])},48990,(e,a,r)=>{let s="/parent/referrals/[id]/onboarding/review";(window.__NEXT_P=window.__NEXT_P||[]).push([s,()=>e.r(20768)]),a.hot&&a.hot.dispose(function(){window.__NEXT_P.push([s])})},88853,e=>{e.v(a=>Promise.all(["static/chunks/ca6b9ab451866ae2.js"].map(a=>e.l(a))).then(()=>a(33811)))},91751,e=>{e.v(a=>Promise.all(["static/chunks/b0bbf6aa740a2457.js"].map(a=>e.l(a))).then(()=>a(23428)))}]);