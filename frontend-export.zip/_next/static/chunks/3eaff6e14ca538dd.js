__turbopack_load_page_chunks__("/parent/referrals/[id]/onboarding/consent", [
  "static/chunks/ea20056a886f5245.js",
  "static/chunks/9550e7df1660064a.js",
  "static/chunks/4b1e92164ea6607d.js",
  "static/chunks/b6758c396527f921.js",
  "static/chunks/382f3ba59a902a64.js",
  "static/chunks/turbopack-36fe68ba1ef29680.js"
])
