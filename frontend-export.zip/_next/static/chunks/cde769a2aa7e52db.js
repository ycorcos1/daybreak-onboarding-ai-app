__turbopack_load_page_chunks__("/admin/chats", [
  "static/chunks/f088a58a835e875d.js",
  "static/chunks/382f3ba59a902a64.js",
  "static/chunks/b6758c396527f921.js",
  "static/chunks/bb660b55afbbf809.js",
  "static/chunks/turbopack-5652a6b3bdc7dab9.js"
])
