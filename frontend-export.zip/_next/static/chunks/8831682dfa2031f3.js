__turbopack_load_page_chunks__("/auth/signup", [
  "static/chunks/bd5e7ccbe0a9dbdb.js",
  "static/chunks/c743b7754a7dc85f.js",
  "static/chunks/e2b2ee896b4ab52e.js",
  "static/chunks/b6758c396527f921.js",
  "static/chunks/382f3ba59a902a64.js",
  "static/chunks/turbopack-b221ac9f841ba657.js"
])
