(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,97679,e=>{"use strict";var a=e.i(41526),r=e.i(22366);function t({label:e,id:t,helperText:i,error:l,required:s,...n}){let d=i?`${t}-helper`:void 0,o=l?`${t}-error`:void 0;return(0,a.jsxs)(a.Fragment,{children:[(0,a.jsxs)("label",{htmlFor:t,className:"jsx-59fec5f1f0edea5 db-input-label",children:[e,s?(0,a.jsx)("span",{className:"jsx-59fec5f1f0edea5 db-required",children:"*"}):null]}),(0,a.jsx)("input",{id:t,"aria-invalid":!!l,"aria-describedby":l?o:d,required:s,...n,className:"jsx-59fec5f1f0edea5 "+(n&&null!=n.className&&n.className||`db-input ${l?"db-input-error":""}`)}),i&&!l?(0,a.jsx)("p",{id:d,className:"jsx-59fec5f1f0edea5 db-input-helper",children:i}):null,l?(0,a.jsx)("p",{id:o,className:"jsx-59fec5f1f0edea5 db-input-error-text",children:l}):null,(0,a.jsx)(r.default,{id:"59fec5f1f0edea5",children:".db-input-label.jsx-59fec5f1f0edea5{color:var(--color-deep-aqua);margin-bottom:4px;font-weight:600;display:block}.db-required.jsx-59fec5f1f0edea5{color:var(--color-accent-red);margin-left:4px}.db-input.jsx-59fec5f1f0edea5{border:1px solid var(--color-border);width:100%;height:46px;color:var(--color-text);background:#fff;border-radius:10px;padding:0 58px 0 14px;font-size:15px;transition:border-color .12s,box-shadow .12s}.db-input.jsx-59fec5f1f0edea5:focus{border-color:var(--color-primary-teal);outline:none;box-shadow:0 0 0 3px #0096a833}.db-input.jsx-59fec5f1f0edea5::placeholder{color:var(--color-muted)}.db-input-error.jsx-59fec5f1f0edea5{border-color:var(--color-accent-red)}.db-input-helper.jsx-59fec5f1f0edea5{color:var(--color-muted);margin-top:6px;font-size:13px}.db-input-error-text.jsx-59fec5f1f0edea5{color:var(--color-accent-red);margin-top:6px;font-size:13px}"})]})}e.s(["TextInput",()=>t,"default",0,t])},91332,e=>{"use strict";var a=e.i(41526),r=e.i(22366);e.s(["default",0,function({id:e,label:t,options:i,helperText:l,error:s,required:n,...d}){let o=l?`${e}-helper`:void 0,c=s?`${e}-error`:void 0,f=i.some(e=>""===e.value);return(0,a.jsxs)("div",{className:"jsx-734334db1d082c81 select-field",children:[(0,a.jsxs)("label",{htmlFor:e,className:"jsx-734334db1d082c81 db-input-label",children:[t,n?(0,a.jsx)("span",{className:"jsx-734334db1d082c81 db-required",children:"*"}):null]}),(0,a.jsxs)("select",{id:e,"aria-invalid":!!s,"aria-describedby":s?c:o,required:n,...d,className:"jsx-734334db1d082c81 "+(d&&null!=d.className&&d.className||`db-select ${s?"db-input-error":""}`),children:[void 0!==d.defaultValue||f?null:(0,a.jsx)("option",{value:"",className:"jsx-734334db1d082c81",children:"Select..."}),i.map(e=>(0,a.jsx)("option",{value:e.value,className:"jsx-734334db1d082c81",children:e.label},e.value))]}),l&&!s?(0,a.jsx)("p",{id:o,className:"jsx-734334db1d082c81 db-input-helper",children:l}):null,s?(0,a.jsx)("p",{id:c,className:"jsx-734334db1d082c81 db-input-error-text",children:s}):null,(0,a.jsx)(r.default,{id:"734334db1d082c81",children:".db-input-label.jsx-734334db1d082c81{color:var(--color-deep-aqua);margin-bottom:6px;font-weight:600;display:block}.db-required.jsx-734334db1d082c81{color:var(--color-accent-red);margin-left:4px}.db-select.jsx-734334db1d082c81{border:1px solid var(--color-border);width:100%;height:46px;color:var(--color-text);background:#fff;border-radius:10px;padding:0 12px;font-size:15px;transition:border-color .12s,box-shadow .12s}.db-select.jsx-734334db1d082c81:focus{border-color:var(--color-primary-teal);outline:none;box-shadow:0 0 0 3px #0096a833}.db-input-error.jsx-734334db1d082c81{border-color:var(--color-accent-red)}.db-input-helper.jsx-734334db1d082c81{color:var(--color-muted);margin-top:6px;font-size:13px}.db-input-error-text.jsx-734334db1d082c81{color:var(--color-accent-red);margin-top:6px;font-size:13px}"})]})}])},20979,e=>{"use strict";var a=e.i(64467);let r=a.gql`
  mutation CreateChildAndReferral($childInput: ChildInput!) {
    createChildAndReferral(childInput: $childInput) {
      child {
        id
        name
        grade
        schoolName
        district
      }
      referral {
        id
        status
        lastCompletedStep
        nextStep
      }
      errors
    }
  }
`,t=a.gql`
  mutation UpdateReferralStep(
    $referralId: ID!
    $stepName: String!
    $stepData: JSON
  ) {
    updateReferralStep(
      referralId: $referralId
      stepName: $stepName
      stepData: $stepData
    ) {
      referral {
        id
        status
        lastCompletedStep
        lastUpdatedStepAt
        nextStep
      }
      errors
    }
  }
`,i=a.gql`
  mutation UpdateParentInfo($referralId: ID!, $parentInfo: ParentInfoInput!) {
    updateParentInfo(referralId: $referralId, parentInfo: $parentInfo) {
      user {
        id
        name
        email
        phone
        address
        languagePreference
        relationshipToChild
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,l=a.gql`
  mutation UpdateChildInfo($referralId: ID!, $childInput: ChildInput!) {
    updateChildInfo(referralId: $referralId, childInput: $childInput) {
      child {
        id
        name
        dob
        ageBand
        grade
        schoolName
        district
        state
        primaryLanguage
        pronouns
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,s=a.gql`
  mutation UpdateClinicalIntake($referralId: ID!, $intakeInput: ClinicalIntakeInput!) {
    updateClinicalIntake(referralId: $referralId, intakeInput: $intakeInput) {
      intakeResponse {
        id
        responses
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,n=a.gql`
  mutation UpdateSchedulingPreferences(
    $referralId: ID!
    $schedulingInput: SchedulingPreferenceInput!
  ) {
    updateSchedulingPreferences(referralId: $referralId, schedulingInput: $schedulingInput) {
      schedulingPreference {
        id
        timezone
        locationPreference
        frequency
        clinicianPreferences
        windows
        suggestedWindows
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,d=a.gql`
  mutation SubmitReferral($referralId: ID!) {
    submitReferral(referralId: $referralId) {
      referral {
        id
        status
        packetStatus
        submittedAt
      }
      errors
    }
  }
`,o=a.gql`
  mutation UpdateInsuranceDetails($referralId: ID!, $insuranceInput: InsuranceDetailInput!) {
    updateInsuranceDetails(referralId: $referralId, insuranceInput: $insuranceInput) {
      insuranceDetail {
        id
        insuranceStatus
        insurerName
        planName
        memberId
        groupId
        policyholderName
        coveragePhone
        coverageWebsite
        source
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,c=a.gql`
  mutation AcceptConsents($referralId: ID!, $consents: [ConsentInput!]!) {
    acceptConsents(referralId: $referralId, consents: $consents) {
      consentRecords {
        id
        consentType
        acceptedAt
        ipAddress
        userAgent
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`;e.s(["ACCEPT_CONSENTS",0,c,"CREATE_CHILD_AND_REFERRAL",0,r,"SUBMIT_REFERRAL",0,d,"UPDATE_CHILD_INFO",0,l,"UPDATE_CLINICAL_INTAKE",0,s,"UPDATE_INSURANCE_DETAILS",0,o,"UPDATE_PARENT_INFO",0,i,"UPDATE_REFERRAL_STEP",0,t,"UPDATE_SCHEDULING_PREFERENCES",0,n])},3308,e=>{"use strict";var a=e.i(41526),r=e.i(22366);e.s(["default",0,function({message:e}){return e?(0,a.jsxs)("div",{role:"alert","aria-live":"assertive",className:"jsx-3a06f6b875d5b277 validation-error",children:[e,(0,a.jsx)(r.default,{id:"3a06f6b875d5b277",children:".validation-error.jsx-3a06f6b875d5b277{color:var(--color-accent-red);border:1px solid var(--color-accent-red);background:#ff4b4b1a;border-radius:12px;padding:10px 12px;font-weight:600}"})]}):null}])},42008,(e,a,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0});var t={VALID_LOADERS:function(){return l},imageConfigDefault:function(){return s}};for(var i in t)Object.defineProperty(r,i,{enumerable:!0,get:t[i]});let l=["default","imgix","cloudinary","akamai","custom"],s={deviceSizes:[640,750,828,1080,1200,1920,2048,3840],imageSizes:[32,48,64,96,128,256,384],path:"/_next/image",loader:"default",loaderFile:"",domains:[],disableStaticImages:!1,minimumCacheTTL:14400,formats:["image/webp"],maximumRedirects:3,dangerouslyAllowLocalIP:!1,dangerouslyAllowSVG:!1,contentSecurityPolicy:"script-src 'none'; frame-src 'none'; sandbox;",contentDispositionType:"attachment",localPatterns:void 0,remotePatterns:[],qualities:[75],unoptimized:!1}},78361,(e,a,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"ImageConfigContext",{enumerable:!0,get:function(){return l}});let t=e.r(1646)._(e.r(73658)),i=e.r(42008),l=t.default.createContext(i.imageConfigDefault)},15172,92103,e=>{"use strict";var a=e.i(41526),r=e.i(22366);e.s(["default",0,function({name:e,label:t,options:i,selectedValues:l,onChange:s,error:n,helperText:d}){return(0,a.jsxs)("fieldset",{"aria-describedby":n?`${e}-error`:void 0,className:"jsx-46c29e667fcb216b checkbox-group",children:[(0,a.jsx)("legend",{className:"jsx-46c29e667fcb216b db-input-label",children:t}),(0,a.jsx)("div",{className:"jsx-46c29e667fcb216b checkbox-options",children:i.map(r=>(0,a.jsxs)("label",{className:"jsx-46c29e667fcb216b checkbox-option",children:[(0,a.jsx)("input",{type:"checkbox",name:e,value:r.value,checked:l.includes(r.value),onChange:()=>{var e;return e=r.value,void(l.includes(e)?s(l.filter(a=>a!==e)):s([...l,e]))},className:"jsx-46c29e667fcb216b"}),(0,a.jsx)("span",{className:"jsx-46c29e667fcb216b",children:r.label})]},r.value))}),d&&!n?(0,a.jsx)("p",{className:"jsx-46c29e667fcb216b db-input-helper",children:d}):null,n?(0,a.jsx)("p",{id:`${e}-error`,className:"jsx-46c29e667fcb216b db-input-error-text",children:n}):null,(0,a.jsx)(r.default,{id:"46c29e667fcb216b",children:".db-input-label.jsx-46c29e667fcb216b{color:var(--color-deep-aqua);margin-bottom:8px;font-weight:600}.checkbox-options.jsx-46c29e667fcb216b{grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:8px 12px;display:grid}.checkbox-option.jsx-46c29e667fcb216b{color:var(--color-text);align-items:center;gap:8px;font-weight:500;display:flex}input[type=checkbox].jsx-46c29e667fcb216b{width:18px;height:18px}.db-input-helper.jsx-46c29e667fcb216b{color:var(--color-muted);margin-top:6px;font-size:13px}.db-input-error-text.jsx-46c29e667fcb216b{color:var(--color-accent-red);margin-top:6px;font-size:13px}"})]})}],15172),e.s(["default",0,function({title:e,description:t,children:i}){return(0,a.jsxs)("section",{className:"jsx-4bfdf9fc807bb08d form-section",children:[(0,a.jsxs)("header",{className:"jsx-4bfdf9fc807bb08d form-section__header",children:[(0,a.jsx)("h3",{className:"jsx-4bfdf9fc807bb08d",children:e}),t?(0,a.jsx)("p",{className:"jsx-4bfdf9fc807bb08d form-section__desc",children:t}):null]}),(0,a.jsx)("div",{className:"jsx-4bfdf9fc807bb08d form-section__body",children:i}),(0,a.jsx)(r.default,{id:"4bfdf9fc807bb08d",children:".form-section.jsx-4bfdf9fc807bb08d{background:var(--color-warm-beige);border:1px solid var(--color-border);border-radius:16px;margin-bottom:16px;padding:18px}.form-section__header.jsx-4bfdf9fc807bb08d{margin-bottom:10px}.form-section__desc.jsx-4bfdf9fc807bb08d{color:var(--color-muted);margin:0;font-size:14px}.form-section__body.jsx-4bfdf9fc807bb08d .field-row{margin-bottom:14px}"})]})}],92103)},1557,e=>{"use strict";var a=e.i(41526),r=e.i(22366),t=e.i(9793),i=e.i(39491),l=e.i(73658),s=e.i(83724),n=e.i(53949),d=e.i(93962),o=e.i(3308),c=e.i(15172),f=e.i(92103),u=e.i(91332),b=e.i(97679);let p=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],x=[{value:"America/Los_Angeles",label:"Pacific (PT)"},{value:"America/Denver",label:"Mountain (MT)"},{value:"America/Chicago",label:"Central (CT)"},{value:"America/New_York",label:"Eastern (ET)"}],m=["Before school","During school","After school","Weekends","School breaks/holidays"].map(e=>({value:e,label:e})),g=[{value:"weekly",label:"Weekly"},{value:"biweekly",label:"Every other week"},{value:"unsure",label:"I’m not sure yet"}];function h({timezone:e,locationPreference:t,frequency:i,timingCategories:l,clinicianPreferences:s,windows:n,suggestedWindows:o,onTimezoneChange:h,onLocationChange:v,onFrequencyChange:N,onTimingCategoriesChange:w,onClinicianPreferencesChange:y,onAddWindow:I,onUpdateWindow:S,onRemoveWindow:C,windowError:_}){let T=p.map(e=>({day:e,entries:n.filter(a=>a.day.toLowerCase()===e.toLowerCase())}));return(0,a.jsxs)("div",{className:"jsx-ae34291b6faa58bf scheduling-form",children:[(0,a.jsxs)(f.default,{title:"When and where could sessions happen?",description:"These times help us coordinate; they are requests, not confirmed appointments.",children:[(0,a.jsxs)("div",{className:"jsx-ae34291b6faa58bf field-grid",children:[(0,a.jsxs)("div",{className:"jsx-ae34291b6faa58bf field-col",children:[(0,a.jsx)("p",{className:"jsx-ae34291b6faa58bf db-input-label",children:"Location preference"}),(0,a.jsx)("div",{role:"group","aria-label":"Location preference",className:"jsx-ae34291b6faa58bf radio-list",children:[{value:"home",label:"Home"},{value:"school",label:"School"},{value:"either",label:"Either home or school"}].map(e=>(0,a.jsxs)("label",{className:"jsx-ae34291b6faa58bf radio-item",children:[(0,a.jsx)("input",{type:"radio",name:"locationPreference",value:e.value,checked:t===e.value,onChange:e=>v(e.target.value),className:"jsx-ae34291b6faa58bf"}),(0,a.jsx)("span",{className:"jsx-ae34291b6faa58bf",children:e.label})]},e.value))})]}),(0,a.jsx)("div",{className:"jsx-ae34291b6faa58bf field-col",children:(0,a.jsx)(u.default,{id:"timezone",label:"Time zone",required:!0,options:x,value:e,onChange:e=>h(e.target.value)})})]}),(0,a.jsxs)("div",{className:"jsx-ae34291b6faa58bf field-grid",children:[(0,a.jsx)("div",{className:"jsx-ae34291b6faa58bf field-col",children:(0,a.jsx)(c.default,{name:"timingCategories",label:"Generally, which times work?",options:m,selectedValues:l,helperText:"You can add specific windows below.",onChange:w})}),(0,a.jsx)("div",{className:"jsx-ae34291b6faa58bf field-col",children:(0,a.jsx)(u.default,{id:"frequency",label:"Preferred frequency",options:g,value:i,onChange:e=>N(e.target.value)})})]})]}),(0,a.jsxs)(f.default,{title:"Add detailed time windows",description:"Add as many windows as you like. Start time must be before end time.",children:[(0,a.jsx)("div",{className:"jsx-ae34291b6faa58bf windows",children:T.map(({day:e,entries:r})=>(0,a.jsxs)("div",{className:"jsx-ae34291b6faa58bf day-row",children:[(0,a.jsxs)("div",{className:"jsx-ae34291b6faa58bf day-header",children:[(0,a.jsx)("p",{className:"jsx-ae34291b6faa58bf day-label",children:e}),(0,a.jsx)(d.default,{variant:"ghost",size:"sm",onClick:()=>I(e),children:"Add time window"})]}),0===r.length?(0,a.jsxs)("p",{className:"jsx-ae34291b6faa58bf muted",children:["No windows added for ",e," yet."]}):r.map(r=>(0,a.jsxs)("div",{className:"jsx-ae34291b6faa58bf window-row",children:[(0,a.jsxs)("label",{className:"jsx-ae34291b6faa58bf time-field",children:[(0,a.jsx)("span",{className:"jsx-ae34291b6faa58bf",children:"Start"}),(0,a.jsx)("input",{type:"time",value:r.startTime,onChange:e=>S(r.id,"startTime",e.target.value),"aria-label":`Start time for ${e}`,className:"jsx-ae34291b6faa58bf"})]}),(0,a.jsxs)("label",{className:"jsx-ae34291b6faa58bf time-field",children:[(0,a.jsx)("span",{className:"jsx-ae34291b6faa58bf",children:"End"}),(0,a.jsx)("input",{type:"time",value:r.endTime,onChange:e=>S(r.id,"endTime",e.target.value),"aria-label":`End time for ${e}`,className:"jsx-ae34291b6faa58bf"})]}),(0,a.jsx)(d.default,{variant:"ghost",size:"sm",onClick:()=>C(r.id),children:"Remove"})]},r.id))]},e))}),_?(0,a.jsx)("p",{className:"jsx-ae34291b6faa58bf db-input-error-text",children:_}):null]}),(0,a.jsxs)(f.default,{title:"Clinician preferences (optional)",children:[(0,a.jsxs)("div",{className:"jsx-ae34291b6faa58bf field-grid",children:[(0,a.jsx)("div",{className:"jsx-ae34291b6faa58bf field-col",children:(0,a.jsx)(b.default,{id:"preferred-language",label:"Language preference",placeholder:"e.g., Spanish, Mandarin",value:s.language??"",onChange:e=>y({...s,language:e.target.value})})}),(0,a.jsx)("div",{className:"jsx-ae34291b6faa58bf field-col",children:(0,a.jsx)(u.default,{id:"gender-preference",label:"Clinician gender preference",options:[{value:"none",label:"No preference"},{value:"female",label:"Female"},{value:"male",label:"Male"}],value:s.gender??"none",onChange:e=>y({...s,gender:e.target.value})})})]}),(0,a.jsxs)("div",{className:"jsx-ae34291b6faa58bf field-grid",children:[(0,a.jsx)("div",{className:"jsx-ae34291b6faa58bf field-col checkbox-inline",children:(0,a.jsxs)("label",{className:"jsx-ae34291b6faa58bf checkbox-inline__label",children:[(0,a.jsx)("input",{type:"checkbox",checked:!!s.lgbtqAffirming,onChange:e=>y({...s,lgbtqAffirming:e.target.checked}),className:"jsx-ae34291b6faa58bf"}),(0,a.jsx)("span",{className:"jsx-ae34291b6faa58bf",children:"LGBTQ+-affirming clinician preferred"})]})}),(0,a.jsx)("div",{className:"jsx-ae34291b6faa58bf field-col",children:(0,a.jsx)(b.default,{id:"cultural-notes",label:"Anything cultural we should honor?",placeholder:"Share any cultural or community preferences",value:s.culturalNotes??"",onChange:e=>y({...s,culturalNotes:e.target.value})})})]})]}),(0,a.jsx)(f.default,{title:"Suggested first-session windows",description:"These are suggestions based on your preferences and typical clinician availability.",children:o.length?(0,a.jsx)("ul",{className:"jsx-ae34291b6faa58bf suggested-list",children:o.map((r,t)=>{var i;return(0,a.jsxs)("li",{className:"jsx-ae34291b6faa58bf suggested-item",children:[(0,a.jsxs)("p",{className:"jsx-ae34291b6faa58bf suggested-time",children:[j(r.start_time,e)," –"," ",j(r.end_time,e)]}),(0,a.jsxs)("p",{className:"jsx-ae34291b6faa58bf muted",children:[r.source_profile?`${r.source_profile} \xb7 `:"","Confidence: ","number"!=typeof(i=r.confidence_score)?"N/A":`${Math.min(100,Math.max(0,Math.round(i)))}%`]})]},`${r.start_time}-${t}`)})}):(0,a.jsx)("p",{className:"jsx-ae34291b6faa58bf muted",children:"No suggested windows yet. Adjust your times or try a different day to see suggestions."})}),(0,a.jsx)(r.default,{id:"ae34291b6faa58bf",children:".scheduling-form.jsx-ae34291b6faa58bf{flex-direction:column;gap:12px;display:flex}.field-grid.jsx-ae34291b6faa58bf{grid-template-columns:repeat(auto-fit,minmax(280px,1fr));align-items:flex-end;gap:12px;display:grid}.field-col.jsx-ae34291b6faa58bf,.radio-list.jsx-ae34291b6faa58bf{flex-direction:column;gap:8px;display:flex}.radio-item.jsx-ae34291b6faa58bf{align-items:center;gap:8px;font-weight:500;display:flex}.windows.jsx-ae34291b6faa58bf{flex-direction:column;gap:12px;display:flex}.day-row.jsx-ae34291b6faa58bf{border:1px solid var(--color-border);background:#fff;border-radius:12px;padding:12px}.day-header.jsx-ae34291b6faa58bf{flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;display:flex}.day-label.jsx-ae34291b6faa58bf{color:var(--color-deep-aqua);margin:0;font-weight:700}.window-row.jsx-ae34291b6faa58bf{grid-template-columns:repeat(auto-fit,minmax(140px,1fr));align-items:center;gap:10px;margin-top:8px;display:grid}.time-field.jsx-ae34291b6faa58bf{color:var(--color-deep-aqua);flex-direction:column;gap:4px;font-weight:600;display:flex}.time-field.jsx-ae34291b6faa58bf input[type=time].jsx-ae34291b6faa58bf{border:1px solid var(--color-border);border-radius:10px;padding:10px 12px;font-size:14px}.muted.jsx-ae34291b6faa58bf{color:var(--color-muted);margin:4px 0 0}.checkbox-inline.jsx-ae34291b6faa58bf{margin-top:4px}.checkbox-inline__label.jsx-ae34291b6faa58bf{align-items:center;gap:8px;font-weight:500;display:flex}.suggested-list.jsx-ae34291b6faa58bf{gap:10px;margin:0;padding:0;list-style:none;display:grid}.suggested-item.jsx-ae34291b6faa58bf{border:1px solid var(--color-border);background:#fff;border-radius:12px;padding:12px}.suggested-time.jsx-ae34291b6faa58bf{color:var(--color-deep-aqua);margin:0 0 6px;font-weight:700}@media (width<=768px){.window-row.jsx-ae34291b6faa58bf{grid-template-columns:1fr}}"})]})}function j(e,a){if(!e)return"Time not available";let r=new Date(e);return Number.isNaN(r.getTime())?e:new Intl.DateTimeFormat("en-US",{weekday:"short",hour:"numeric",minute:"2-digit",timeZoneName:"short",...a?{timeZone:a}:{}}).format(r)}var v=e.i(56421),N=e.i(76245),w=e.i(20979);let y="undefined"!=typeof Intl&&Intl.DateTimeFormat().resolvedOptions().timeZone?Intl.DateTimeFormat().resolvedOptions().timeZone:"America/Los_Angeles",I="Please add at least one valid scheduling window to continue.";function S(){let e=(0,i.useRouter)(),{id:c}=e.query,f=(0,l.useMemo)(()=>c||"",[c]),{referral:u,loading:b,error:p}=(0,v.default)(f),[x]=(0,t.useMutation)(w.UPDATE_SCHEDULING_PREFERENCES),[m,g]=(0,l.useState)(y),[j,S]=(0,l.useState)("either"),[_,T]=(0,l.useState)("unsure"),[A,$]=(0,l.useState)([]),[P,k]=(0,l.useState)({language:"",gender:"none",lgbtqAffirming:!1,culturalNotes:""}),[q,E]=(0,l.useState)([]),[D,R]=(0,l.useState)([]),[U,L]=(0,l.useState)("idle"),[z,F]=(0,l.useState)(""),[O,M]=(0,l.useState)(""),W=(0,l.useRef)(!1),B=e=>e.some(e=>(function(e,a){if(!e||!a)return!1;let r=C(e),t=C(a);return null!==r&&null!==t&&r<t})(e.startTime,e.endTime));(0,l.useEffect)(()=>{if(!u)return;let e=u.schedulingPreference,a=!!e?.windows?.length;if(!W.current||a){g(e?.timezone||y),S(e?.locationPreference||"either"),T(e?.frequency||"unsure");let a=e?.clinicianPreferences||{};k({language:a.language||"",gender:a.gender||"none",lgbtqAffirming:!!(a.lgbtq_affirming||a.lgbtqAffirming),culturalNotes:a.cultural_notes||""}),$(a.timing_categories||[]);let r=e?.windows?.map((e,a)=>({id:`win-${a}`,day:(e.day||e.day||"").toString()||"Monday",startTime:e.start_time||e.start_time||"",endTime:e.end_time||e.end_time||""}))??[];r.length?E(r):W.current||E([{id:`win-${Date.now()}`,day:"Monday",startTime:"",endTime:""}]),R(e?.suggestedWindows||[])}W.current=!0},[u]),(0,l.useEffect)(()=>{if(!W.current||!f||!B(q))return;let e=setTimeout(()=>{H(!1)},800);return()=>clearTimeout(e)},[f,m,j,_,JSON.stringify(q),JSON.stringify(A),JSON.stringify(P)]);let G=()=>{let e=q.filter(e=>e.day&&e.startTime&&e.endTime).map(e=>({day:e.day.toLowerCase(),start_time:e.startTime,end_time:e.endTime})),a={};return P.language&&(a.language=P.language),P.gender&&"none"!==P.gender&&(a.gender=P.gender),P.lgbtqAffirming&&(a.lgbtq_affirming=!0),P.culturalNotes&&(a.cultural_notes=P.culturalNotes),A.length&&(a.timing_categories=A),{timezone:m,locationPreference:j,frequency:_,windows:e,clinicianPreferences:a}},H=async e=>{if(!f)return!1;if(F(""),M(""),!G().windows.length||!B(q))return M(I),L("error"),!1;L("saving");try{let{data:a}=await x({variables:{referralId:f,schedulingInput:G()}}),r=a?.updateSchedulingPreferences?.errors;if(r?.length)return e&&F(r[0]),L("error"),!1;let t=a?.updateSchedulingPreferences?.schedulingPreference;return R(t?.suggestedWindows||[]),L("saved"),setTimeout(()=>L("idle"),1200),!0}catch{return e&&F("Unable to save scheduling preferences right now."),L("error"),!1}},J=async()=>{if(!B(q)){M(I),F(""),L("error");return}if(!await H(!0))return;let a=(0,N.getNextStep)("scheduling");e.push(`/parent/referrals/${f}/onboarding/${a}`)};return b?(0,a.jsx)(s.default,{requireRole:"parent",children:(0,a.jsx)("div",{style:{padding:"48px 24px",textAlign:"center"},children:"Loading scheduling…"})}):p||!u?(0,a.jsx)(s.default,{requireRole:"parent",children:(0,a.jsxs)("div",{style:{padding:"48px 24px",textAlign:"center"},children:[(0,a.jsx)("p",{children:"Unable to load this referral."}),(0,a.jsx)(d.default,{onClick:()=>e.push("/parent/dashboard"),children:"Back to dashboard"})]})}):(0,a.jsx)(s.default,{requireRole:"parent",children:(0,a.jsxs)(n.default,{referralId:u.id,currentStep:"scheduling",onStepSelect:a=>"scheduling"===a?void 0:void e.push(`/parent/referrals/${u.id}/onboarding/${a}`),children:[(0,a.jsxs)("div",{className:"jsx-7cd5a213ca9979ab step-header",children:[(0,a.jsxs)("div",{className:"jsx-7cd5a213ca9979ab",children:[(0,a.jsxs)("p",{className:"jsx-7cd5a213ca9979ab eyebrow",children:["Step ",7," of ",9]}),(0,a.jsx)("h2",{className:"jsx-7cd5a213ca9979ab",children:"When are sessions possible?"}),(0,a.jsx)("p",{className:"jsx-7cd5a213ca9979ab muted",children:"Share the times that could work. We’ll suggest 1–3 windows that best match clinician availability."})]}),(0,a.jsxs)("div",{"aria-live":"polite",className:"jsx-7cd5a213ca9979ab save-indicator",children:["saving"===U&&"Saving…","saved"===U&&"Saved","error"===U&&"Save error"]})]}),z?(0,a.jsx)(o.default,{message:z}):null,O&&!z?(0,a.jsx)(o.default,{message:O}):null,(0,a.jsx)(h,{timezone:m,locationPreference:j,frequency:_,timingCategories:A,clinicianPreferences:P,windows:q,suggestedWindows:D,onTimezoneChange:g,onLocationChange:S,onFrequencyChange:T,onTimingCategoriesChange:$,onClinicianPreferencesChange:e=>k({language:e.language??"",gender:e.gender??"none",lgbtqAffirming:!!e.lgbtqAffirming,culturalNotes:e.culturalNotes??""}),onAddWindow:e=>{E(a=>[...a,{id:`win-${Date.now()}-${a.length}`,day:e,startTime:"",endTime:""}])},onUpdateWindow:(e,a,r)=>{E(t=>t.map(t=>t.id===e?{...t,[a]:r}:t))},onRemoveWindow:e=>{E(a=>a.filter(a=>a.id!==e))},windowError:O}),(0,a.jsxs)("div",{className:"jsx-7cd5a213ca9979ab nav-actions",children:[(0,a.jsx)(d.default,{variant:"ghost",onClick:()=>{let a;a=(0,N.getPreviousStep)("scheduling"),e.push(`/parent/referrals/${f}/onboarding/${a}`)},children:"Back"}),(0,a.jsx)(d.default,{onClick:()=>void J(),children:"Save & Continue"})]}),(0,a.jsx)(r.default,{id:"7cd5a213ca9979ab",children:".step-header.jsx-7cd5a213ca9979ab{flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;margin-bottom:12px;display:flex}.eyebrow.jsx-7cd5a213ca9979ab{color:var(--color-primary-teal);margin:0;font-weight:700}h2.jsx-7cd5a213ca9979ab{color:var(--color-deep-aqua);margin:4px 0}.muted.jsx-7cd5a213ca9979ab{color:var(--color-muted);max-width:760px;margin:0}.save-indicator.jsx-7cd5a213ca9979ab{color:var(--color-muted);font-weight:600}.nav-actions.jsx-7cd5a213ca9979ab{flex-wrap:wrap;justify-content:space-between;gap:10px;margin-top:12px;display:flex}@media (width<=768px){.nav-actions.jsx-7cd5a213ca9979ab{flex-direction:column}}"})]})})}function C(e){let a=e.match(/^(\d{1,2}):(\d{2})$/);if(!a)return null;let r=Number(a[1]),t=Number(a[2]);return Number.isNaN(r)||Number.isNaN(t)||r<0||r>23||t<0||t>59?null:60*r+t}e.s(["default",()=>S],1557)},1554,(e,a,r)=>{let t="/parent/referrals/[id]/onboarding/scheduling";(window.__NEXT_P=window.__NEXT_P||[]).push([t,()=>e.r(1557)]),a.hot&&a.hot.dispose(function(){window.__NEXT_P.push([t])})},88853,e=>{e.v(a=>Promise.all(["static/chunks/ca6b9ab451866ae2.js"].map(a=>e.l(a))).then(()=>a(33811)))},91751,e=>{e.v(a=>Promise.all(["static/chunks/b0bbf6aa740a2457.js"].map(a=>e.l(a))).then(()=>a(23428)))}]);