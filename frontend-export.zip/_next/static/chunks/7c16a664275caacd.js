__turbopack_load_page_chunks__("/parent/resources", [
  "static/chunks/d7a573036505e695.js",
  "static/chunks/382f3ba59a902a64.js",
  "static/chunks/b6758c396527f921.js",
  "static/chunks/bb660b55afbbf809.js",
  "static/chunks/turbopack-b1224f913821679b.js"
])
