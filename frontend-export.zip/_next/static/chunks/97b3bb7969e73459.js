__turbopack_load_page_chunks__("/admin/referrals", [
  "static/chunks/435ef67ecab6bdad.js",
  "static/chunks/382f3ba59a902a64.js",
  "static/chunks/b6758c396527f921.js",
  "static/chunks/bb660b55afbbf809.js",
  "static/chunks/turbopack-01d80e47cfaec48c.js"
])
