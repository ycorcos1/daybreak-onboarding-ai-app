__turbopack_load_page_chunks__("/admin/referrals/[id]", [
  "static/chunks/e480264d596d1e18.js",
  "static/chunks/382f3ba59a902a64.js",
  "static/chunks/b6758c396527f921.js",
  "static/chunks/bb660b55afbbf809.js",
  "static/chunks/turbopack-59b136d3b36b94b1.js"
])
