__turbopack_load_page_chunks__("/admin/resources", [
  "static/chunks/2c9e60a3bf6fdd51.js",
  "static/chunks/382f3ba59a902a64.js",
  "static/chunks/b6758c396527f921.js",
  "static/chunks/bb660b55afbbf809.js",
  "static/chunks/turbopack-e49ef2f4168fbb72.js"
])
