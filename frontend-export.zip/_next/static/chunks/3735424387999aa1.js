(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,20979,e=>{"use strict";var a=e.i(64467);let r=a.gql`
  mutation CreateChildAndReferral($childInput: ChildInput!) {
    createChildAndReferral(childInput: $childInput) {
      child {
        id
        name
        grade
        schoolName
        district
      }
      referral {
        id
        status
        lastCompletedStep
        nextStep
      }
      errors
    }
  }
`,t=a.gql`
  mutation UpdateReferralStep(
    $referralId: ID!
    $stepName: String!
    $stepData: JSON
  ) {
    updateReferralStep(
      referralId: $referralId
      stepName: $stepName
      stepData: $stepData
    ) {
      referral {
        id
        status
        lastCompletedStep
        lastUpdatedStepAt
        nextStep
      }
      errors
    }
  }
`,l=a.gql`
  mutation UpdateParentInfo($referralId: ID!, $parentInfo: ParentInfoInput!) {
    updateParentInfo(referralId: $referralId, parentInfo: $parentInfo) {
      user {
        id
        name
        email
        phone
        address
        languagePreference
        relationshipToChild
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,d=a.gql`
  mutation UpdateChildInfo($referralId: ID!, $childInput: ChildInput!) {
    updateChildInfo(referralId: $referralId, childInput: $childInput) {
      child {
        id
        name
        dob
        ageBand
        grade
        schoolName
        district
        state
        primaryLanguage
        pronouns
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,i=a.gql`
  mutation UpdateClinicalIntake($referralId: ID!, $intakeInput: ClinicalIntakeInput!) {
    updateClinicalIntake(referralId: $referralId, intakeInput: $intakeInput) {
      intakeResponse {
        id
        responses
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,n=a.gql`
  mutation UpdateSchedulingPreferences(
    $referralId: ID!
    $schedulingInput: SchedulingPreferenceInput!
  ) {
    updateSchedulingPreferences(referralId: $referralId, schedulingInput: $schedulingInput) {
      schedulingPreference {
        id
        timezone
        locationPreference
        frequency
        clinicianPreferences
        windows
        suggestedWindows
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,s=a.gql`
  mutation SubmitReferral($referralId: ID!) {
    submitReferral(referralId: $referralId) {
      referral {
        id
        status
        packetStatus
        submittedAt
      }
      errors
    }
  }
`,o=a.gql`
  mutation UpdateInsuranceDetails($referralId: ID!, $insuranceInput: InsuranceDetailInput!) {
    updateInsuranceDetails(referralId: $referralId, insuranceInput: $insuranceInput) {
      insuranceDetail {
        id
        insuranceStatus
        insurerName
        planName
        memberId
        groupId
        policyholderName
        coveragePhone
        coverageWebsite
        source
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,c=a.gql`
  mutation AcceptConsents($referralId: ID!, $consents: [ConsentInput!]!) {
    acceptConsents(referralId: $referralId, consents: $consents) {
      consentRecords {
        id
        consentType
        acceptedAt
        ipAddress
        userAgent
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`;e.s(["ACCEPT_CONSENTS",0,c,"CREATE_CHILD_AND_REFERRAL",0,r,"SUBMIT_REFERRAL",0,s,"UPDATE_CHILD_INFO",0,d,"UPDATE_CLINICAL_INTAKE",0,i,"UPDATE_INSURANCE_DETAILS",0,o,"UPDATE_PARENT_INFO",0,l,"UPDATE_REFERRAL_STEP",0,t,"UPDATE_SCHEDULING_PREFERENCES",0,n])},3308,e=>{"use strict";var a=e.i(41526),r=e.i(22366);e.s(["default",0,function({message:e}){return e?(0,a.jsxs)("div",{role:"alert","aria-live":"assertive",className:"jsx-3a06f6b875d5b277 validation-error",children:[e,(0,a.jsx)(r.default,{id:"3a06f6b875d5b277",children:".validation-error.jsx-3a06f6b875d5b277{color:var(--color-accent-red);border:1px solid var(--color-accent-red);background:#ff4b4b1a;border-radius:12px;padding:10px 12px;font-weight:600}"})]}):null}])},91332,e=>{"use strict";var a=e.i(41526),r=e.i(22366);e.s(["default",0,function({id:e,label:t,options:l,helperText:d,error:i,required:n,...s}){let o=d?`${e}-helper`:void 0,c=i?`${e}-error`:void 0,u=l.some(e=>""===e.value);return(0,a.jsxs)("div",{className:"jsx-734334db1d082c81 select-field",children:[(0,a.jsxs)("label",{htmlFor:e,className:"jsx-734334db1d082c81 db-input-label",children:[t,n?(0,a.jsx)("span",{className:"jsx-734334db1d082c81 db-required",children:"*"}):null]}),(0,a.jsxs)("select",{id:e,"aria-invalid":!!i,"aria-describedby":i?c:o,required:n,...s,className:"jsx-734334db1d082c81 "+(s&&null!=s.className&&s.className||`db-select ${i?"db-input-error":""}`),children:[void 0!==s.defaultValue||u?null:(0,a.jsx)("option",{value:"",className:"jsx-734334db1d082c81",children:"Select..."}),l.map(e=>(0,a.jsx)("option",{value:e.value,className:"jsx-734334db1d082c81",children:e.label},e.value))]}),d&&!i?(0,a.jsx)("p",{id:o,className:"jsx-734334db1d082c81 db-input-helper",children:d}):null,i?(0,a.jsx)("p",{id:c,className:"jsx-734334db1d082c81 db-input-error-text",children:i}):null,(0,a.jsx)(r.default,{id:"734334db1d082c81",children:".db-input-label.jsx-734334db1d082c81{color:var(--color-deep-aqua);margin-bottom:6px;font-weight:600;display:block}.db-required.jsx-734334db1d082c81{color:var(--color-accent-red);margin-left:4px}.db-select.jsx-734334db1d082c81{border:1px solid var(--color-border);width:100%;height:46px;color:var(--color-text);background:#fff;border-radius:10px;padding:0 12px;font-size:15px;transition:border-color .12s,box-shadow .12s}.db-select.jsx-734334db1d082c81:focus{border-color:var(--color-primary-teal);outline:none;box-shadow:0 0 0 3px #0096a833}.db-input-error.jsx-734334db1d082c81{border-color:var(--color-accent-red)}.db-input-helper.jsx-734334db1d082c81{color:var(--color-muted);margin-top:6px;font-size:13px}.db-input-error-text.jsx-734334db1d082c81{color:var(--color-accent-red);margin-top:6px;font-size:13px}"})]})}])},97679,e=>{"use strict";var a=e.i(41526),r=e.i(22366);function t({label:e,id:t,helperText:l,error:d,required:i,...n}){let s=l?`${t}-helper`:void 0,o=d?`${t}-error`:void 0;return(0,a.jsxs)(a.Fragment,{children:[(0,a.jsxs)("label",{htmlFor:t,className:"jsx-59fec5f1f0edea5 db-input-label",children:[e,i?(0,a.jsx)("span",{className:"jsx-59fec5f1f0edea5 db-required",children:"*"}):null]}),(0,a.jsx)("input",{id:t,"aria-invalid":!!d,"aria-describedby":d?o:s,required:i,...n,className:"jsx-59fec5f1f0edea5 "+(n&&null!=n.className&&n.className||`db-input ${d?"db-input-error":""}`)}),l&&!d?(0,a.jsx)("p",{id:s,className:"jsx-59fec5f1f0edea5 db-input-helper",children:l}):null,d?(0,a.jsx)("p",{id:o,className:"jsx-59fec5f1f0edea5 db-input-error-text",children:d}):null,(0,a.jsx)(r.default,{id:"59fec5f1f0edea5",children:".db-input-label.jsx-59fec5f1f0edea5{color:var(--color-deep-aqua);margin-bottom:4px;font-weight:600;display:block}.db-required.jsx-59fec5f1f0edea5{color:var(--color-accent-red);margin-left:4px}.db-input.jsx-59fec5f1f0edea5{border:1px solid var(--color-border);width:100%;height:46px;color:var(--color-text);background:#fff;border-radius:10px;padding:0 58px 0 14px;font-size:15px;transition:border-color .12s,box-shadow .12s}.db-input.jsx-59fec5f1f0edea5:focus{border-color:var(--color-primary-teal);outline:none;box-shadow:0 0 0 3px #0096a833}.db-input.jsx-59fec5f1f0edea5::placeholder{color:var(--color-muted)}.db-input-error.jsx-59fec5f1f0edea5{border-color:var(--color-accent-red)}.db-input-helper.jsx-59fec5f1f0edea5{color:var(--color-muted);margin-top:6px;font-size:13px}.db-input-error-text.jsx-59fec5f1f0edea5{color:var(--color-accent-red);margin-top:6px;font-size:13px}"})]})}e.s(["TextInput",()=>t,"default",0,t])},3086,e=>{"use strict";var a=e.i(41526),r=e.i(97679);e.s(["default",0,function(e){return(0,a.jsx)(r.default,{...e})}])},23569,e=>{"use strict";var a=e.i(41526),r=e.i(97679);e.s(["default",0,function({id:e,label:t,value:l,onChange:d,onBlur:i,required:n,disabled:s,error:o,helperText:c,placeholder:u}){return(0,a.jsx)(r.default,{id:e,label:t,value:l,onChange:e=>{let a=e.target.value.replace(/[^\d]/g,""),r=[a.slice(0,3),a.slice(3,6),a.slice(6,10)].filter(e=>e.length>0);d(0===r.length?"":1===r.length?r[0]:2===r.length?`${r[0]}-${r[1]}`:`${r[0]}-${r[1]}-${r[2]}`)},onBlur:i,required:n,disabled:s,error:o,helperText:c,placeholder:u??"555-123-4567",inputMode:"tel",pattern:"^\\\\d{3}-\\\\d{3}-\\\\d{4}$"})}])},42008,(e,a,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0});var t={VALID_LOADERS:function(){return d},imageConfigDefault:function(){return i}};for(var l in t)Object.defineProperty(r,l,{enumerable:!0,get:t[l]});let d=["default","imgix","cloudinary","akamai","custom"],i={deviceSizes:[640,750,828,1080,1200,1920,2048,3840],imageSizes:[32,48,64,96,128,256,384],path:"/_next/image",loader:"default",loaderFile:"",domains:[],disableStaticImages:!1,minimumCacheTTL:14400,formats:["image/webp"],maximumRedirects:3,dangerouslyAllowLocalIP:!1,dangerouslyAllowSVG:!1,contentSecurityPolicy:"script-src 'none'; frame-src 'none'; sandbox;",contentDispositionType:"attachment",localPatterns:void 0,remotePatterns:[],qualities:[75],unoptimized:!1}},78361,(e,a,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"ImageConfigContext",{enumerable:!0,get:function(){return d}});let t=e.r(1646)._(e.r(73658)),l=e.r(42008),d=t.default.createContext(l.imageConfigDefault)},16416,e=>{"use strict";var a=e.i(41526),r=e.i(22366),t=e.i(9793),l=e.i(39491),d=e.i(73658),i=e.i(27941),n=e.i(83724),s=e.i(53949),o=e.i(93962),c=e.i(56421),u=e.i(76245),p=e.i(20979),f=e.i(3086),m=e.i(23569),h=e.i(91332),b=e.i(3308);function x(){let e=(0,l.useRouter)(),{id:x}=e.query,g=(0,d.useMemo)(()=>x||"",[x]),{referral:j,loading:v,error:I}=(0,c.default)(g),[S]=(0,t.useMutation)(p.UPDATE_PARENT_INFO),[C,N]=(0,d.useState)(""),[P,$]=(0,d.useState)("idle"),y=(0,d.useRef)(!1),{register:T,handleSubmit:A,reset:E,watch:_,setValue:R,formState:{errors:q,isDirty:w}}=(0,i.useForm)({mode:"onBlur",defaultValues:{name:"",relationshipToChild:"",email:"",phone:"",address:"",languagePreference:""}});(0,d.useEffect)(()=>{j&&(E({name:j.user?.name??"",relationshipToChild:j.user?.relationshipToChild??"",email:j.user?.email??"",phone:j.user?.phone??"",address:j.user?.address??"",languagePreference:j.user?.languagePreference??""}),y.current=!0)},[j,E]);let D=async e=>{if(g){N(""),$("saving");try{let{data:a}=await S({variables:{referralId:g,parentInfo:{name:e.name,phone:e.phone,address:e.address,languagePreference:e.languagePreference,relationshipToChild:e.relationshipToChild}}}),r=a?.updateParentInfo?.errors;if(r?.length){N(r[0]),$("error");return}$("saved"),setTimeout(()=>$("idle"),1200)}catch{N("Unable to save your info right now. Please try again."),$("error")}}},U=_();(0,d.useEffect)(()=>{if(!y.current||!g||!w)return;let e=setTimeout(()=>{D({...U,email:U.email})},700);return()=>clearTimeout(e)},[g,JSON.stringify(U),w]);let k=async a=>{await D(a);let r=(0,u.getNextStep)("parent-info");e.push(`/parent/referrals/${g}/onboarding/${r}`)};return v?(0,a.jsx)(n.default,{requireRole:"parent",children:(0,a.jsx)("div",{style:{padding:"48px 24px",textAlign:"center"},children:"Loading referral…"})}):I||!j?(0,a.jsx)(n.default,{requireRole:"parent",children:(0,a.jsxs)("div",{style:{padding:"48px 24px",textAlign:"center"},children:[(0,a.jsx)("p",{children:"Unable to load this referral."}),(0,a.jsx)(o.default,{onClick:()=>e.push("/parent/dashboard"),children:"Back to dashboard"})]})}):(0,a.jsx)(n.default,{requireRole:"parent",children:(0,a.jsxs)(s.default,{referralId:j.id,currentStep:"parent-info",onStepSelect:a=>"parent-info"===a?void 0:void e.push(`/parent/referrals/${j.id}/onboarding/${a}`),children:[(0,a.jsxs)("div",{className:"jsx-a2baa3ac274c110d step-header",children:[(0,a.jsxs)("div",{className:"jsx-a2baa3ac274c110d",children:[(0,a.jsx)("p",{className:"jsx-a2baa3ac274c110d eyebrow",children:"Step 1 of 9"}),(0,a.jsx)("h2",{className:"jsx-a2baa3ac274c110d",children:"About you"}),(0,a.jsx)("p",{className:"jsx-a2baa3ac274c110d muted",children:"We’ll use your contact information to coordinate care and keep you updated. Your answers save automatically."})]}),(0,a.jsxs)("div",{"aria-live":"polite",className:"jsx-a2baa3ac274c110d save-indicator",children:["saving"===P&&"Saving…","saved"===P&&"Saved","error"===P&&"Save error"]})]}),C?(0,a.jsx)(b.default,{message:C}):null,(0,a.jsxs)("form",{onSubmit:A(k),noValidate:!0,"aria-label":"Parent information form",className:"jsx-a2baa3ac274c110d form-grid",children:[(0,a.jsx)(f.default,{id:"name",label:"Full name",required:!0,error:q.name?.message,...T("name",{required:"Your name is required"})}),(0,a.jsx)(h.default,{id:"relationshipToChild",label:"Relationship to child",required:!0,error:q.relationshipToChild?.message,...T("relationshipToChild",{required:"Relationship is required"}),options:[{value:"Parent",label:"Parent"},{value:"Legal guardian",label:"Legal guardian"},{value:"Grandparent",label:"Grandparent"},{value:"Other",label:"Other"}]}),(0,a.jsx)(f.default,{id:"email",label:"Email",type:"email",required:!0,disabled:!0,helperText:"Email comes from your account and can be updated in settings.",...T("email")}),(0,a.jsx)(m.default,{id:"phone",label:"Phone number",required:!0,value:_("phone"),onChange:e=>R("phone",e,{shouldValidate:!0}),onBlur:()=>void D({..._(),phone:_("phone")}),error:q.phone?.message,helperText:"We’ll use this to coordinate next steps."}),(0,a.jsx)(f.default,{id:"address",label:"Home address (optional)",placeholder:"Street, city, state",error:q.address?.message,...T("address")}),(0,a.jsx)(h.default,{id:"languagePreference",label:"Language preference (optional)",options:[{value:"",label:"Select..."},{value:"English",label:"English"},{value:"Spanish",label:"Spanish"},{value:"Other",label:"Other"}],...T("languagePreference")}),(0,a.jsxs)("div",{className:"jsx-a2baa3ac274c110d actions",children:[(0,a.jsx)(o.default,{type:"button",variant:"ghost",onClick:()=>{e.push("/parent/dashboard")},children:"Save & exit"}),(0,a.jsx)(o.default,{type:"submit",children:"Save & Continue"})]})]}),(0,a.jsx)(r.default,{id:"a2baa3ac274c110d",children:".step-header.jsx-a2baa3ac274c110d{flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;margin-bottom:12px;display:flex}.eyebrow.jsx-a2baa3ac274c110d{color:var(--color-primary-teal);margin:0;font-weight:700}h2.jsx-a2baa3ac274c110d{color:var(--color-deep-aqua);margin:4px 0}.muted.jsx-a2baa3ac274c110d{color:var(--color-muted);margin:0}.save-indicator.jsx-a2baa3ac274c110d{color:var(--color-muted);font-weight:600}.form-grid.jsx-a2baa3ac274c110d{grid-template-columns:1fr;row-gap:10px;margin-top:8px;display:grid}.form-grid.jsx-a2baa3ac274c110d .db-input-label{margin-bottom:4px}.actions.jsx-a2baa3ac274c110d{grid-column:1/-1;justify-content:flex-end;gap:12px;margin-top:8px;display:flex}"})]})})}e.s(["default",()=>x])},11071,(e,a,r)=>{let t="/parent/referrals/[id]/onboarding/parent-info";(window.__NEXT_P=window.__NEXT_P||[]).push([t,()=>e.r(16416)]),a.hot&&a.hot.dispose(function(){window.__NEXT_P.push([t])})},88853,e=>{e.v(a=>Promise.all(["static/chunks/ca6b9ab451866ae2.js"].map(a=>e.l(a))).then(()=>a(33811)))},91751,e=>{e.v(a=>Promise.all(["static/chunks/b0bbf6aa740a2457.js"].map(a=>e.l(a))).then(()=>a(23428)))}]);