__turbopack_load_page_chunks__("/admin/resources/new", [
  "static/chunks/13517e7bc9acfad8.js",
  "static/chunks/382f3ba59a902a64.js",
  "static/chunks/bb660b55afbbf809.js",
  "static/chunks/b6758c396527f921.js",
  "static/chunks/turbopack-4785a95fc591c746.js"
])
