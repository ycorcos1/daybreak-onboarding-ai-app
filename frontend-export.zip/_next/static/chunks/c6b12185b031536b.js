(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,76245,47141,e=>{"use strict";let t=["parent-info","child-info","screener","intake","insurance","cost","scheduling","consent","review"];function r(e){let r=t.indexOf(e);return -1===r||r===t.length-1?e:t[r+1]}function n(e){let r=t.indexOf(e);return r<=0?e:t[r-1]}e.s(["ONBOARDING_STEPS",0,t,"STEP_LABELS",0,{"parent-info":"Parent info","child-info":"Child info",screener:"AI screener",intake:"Intake",insurance:"Insurance",cost:"Cost",scheduling:"Scheduling",consent:"Consent",review:"Review"},"getNextStep",()=>r,"getPreviousStep",()=>n],76245);var o=e.i(41526),s=e.i(22366),i=e.i(73658),a=e.i(9793),u=e.i(9910);function c({message:e}){var t;let r="parent"===e.senderType,n="ai"===e.senderType;return(0,o.jsxs)("div",{className:s.default.dynamic([["f44e402da0172a30",[n?"#f2f2f2":"#fff3e0"]]])+" "+`message ${r?"message--parent":"message--other"}`,children:[(0,o.jsxs)("div",{className:s.default.dynamic([["f44e402da0172a30",[n?"#f2f2f2":"#fff3e0"]]])+" header",children:[(0,o.jsx)("span",{className:s.default.dynamic([["f44e402da0172a30",[n?"#f2f2f2":"#fff3e0"]]])+" sender",children:"parent"===(t=e.senderType)?"You":"admin"===t?"Support Team":"ai"===t?"AI Assistant":t}),(0,o.jsx)("span",{className:s.default.dynamic([["f44e402da0172a30",[n?"#f2f2f2":"#fff3e0"]]])+" time",children:new Date(e.createdAt).toLocaleTimeString()})]}),(0,o.jsx)("p",{className:s.default.dynamic([["f44e402da0172a30",[n?"#f2f2f2":"#fff3e0"]]])+" text",children:e.messageText}),(0,o.jsx)(s.default,{id:"f44e402da0172a30",dynamic:[n?"#f2f2f2":"#fff3e0"],children:`.message.__jsx-style-dynamic-selector{background:#fff3e0;border-radius:12px;align-self:flex-start;max-width:78%;padding:10px 12px}.message--parent.__jsx-style-dynamic-selector{background:#e3f2fd;align-self:flex-end}.message--other.__jsx-style-dynamic-selector{background:${n?"#f2f2f2":"#fff3e0"}}.header.__jsx-style-dynamic-selector{justify-content:space-between;gap:8px;margin-bottom:4px;font-size:12px;display:flex}.sender.__jsx-style-dynamic-selector{color:var(--color-deep-aqua);font-weight:700}.time.__jsx-style-dynamic-selector{color:var(--color-muted)}.text.__jsx-style-dynamic-selector{color:var(--color-text);margin:0;font-size:14px;line-height:1.5}`})]})}function d({messages:e}){return(0,o.jsxs)("div",{className:"jsx-23fd9f92e303b5ea transcript",children:[e.map(e=>(0,o.jsx)(c,{message:e},e.id)),(0,o.jsx)(s.default,{id:"23fd9f92e303b5ea",children:".transcript.jsx-23fd9f92e303b5ea{flex-direction:column;gap:10px;display:flex}"})]})}var l=e.i(93962);function f({value:e,onChange:t,onSend:r,disabled:n,placeholder:i}){return(0,o.jsxs)("div",{className:"jsx-295133501a38850b chat-input",children:[(0,o.jsx)("textarea",{value:e,onChange:e=>t(e.target.value),onKeyDown:e=>{"Enter"!==e.key||e.shiftKey||(e.preventDefault(),r())},placeholder:i||"Type a message",rows:2,disabled:n,className:"jsx-295133501a38850b"}),(0,o.jsx)(l.default,{size:"sm",onClick:r,disabled:n||!e.trim(),children:"Send"}),(0,o.jsx)(s.default,{id:"295133501a38850b",children:".chat-input.jsx-295133501a38850b{align-items:flex-end;gap:8px;display:flex}textarea.jsx-295133501a38850b{border:1px solid var(--color-border);resize:none;border-radius:10px;flex:1;min-height:64px;padding:10px;font-family:inherit;font-size:14px}textarea.jsx-295133501a38850b:focus{border-color:var(--color-primary-teal);outline:none;box-shadow:0 0 0 3px #0096a82e}"})]})}var p=e.i(41921),h=e.i(63688);function m({referralId:e}){let[t,r]=(0,i.useState)(!1),[n,c]=(0,i.useState)(""),{data:l,loading:m,error:y,refetch:b,startPolling:g,stopPolling:x}=(0,u.useQuery)(p.MY_SUPPORT_CHATS_QUERY,{variables:{referralId:e},skip:!t,pollInterval:0});(0,i.useEffect)(()=>(t?g(3e3):x(),()=>x()),[t,g,x]);let[v,{loading:_}]=(0,a.useMutation)(h.SEND_SUPPORT_MESSAGE_MUTATION,{onCompleted:()=>{c(""),b()}}),S=l?.mySupportChats??[],j=(0,i.useMemo)(()=>S[0],[S]),w=async()=>{n.trim()&&await v({variables:{referralId:e,messageText:n}})};return(0,o.jsxs)(o.Fragment,{children:[t?(0,o.jsxs)("div",{className:"jsx-b5386d13c1d0bd47 chat-drawer",children:[(0,o.jsxs)("div",{className:"jsx-b5386d13c1d0bd47 drawer-header",children:[(0,o.jsxs)("div",{className:"jsx-b5386d13c1d0bd47",children:[(0,o.jsx)("p",{className:"jsx-b5386d13c1d0bd47 eyebrow",children:"Support chat"}),(0,o.jsx)("h4",{className:"jsx-b5386d13c1d0bd47",children:"We’re here to help"}),(0,o.jsx)("p",{className:"jsx-b5386d13c1d0bd47 muted",children:"Not for emergencies. If this is a crisis, please call 911 or 988."})]}),(0,o.jsx)("button",{type:"button",onClick:()=>r(!1),className:"jsx-b5386d13c1d0bd47 close-btn",children:"✕"})]}),(0,o.jsxs)("div",{className:"jsx-b5386d13c1d0bd47 drawer-body",children:[m&&(0,o.jsx)("p",{className:"jsx-b5386d13c1d0bd47 muted",children:"Loading messages…"}),y&&(0,o.jsx)("p",{className:"jsx-b5386d13c1d0bd47 error",children:"Unable to load chat."}),!m&&!j&&(0,o.jsx)("p",{className:"jsx-b5386d13c1d0bd47 muted",children:"Ask a question about the process, forms, insurance, or scheduling. We’ll respond here."}),j?(0,o.jsx)(d,{messages:j.supportChatMessages}):null]}),(0,o.jsxs)("div",{className:"jsx-b5386d13c1d0bd47 drawer-footer",children:[(0,o.jsx)(f,{value:n,onChange:c,onSend:w,disabled:_,placeholder:"Type your message…"}),(0,o.jsx)("p",{className:"jsx-b5386d13c1d0bd47 micro muted",children:"Operator status: Available"})]})]}):(0,o.jsx)("button",{type:"button",onClick:()=>r(!0),className:"jsx-b5386d13c1d0bd47 chat-pill",children:"💬 Need help?"}),(0,o.jsx)(s.default,{id:"b5386d13c1d0bd47",children:".chat-pill.jsx-b5386d13c1d0bd47{z-index:1000;background:var(--color-primary-teal);color:#fff;cursor:pointer;border:none;border-radius:999px;padding:12px 16px;font-weight:700;position:fixed;bottom:18px;right:18px;box-shadow:0 10px 28px #0096a847}.chat-drawer.jsx-b5386d13c1d0bd47{z-index:1000;border:1px solid var(--color-border);background:#fff;border-radius:16px;flex-direction:column;width:360px;max-height:70vh;display:flex;position:fixed;bottom:18px;right:18px;overflow:hidden;box-shadow:0 14px 38px #0000002e}.drawer-header.jsx-b5386d13c1d0bd47{border-bottom:1px solid var(--color-border);justify-content:space-between;gap:10px;padding:14px;display:flex}h4.jsx-b5386d13c1d0bd47{color:var(--color-deep-aqua);margin:4px 0}.muted.jsx-b5386d13c1d0bd47{color:var(--color-muted);margin:0}.eyebrow.jsx-b5386d13c1d0bd47{color:var(--color-primary-teal);margin:0;font-size:12px;font-weight:700}.drawer-body.jsx-b5386d13c1d0bd47{flex-direction:column;flex:1;gap:10px;padding:14px;display:flex;overflow-y:auto}.drawer-footer.jsx-b5386d13c1d0bd47{border-top:1px solid var(--color-border);background:#fafafa;padding:12px}.close-btn.jsx-b5386d13c1d0bd47{cursor:pointer;color:var(--color-muted);background:0 0;border:none;font-size:18px;line-height:1}.error.jsx-b5386d13c1d0bd47{color:var(--color-accent-red);margin:0}.micro.jsx-b5386d13c1d0bd47{margin:6px 2px 0;font-size:12px}@media (width<=520px){.chat-drawer.jsx-b5386d13c1d0bd47{width:calc(100vw - 24px);bottom:12px;right:12px}}"})]})}e.s(["default",()=>m],47141)},50107,e=>{"use strict";var t=e.i(41526),r=e.i(22366);e.s(["default",0,function({children:e,className:n,padding:o="24px",onClick:s,role:i}){return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("div",{style:{padding:o},onClick:s,role:i,className:r.default.dynamic([["e5888aa2411fc9da",[s?"pointer":"default"]]])+" "+`db-card ${n??""}`,children:e}),(0,t.jsx)(r.default,{id:"e5888aa2411fc9da",dynamic:[s?"pointer":"default"],children:`.db-card.__jsx-style-dynamic-selector{background:var(--color-card);border:1px solid var(--color-border);box-shadow:var(--shadow-soft);cursor:${s?"pointer":"default"};border-radius:16px}`})]})}])},26576,(e,t,r)=>{var n={229:function(e){var t,r,n,o=e.exports={};function s(){throw Error("setTimeout has not been defined")}function i(){throw Error("clearTimeout has not been defined")}try{t="function"==typeof setTimeout?setTimeout:s}catch(e){t=s}try{r="function"==typeof clearTimeout?clearTimeout:i}catch(e){r=i}function a(e){if(t===setTimeout)return setTimeout(e,0);if((t===s||!t)&&setTimeout)return t=setTimeout,setTimeout(e,0);try{return t(e,0)}catch(r){try{return t.call(null,e,0)}catch(r){return t.call(this,e,0)}}}var u=[],c=!1,d=-1;function l(){c&&n&&(c=!1,n.length?u=n.concat(u):d=-1,u.length&&f())}function f(){if(!c){var e=a(l);c=!0;for(var t=u.length;t;){for(n=u,u=[];++d<t;)n&&n[d].run();d=-1,t=u.length}n=null,c=!1,function(e){if(r===clearTimeout)return clearTimeout(e);if((r===i||!r)&&clearTimeout)return r=clearTimeout,clearTimeout(e);try{r(e)}catch(t){try{return r.call(null,e)}catch(t){return r.call(this,e)}}}(e)}}function p(e,t){this.fun=e,this.array=t}function h(){}o.nextTick=function(e){var t=Array(arguments.length-1);if(arguments.length>1)for(var r=1;r<arguments.length;r++)t[r-1]=arguments[r];u.push(new p(e,t)),1!==u.length||c||a(f)},p.prototype.run=function(){this.fun.apply(null,this.array)},o.title="browser",o.browser=!0,o.env={},o.argv=[],o.version="",o.versions={},o.on=h,o.addListener=h,o.once=h,o.off=h,o.removeListener=h,o.removeAllListeners=h,o.emit=h,o.prependListener=h,o.prependOnceListener=h,o.listeners=function(e){return[]},o.binding=function(e){throw Error("process.binding is not supported")},o.cwd=function(){return"/"},o.chdir=function(e){throw Error("process.chdir is not supported")},o.umask=function(){return 0}}},o={};function s(e){var t=o[e];if(void 0!==t)return t.exports;var r=o[e]={exports:{}},i=!0;try{n[e](r,r.exports,s),i=!1}finally{i&&delete o[e]}return r.exports}s.ab="/ROOT/Desktop/gauntlet-workspace/daybreak-onboarding-ai-app/frontend/node_modules/next/dist/compiled/process/",t.exports=s(229)},6725,(e,t,r)=>{"use strict";var n,o;t.exports=(null==(n=e.g.process)?void 0:n.env)&&"object"==typeof(null==(o=e.g.process)?void 0:o.env)?e.g.process:e.r(26576)},1646,(e,t,r)=>{"use strict";r._=function(e){return e&&e.__esModule?e:{default:e}}},75625,(e,t,r)=>{"use strict";var n=Symbol.for("react.transitional.element");function o(e,t,r){var o=null;if(void 0!==r&&(o=""+r),void 0!==t.key&&(o=""+t.key),"key"in t)for(var s in r={},t)"key"!==s&&(r[s]=t[s]);else r=t;return{$$typeof:n,type:e,key:o,ref:void 0!==(t=r.ref)?t:null,props:r}}r.Fragment=Symbol.for("react.fragment"),r.jsx=o,r.jsxs=o},41526,(e,t,r)=>{"use strict";t.exports=e.r(75625)},78353,(e,t,r)=>{"use strict";var n=e.i(6725),o=Symbol.for("react.transitional.element"),s=Symbol.for("react.portal"),i=Symbol.for("react.fragment"),a=Symbol.for("react.strict_mode"),u=Symbol.for("react.profiler"),c=Symbol.for("react.consumer"),d=Symbol.for("react.context"),l=Symbol.for("react.forward_ref"),f=Symbol.for("react.suspense"),p=Symbol.for("react.memo"),h=Symbol.for("react.lazy"),m=Symbol.for("react.activity"),y=Symbol.iterator,b={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},g=Object.assign,x={};function v(e,t,r){this.props=e,this.context=t,this.refs=x,this.updater=r||b}function _(){}function S(e,t,r){this.props=e,this.context=t,this.refs=x,this.updater=r||b}v.prototype.isReactComponent={},v.prototype.setState=function(e,t){if("object"!=typeof e&&"function"!=typeof e&&null!=e)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")},v.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")},_.prototype=v.prototype;var j=S.prototype=new _;j.constructor=S,g(j,v.prototype),j.isPureReactComponent=!0;var w=Array.isArray;function R(){}var E={H:null,A:null,T:null,S:null},T=Object.prototype.hasOwnProperty;function A(e,t,r){var n=r.ref;return{$$typeof:o,type:e,key:t,ref:void 0!==n?n:null,props:r}}function C(e){return"object"==typeof e&&null!==e&&e.$$typeof===o}var k=/\/+/g;function I(e,t){var r,n;return"object"==typeof e&&null!==e&&null!=e.key?(r=""+e.key,n={"=":"=0",":":"=2"},"$"+r.replace(/[=:]/g,function(e){return n[e]})):t.toString(36)}function N(e,t,r){if(null==e)return e;var n=[],i=0;return!function e(t,r,n,i,a){var u,c,d,l=typeof t;("undefined"===l||"boolean"===l)&&(t=null);var f=!1;if(null===t)f=!0;else switch(l){case"bigint":case"string":case"number":f=!0;break;case"object":switch(t.$$typeof){case o:case s:f=!0;break;case h:return e((f=t._init)(t._payload),r,n,i,a)}}if(f)return a=a(t),f=""===i?"."+I(t,0):i,w(a)?(n="",null!=f&&(n=f.replace(k,"$&/")+"/"),e(a,r,n,"",function(e){return e})):null!=a&&(C(a)&&(u=a,c=n+(null==a.key||t&&t.key===a.key?"":(""+a.key).replace(k,"$&/")+"/")+f,a=A(u.type,c,u.props)),r.push(a)),1;f=0;var p=""===i?".":i+":";if(w(t))for(var m=0;m<t.length;m++)l=p+I(i=t[m],m),f+=e(i,r,n,l,a);else if("function"==typeof(m=null===(d=t)||"object"!=typeof d?null:"function"==typeof(d=y&&d[y]||d["@@iterator"])?d:null))for(t=m.call(t),m=0;!(i=t.next()).done;)l=p+I(i=i.value,m++),f+=e(i,r,n,l,a);else if("object"===l){if("function"==typeof t.then)return e(function(e){switch(e.status){case"fulfilled":return e.value;case"rejected":throw e.reason;default:switch("string"==typeof e.status?e.then(R,R):(e.status="pending",e.then(function(t){"pending"===e.status&&(e.status="fulfilled",e.value=t)},function(t){"pending"===e.status&&(e.status="rejected",e.reason=t)})),e.status){case"fulfilled":return e.value;case"rejected":throw e.reason}}throw e}(t),r,n,i,a);throw Error("Objects are not valid as a React child (found: "+("[object Object]"===(r=String(t))?"object with keys {"+Object.keys(t).join(", ")+"}":r)+"). If you meant to render a collection of children, use an array instead.")}return f}(e,n,"","",function(e){return t.call(r,e,i++)}),n}function O(e){if(-1===e._status){var t=e._result;(t=t()).then(function(t){(0===e._status||-1===e._status)&&(e._status=1,e._result=t)},function(t){(0===e._status||-1===e._status)&&(e._status=2,e._result=t)}),-1===e._status&&(e._status=0,e._result=t)}if(1===e._status)return e._result.default;throw e._result}var P="function"==typeof reportError?reportError:function(e){if("object"==typeof window&&"function"==typeof window.ErrorEvent){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:"object"==typeof e&&null!==e&&"string"==typeof e.message?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if("object"==typeof n.default&&"function"==typeof n.default.emit)return void n.default.emit("uncaughtException",e);console.error(e)};r.Activity=m,r.Children={map:N,forEach:function(e,t,r){N(e,function(){t.apply(this,arguments)},r)},count:function(e){var t=0;return N(e,function(){t++}),t},toArray:function(e){return N(e,function(e){return e})||[]},only:function(e){if(!C(e))throw Error("React.Children.only expected to receive a single React element child.");return e}},r.Component=v,r.Fragment=i,r.Profiler=u,r.PureComponent=S,r.StrictMode=a,r.Suspense=f,r.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=E,r.__COMPILER_RUNTIME={__proto__:null,c:function(e){return E.H.useMemoCache(e)}},r.cache=function(e){return function(){return e.apply(null,arguments)}},r.cacheSignal=function(){return null},r.cloneElement=function(e,t,r){if(null==e)throw Error("The argument must be a React element, but you passed "+e+".");var n=g({},e.props),o=e.key;if(null!=t)for(s in void 0!==t.key&&(o=""+t.key),t)T.call(t,s)&&"key"!==s&&"__self"!==s&&"__source"!==s&&("ref"!==s||void 0!==t.ref)&&(n[s]=t[s]);var s=arguments.length-2;if(1===s)n.children=r;else if(1<s){for(var i=Array(s),a=0;a<s;a++)i[a]=arguments[a+2];n.children=i}return A(e.type,o,n)},r.createContext=function(e){return(e={$$typeof:d,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null}).Provider=e,e.Consumer={$$typeof:c,_context:e},e},r.createElement=function(e,t,r){var n,o={},s=null;if(null!=t)for(n in void 0!==t.key&&(s=""+t.key),t)T.call(t,n)&&"key"!==n&&"__self"!==n&&"__source"!==n&&(o[n]=t[n]);var i=arguments.length-2;if(1===i)o.children=r;else if(1<i){for(var a=Array(i),u=0;u<i;u++)a[u]=arguments[u+2];o.children=a}if(e&&e.defaultProps)for(n in i=e.defaultProps)void 0===o[n]&&(o[n]=i[n]);return A(e,s,o)},r.createRef=function(){return{current:null}},r.forwardRef=function(e){return{$$typeof:l,render:e}},r.isValidElement=C,r.lazy=function(e){return{$$typeof:h,_payload:{_status:-1,_result:e},_init:O}},r.memo=function(e,t){return{$$typeof:p,type:e,compare:void 0===t?null:t}},r.startTransition=function(e){var t=E.T,r={};E.T=r;try{var n=e(),o=E.S;null!==o&&o(r,n),"object"==typeof n&&null!==n&&"function"==typeof n.then&&n.then(R,P)}catch(e){P(e)}finally{null!==t&&null!==r.types&&(t.types=r.types),E.T=t}},r.unstable_useCacheRefresh=function(){return E.H.useCacheRefresh()},r.use=function(e){return E.H.use(e)},r.useActionState=function(e,t,r){return E.H.useActionState(e,t,r)},r.useCallback=function(e,t){return E.H.useCallback(e,t)},r.useContext=function(e){return E.H.useContext(e)},r.useDebugValue=function(){},r.useDeferredValue=function(e,t){return E.H.useDeferredValue(e,t)},r.useEffect=function(e,t){return E.H.useEffect(e,t)},r.useEffectEvent=function(e){return E.H.useEffectEvent(e)},r.useId=function(){return E.H.useId()},r.useImperativeHandle=function(e,t,r){return E.H.useImperativeHandle(e,t,r)},r.useInsertionEffect=function(e,t){return E.H.useInsertionEffect(e,t)},r.useLayoutEffect=function(e,t){return E.H.useLayoutEffect(e,t)},r.useMemo=function(e,t){return E.H.useMemo(e,t)},r.useOptimistic=function(e,t){return E.H.useOptimistic(e,t)},r.useReducer=function(e,t,r){return E.H.useReducer(e,t,r)},r.useRef=function(e){return E.H.useRef(e)},r.useState=function(e){return E.H.useState(e)},r.useSyncExternalStore=function(e,t,r){return E.H.useSyncExternalStore(e,t,r)},r.useTransition=function(){return E.H.useTransition()},r.version="19.2.0"},73658,(e,t,r)=>{"use strict";t.exports=e.r(78353)},75281,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"HeadManagerContext",{enumerable:!0,get:function(){return n}});let n=e.r(1646)._(e.r(73658)).default.createContext({})},30362,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"warnOnce",{enumerable:!0,get:function(){return n}});let n=e=>{}},94008,(e,t,r)=>{"use strict";function n(e){if("function"!=typeof WeakMap)return null;var t=new WeakMap,r=new WeakMap;return(n=function(e){return e?r:t})(e)}r._=function(e,t){if(!t&&e&&e.__esModule)return e;if(null===e||"object"!=typeof e&&"function"!=typeof e)return{default:e};var r=n(t);if(r&&r.has(e))return r.get(e);var o={__proto__:null},s=Object.defineProperty&&Object.getOwnPropertyDescriptor;for(var i in e)if("default"!==i&&Object.prototype.hasOwnProperty.call(e,i)){var a=s?Object.getOwnPropertyDescriptor(e,i):null;a&&(a.get||a.set)?Object.defineProperty(o,i,a):o[i]=e[i]}return o.default=e,r&&r.set(e,o),o}},18465,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0});var n={DecodeError:function(){return b},MiddlewareNotFoundError:function(){return _},MissingStaticPage:function(){return v},NormalizeError:function(){return g},PageNotFoundError:function(){return x},SP:function(){return m},ST:function(){return y},WEB_VITALS:function(){return s},execOnce:function(){return i},getDisplayName:function(){return l},getLocationOrigin:function(){return c},getURL:function(){return d},isAbsoluteUrl:function(){return u},isResSent:function(){return f},loadGetInitialProps:function(){return h},normalizeRepeatedSlashes:function(){return p},stringifyError:function(){return S}};for(var o in n)Object.defineProperty(r,o,{enumerable:!0,get:n[o]});let s=["CLS","FCP","FID","INP","LCP","TTFB"];function i(e){let t,r=!1;return(...n)=>(r||(r=!0,t=e(...n)),t)}let a=/^[a-zA-Z][a-zA-Z\d+\-.]*?:/,u=e=>a.test(e);function c(){let{protocol:e,hostname:t,port:r}=window.location;return`${e}//${t}${r?":"+r:""}`}function d(){let{href:e}=window.location,t=c();return e.substring(t.length)}function l(e){return"string"==typeof e?e:e.displayName||e.name||"Unknown"}function f(e){return e.finished||e.headersSent}function p(e){let t=e.split("?");return t[0].replace(/\\/g,"/").replace(/\/\/+/g,"/")+(t[1]?`?${t.slice(1).join("?")}`:"")}async function h(e,t){let r=t.res||t.ctx&&t.ctx.res;if(!e.getInitialProps)return t.ctx&&t.Component?{pageProps:await h(t.Component,t.ctx)}:{};let n=await e.getInitialProps(t);if(r&&f(r))return n;if(!n)throw Object.defineProperty(Error(`"${l(e)}.getInitialProps()" should resolve to an object. But found "${n}" instead.`),"__NEXT_ERROR_CODE",{value:"E394",enumerable:!1,configurable:!0});return n}let m="undefined"!=typeof performance,y=m&&["mark","measure","getEntriesByName"].every(e=>"function"==typeof performance[e]);class b extends Error{}class g extends Error{}class x extends Error{constructor(e){super(),this.code="ENOENT",this.name="PageNotFoundError",this.message=`Cannot find module for page: ${e}`}}class v extends Error{constructor(e,t){super(),this.message=`Failed to load static file for page: ${e} ${t}`}}class _ extends Error{constructor(){super(),this.code="ENOENT",this.message="Cannot find the middleware module"}}function S(e){return JSON.stringify({message:e.message,stack:e.stack})}},34072,(e,t,r)=>{},88499,(e,t,r)=>{var n=e.i(6725);e.r(34072);var o=e.r(73658),s=o&&"object"==typeof o&&"default"in o?o:{default:o},i=void 0!==n.default&&n.default.env&&!0,a=function(e){return"[object String]"===Object.prototype.toString.call(e)},u=function(){function e(e){var t=void 0===e?{}:e,r=t.name,n=void 0===r?"stylesheet":r,o=t.optimizeForSpeed,s=void 0===o?i:o;c(a(n),"`name` must be a string"),this._name=n,this._deletedRulePlaceholder="#"+n+"-deleted-rule____{}",c("boolean"==typeof s,"`optimizeForSpeed` must be a boolean"),this._optimizeForSpeed=s,this._serverSheet=void 0,this._tags=[],this._injected=!1,this._rulesCount=0;var u="undefined"!=typeof window&&document.querySelector('meta[property="csp-nonce"]');this._nonce=u?u.getAttribute("content"):null}var t,r=e.prototype;return r.setOptimizeForSpeed=function(e){c("boolean"==typeof e,"`setOptimizeForSpeed` accepts a boolean"),c(0===this._rulesCount,"optimizeForSpeed cannot be when rules have already been inserted"),this.flush(),this._optimizeForSpeed=e,this.inject()},r.isOptimizeForSpeed=function(){return this._optimizeForSpeed},r.inject=function(){var e=this;if(c(!this._injected,"sheet already injected"),this._injected=!0,"undefined"!=typeof window&&this._optimizeForSpeed){this._tags[0]=this.makeStyleTag(this._name),this._optimizeForSpeed="insertRule"in this.getSheet(),this._optimizeForSpeed||(i||console.warn("StyleSheet: optimizeForSpeed mode not supported falling back to standard mode."),this.flush(),this._injected=!0);return}this._serverSheet={cssRules:[],insertRule:function(t,r){return"number"==typeof r?e._serverSheet.cssRules[r]={cssText:t}:e._serverSheet.cssRules.push({cssText:t}),r},deleteRule:function(t){e._serverSheet.cssRules[t]=null}}},r.getSheetForTag=function(e){if(e.sheet)return e.sheet;for(var t=0;t<document.styleSheets.length;t++)if(document.styleSheets[t].ownerNode===e)return document.styleSheets[t]},r.getSheet=function(){return this.getSheetForTag(this._tags[this._tags.length-1])},r.insertRule=function(e,t){if(c(a(e),"`insertRule` accepts only strings"),"undefined"==typeof window)return"number"!=typeof t&&(t=this._serverSheet.cssRules.length),this._serverSheet.insertRule(e,t),this._rulesCount++;if(this._optimizeForSpeed){var r=this.getSheet();"number"!=typeof t&&(t=r.cssRules.length);try{r.insertRule(e,t)}catch(t){return i||console.warn("StyleSheet: illegal rule: \n\n"+e+"\n\nSee https://stackoverflow.com/q/20007992 for more info"),-1}}else{var n=this._tags[t];this._tags.push(this.makeStyleTag(this._name,e,n))}return this._rulesCount++},r.replaceRule=function(e,t){if(this._optimizeForSpeed||"undefined"==typeof window){var r="undefined"!=typeof window?this.getSheet():this._serverSheet;if(t.trim()||(t=this._deletedRulePlaceholder),!r.cssRules[e])return e;r.deleteRule(e);try{r.insertRule(t,e)}catch(n){i||console.warn("StyleSheet: illegal rule: \n\n"+t+"\n\nSee https://stackoverflow.com/q/20007992 for more info"),r.insertRule(this._deletedRulePlaceholder,e)}}else{var n=this._tags[e];c(n,"old rule at index `"+e+"` not found"),n.textContent=t}return e},r.deleteRule=function(e){if("undefined"==typeof window)return void this._serverSheet.deleteRule(e);if(this._optimizeForSpeed)this.replaceRule(e,"");else{var t=this._tags[e];c(t,"rule at index `"+e+"` not found"),t.parentNode.removeChild(t),this._tags[e]=null}},r.flush=function(){this._injected=!1,this._rulesCount=0,"undefined"!=typeof window?(this._tags.forEach(function(e){return e&&e.parentNode.removeChild(e)}),this._tags=[]):this._serverSheet.cssRules=[]},r.cssRules=function(){var e=this;return"undefined"==typeof window?this._serverSheet.cssRules:this._tags.reduce(function(t,r){return r?t=t.concat(Array.prototype.map.call(e.getSheetForTag(r).cssRules,function(t){return t.cssText===e._deletedRulePlaceholder?null:t})):t.push(null),t},[])},r.makeStyleTag=function(e,t,r){t&&c(a(t),"makeStyleTag accepts only strings as second parameter");var n=document.createElement("style");this._nonce&&n.setAttribute("nonce",this._nonce),n.type="text/css",n.setAttribute("data-"+e,""),t&&n.appendChild(document.createTextNode(t));var o=document.head||document.getElementsByTagName("head")[0];return r?o.insertBefore(n,r):o.appendChild(n),n},t=[{key:"length",get:function(){return this._rulesCount}}],function(e,t){for(var r=0;r<t.length;r++){var n=t[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}(e.prototype,t),e}();function c(e,t){if(!e)throw Error("StyleSheet: "+t+".")}var d=function(e){for(var t=5381,r=e.length;r;)t=33*t^e.charCodeAt(--r);return t>>>0},l={};function f(e,t){if(!t)return"jsx-"+e;var r=String(t),n=e+r;return l[n]||(l[n]="jsx-"+d(e+"-"+r)),l[n]}function p(e,t){"undefined"==typeof window&&(t=t.replace(/\/style/gi,"\\/style"));var r=e+t;return l[r]||(l[r]=t.replace(/__jsx-style-dynamic-selector/g,e)),l[r]}var h=function(){function e(e){var t=void 0===e?{}:e,r=t.styleSheet,n=void 0===r?null:r,o=t.optimizeForSpeed,s=void 0!==o&&o;this._sheet=n||new u({name:"styled-jsx",optimizeForSpeed:s}),this._sheet.inject(),n&&"boolean"==typeof s&&(this._sheet.setOptimizeForSpeed(s),this._optimizeForSpeed=this._sheet.isOptimizeForSpeed()),this._fromServer=void 0,this._indices={},this._instancesCounts={}}var t=e.prototype;return t.add=function(e){var t=this;void 0===this._optimizeForSpeed&&(this._optimizeForSpeed=Array.isArray(e.children),this._sheet.setOptimizeForSpeed(this._optimizeForSpeed),this._optimizeForSpeed=this._sheet.isOptimizeForSpeed()),"undefined"==typeof window||this._fromServer||(this._fromServer=this.selectFromServer(),this._instancesCounts=Object.keys(this._fromServer).reduce(function(e,t){return e[t]=0,e},{}));var r=this.getIdAndRules(e),n=r.styleId,o=r.rules;if(n in this._instancesCounts){this._instancesCounts[n]+=1;return}var s=o.map(function(e){return t._sheet.insertRule(e)}).filter(function(e){return -1!==e});this._indices[n]=s,this._instancesCounts[n]=1},t.remove=function(e){var t=this,r=this.getIdAndRules(e).styleId;if(function(e,t){if(!e)throw Error("StyleSheetRegistry: "+t+".")}(r in this._instancesCounts,"styleId: `"+r+"` not found"),this._instancesCounts[r]-=1,this._instancesCounts[r]<1){var n=this._fromServer&&this._fromServer[r];n?(n.parentNode.removeChild(n),delete this._fromServer[r]):(this._indices[r].forEach(function(e){return t._sheet.deleteRule(e)}),delete this._indices[r]),delete this._instancesCounts[r]}},t.update=function(e,t){this.add(t),this.remove(e)},t.flush=function(){this._sheet.flush(),this._sheet.inject(),this._fromServer=void 0,this._indices={},this._instancesCounts={}},t.cssRules=function(){var e=this,t=this._fromServer?Object.keys(this._fromServer).map(function(t){return[t,e._fromServer[t]]}):[],r=this._sheet.cssRules();return t.concat(Object.keys(this._indices).map(function(t){return[t,e._indices[t].map(function(e){return r[e].cssText}).join(e._optimizeForSpeed?"":"\n")]}).filter(function(e){return!!e[1]}))},t.styles=function(e){var t,r;return t=this.cssRules(),void 0===(r=e)&&(r={}),t.map(function(e){var t=e[0],n=e[1];return s.default.createElement("style",{id:"__"+t,key:"__"+t,nonce:r.nonce?r.nonce:void 0,dangerouslySetInnerHTML:{__html:n}})})},t.getIdAndRules=function(e){var t=e.children,r=e.dynamic,n=e.id;if(r){var o=f(n,r);return{styleId:o,rules:Array.isArray(t)?t.map(function(e){return p(o,e)}):[p(o,t)]}}return{styleId:f(n),rules:Array.isArray(t)?t:[t]}},t.selectFromServer=function(){return Array.prototype.slice.call(document.querySelectorAll('[id^="__jsx-"]')).reduce(function(e,t){return e[t.id.slice(2)]=t,e},{})},e}(),m=o.createContext(null);function y(){return new h}function b(){return o.useContext(m)}m.displayName="StyleSheetContext";var g=s.default.useInsertionEffect||s.default.useLayoutEffect,x="undefined"!=typeof window?y():void 0;function v(e){var t=x||b();return t&&("undefined"==typeof window?t.add(e):g(function(){return t.add(e),function(){t.remove(e)}},[e.id,String(e.dynamic)])),null}v.dynamic=function(e){return e.map(function(e){return f(e[0],e[1])}).join(" ")},r.StyleRegistry=function(e){var t=e.registry,r=e.children,n=o.useContext(m),i=o.useState(function(){return n||t||y()})[0];return s.default.createElement(m.Provider,{value:i},r)},r.createStyleRegistry=y,r.style=v,r.useStyleRegistry=b},22366,(e,t,r)=>{t.exports=e.r(88499).style},39491,(e,t,r)=>{t.exports=e.r(90754)},93962,e=>{"use strict";var t=e.i(41526),r=e.i(22366);let n={primary:"db-btn-primary",secondary:"db-btn-secondary",ghost:"db-btn-ghost"},o={sm:"db-btn-sm",md:"db-btn-md",lg:"db-btn-lg"};e.s(["default",0,function({children:e,className:s,variant:i="primary",size:a="md",isFullWidth:u,disabled:c,...d}){return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("button",{disabled:c,"aria-disabled":c,...d,className:"jsx-fc589ec2381676fa "+(d&&null!=d.className&&d.className||`db-btn ${n[i]} ${o[a]} ${u?"db-btn-block":""} ${s??""}`),children:e}),(0,t.jsx)(r.default,{id:"fc589ec2381676fa",children:".db-btn.jsx-fc589ec2381676fa{cursor:pointer;font-weight:600;font-family:var(--font-sans);border:1px solid #0000;border-radius:9999px;justify-content:center;align-items:center;text-decoration:none;transition:transform .12s,box-shadow .12s,background-color .12s,border-color .12s;display:inline-flex;box-shadow:0 8px 24px #00000014}.db-btn-sm.jsx-fc589ec2381676fa{height:40px;padding:0 16px;font-size:14px}.db-btn-md.jsx-fc589ec2381676fa{height:46px;padding:0 20px;font-size:15px}.db-btn-lg.jsx-fc589ec2381676fa{height:52px;padding:0 24px;font-size:16px}.db-btn-block.jsx-fc589ec2381676fa{width:100%}.db-btn-primary.jsx-fc589ec2381676fa{background:var(--color-primary-teal);color:#fff}.db-btn-primary.jsx-fc589ec2381676fa:hover:not(:disabled){background:#00a6bb;transform:translateY(-1px);box-shadow:0 10px 28px #0096a83d}.db-btn-secondary.jsx-fc589ec2381676fa{background:var(--color-secondary-gold);color:#fff}.db-btn-secondary.jsx-fc589ec2381676fa:hover:not(:disabled){background:#ffb632;transform:translateY(-1px);box-shadow:0 10px 28px #f4a61c3d}.db-btn-ghost.jsx-fc589ec2381676fa{color:var(--color-primary-teal);border:1px solid var(--color-primary-teal);box-shadow:none;background:0 0}.db-btn-ghost.jsx-fc589ec2381676fa:hover:not(:disabled){background:#0096a814;transform:translateY(-1px)}.db-btn.jsx-fc589ec2381676fa:disabled{opacity:.6;cursor:not-allowed;box-shadow:none;transform:none}.db-btn.jsx-fc589ec2381676fa:focus-visible{outline-offset:2px;outline:3px solid #0096a859}"})]})}])},9793,e=>{"use strict";var t=e.i(73872),r=e.i(55251),n=e.i(30111),o=e.i(2526),s=e.i(50973),i=e.i(34264),a=e.i(52254),u=e.i(29741).canUseDOM?r.useLayoutEffect:r.useEffect,c=e.i(42198);function d(e,d){!1!==globalThis.__DEV__&&(0,c.useWarnRemovedOption)(d||{},"ignoreResults","useMutation","If you don't want to synchronize component state with the mutation, please use the `useApolloClient` hook to get the client instance and call `client.mutate` directly.");var l=(0,a.useApolloClient)(null==d?void 0:d.client);(0,s.verifyDocumentType)(e,s.DocumentType.Mutation);var f=r.useState({called:!1,loading:!1,client:l}),p=f[0],h=f[1],m=r.useRef({result:p,mutationId:0,isMounted:!0,client:l,mutation:e,options:d});u(function(){Object.assign(m.current,{client:l,options:d,mutation:e})});var y=r.useCallback(function(e){void 0===e&&(e={});var r=m.current,s=r.options,a=r.mutation,u=(0,t.__assign)((0,t.__assign)({},s),{mutation:a}),c=e.client||m.current.client;m.current.result.loading||u.ignoreResults||!m.current.isMounted||h(m.current.result={loading:!0,error:void 0,data:void 0,called:!0,client:c});var d=++m.current.mutationId,l=(0,n.mergeOptions)(u,e);return c.mutate(l).then(function(t){var r,n,s=t.data,a=t.errors,u=a&&a.length>0?new i.ApolloError({graphQLErrors:a}):void 0,f=e.onError||(null==(r=m.current.options)?void 0:r.onError);if(u&&f&&f(u,l),d===m.current.mutationId&&!l.ignoreResults){var p={called:!0,loading:!1,data:s,error:u,client:c};m.current.isMounted&&!(0,o.equal)(m.current.result,p)&&h(m.current.result=p)}var y=e.onCompleted||(null==(n=m.current.options)?void 0:n.onCompleted);return u||null==y||y(t.data,l),t},function(t){if(d===m.current.mutationId&&m.current.isMounted){var r,n={loading:!1,error:t,data:void 0,called:!0,client:c};(0,o.equal)(m.current.result,n)||h(m.current.result=n)}var s=e.onError||(null==(r=m.current.options)?void 0:r.onError);if(s)return s(t,l),{data:void 0,errors:t};throw t})},[]),b=r.useCallback(function(){if(m.current.isMounted){var e={called:!1,loading:!1,client:m.current.client};Object.assign(m.current,{mutationId:0,result:e}),h(e)}},[]);return r.useEffect(function(){var e=m.current;return e.isMounted=!0,function(){e.isMounted=!1}},[]),[y,(0,t.__assign)({reset:b},p)]}e.s(["useMutation",()=>d],9793)},83724,7282,e=>{"use strict";var t=e.i(41526),r=e.i(73658),n=e.i(39491),o=e.i(18038);let s=function(){let{currentUser:e,loading:t}=(0,o.useAuth)();return{currentUser:e,loading:t}};e.s(["default",0,s],7282),e.s(["default",0,function({children:e,requireRole:o="parent"}){let i=(0,n.useRouter)(),{currentUser:a,loading:u}=s(),c=a?.role&&"string"==typeof a.role?a.role.toLowerCase():void 0;(0,r.useEffect)(()=>{if(!i.isReady||u)return;let e="admin"===c?"/admin/referrals":"/parent/dashboard";if(!a){"/auth/login"!==i.asPath&&i.replace("/auth/login");return}if(o&&c!==o){i.asPath!==e&&i.replace(e);return}},[a,u,c,o,i,i.isReady]);let d=!u&&a&&o&&c!==o;return u||!i.isReady?(0,t.jsx)("div",{style:{padding:"80px 24px",textAlign:"center"},children:"Loading..."}):a?d?(0,t.jsx)("div",{style:{padding:"80px 24px",textAlign:"center"},children:"Redirecting…"}):(0,t.jsx)(t.Fragment,{children:e}):(0,t.jsx)("div",{style:{padding:"80px 24px",textAlign:"center"},children:"Redirecting to login…"})}],83724)},12190,e=>{"use strict";var t=e.i(64467);let r=t.gql`
  query MyReferrals {
    myReferrals {
      id
      status
      packetStatus
      riskFlag
      lastCompletedStep
      lastUpdatedStepAt
      nextStep
      createdAt
      submittedAt
      withdrawnAt
      deletionRequestedAt
      child {
        id
        name
        grade
        schoolName
        district
      }
    }
  }
`,n=t.gql`
  query Referral($id: ID!) {
    referral(id: $id) {
      id
      status
      packetStatus
      deletionRequestedAt
      withdrawnAt
      createdAt
      riskFlag
      lastCompletedStep
      lastUpdatedStepAt
      nextStep
      submittedAt
      user {
        id
        name
        email
        phone
        address
        languagePreference
        relationshipToChild
      }
      child {
        id
        name
        dob
        ageBand
        grade
        schoolName
        district
        state
        primaryLanguage
        pronouns
      }
      insuranceDetail {
        id
        insuranceStatus
        insurerName
        planName
        memberId
        groupId
        policyholderName
        coveragePhone
        coverageWebsite
        source
      }
      insuranceUploads {
        id
        frontImageS3Key
        backImageS3Key
        ocrStatus
        ocrConfidence
        createdAt
        updatedAt
      }
      costEstimate {
        id
        category
        ruleKey
        explanationText
        updatedAt
      }
      intakeResponse {
        id
        responses
      }
      consentRecords {
        id
        consentType
        acceptedAt
        ipAddress
        userAgent
      }
      schedulingPreference {
        id
        timezone
        locationPreference
        frequency
        clinicianPreferences
        windows
        suggestedWindows
      }
      aiScreenerSession {
        id
        summaryJsonb
        riskFlag
      }
    }
  }
`,o=t.gql`
  query ReferralStatus($id: ID!) {
    referral(id: $id) {
      id
      status
      packetStatus
    }
  }
`;e.s(["MY_REFERRALS_QUERY",0,r,"REFERRAL_QUERY",0,n,"REFERRAL_STATUS_QUERY",0,o])},41921,e=>{"use strict";var t=e.i(64467);let r=t.gql`
  query MySupportChats($referralId: ID) {
    mySupportChats(referralId: $referralId) {
      id
      referralId
      parentUserId
      mode
      createdAt
      updatedAt
      supportChatMessages {
        id
        senderType
        messageText
        metadataJsonb
        createdAt
      }
    }
  }
`,n=t.gql`
  query AdminChats($limit: Int, $offset: Int) {
    adminChats(limit: $limit, offset: $offset) {
      id
      referralId
      parentUserId
      mode
      createdAt
      updatedAt
      supportChatMessages {
        id
        senderType
        messageText
        createdAt
      }
    }
  }
`,o=t.gql`
  query AdminChat($id: ID!) {
    adminChat(id: $id) {
      id
      referralId
      parentUserId
      mode
      createdAt
      updatedAt
      supportChatMessages {
        id
        senderType
        messageText
        metadataJsonb
        createdAt
      }
    }
  }
`;e.s(["ADMIN_CHATS_QUERY",0,n,"ADMIN_CHAT_QUERY",0,o,"MY_SUPPORT_CHATS_QUERY",0,r])},63688,e=>{"use strict";var t=e.i(64467);let r=t.gql`
  mutation SendSupportMessage($referralId: ID, $messageText: String!) {
    sendSupportMessage(referralId: $referralId, messageText: $messageText) {
      chat {
        id
        mode
        updatedAt
      }
      message {
        id
        senderType
        messageText
        createdAt
      }
      aiMessage {
        id
        senderType
        messageText
        createdAt
      }
      riskDetected
      errors
    }
  }
`,n=t.gql`
  mutation SendAdminChatMessage($chatId: ID!, $messageText: String!) {
    sendAdminChatMessage(chatId: $chatId, messageText: $messageText) {
      message {
        id
        senderType
        messageText
        createdAt
      }
      chat {
        id
        mode
        updatedAt
      }
      errors
    }
  }
`;e.s(["SEND_ADMIN_CHAT_MESSAGE_MUTATION",0,n,"SEND_SUPPORT_MESSAGE_MUTATION",0,r])}]);