(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,97679,e=>{"use strict";var r=e.i(41526),a=e.i(22366);function t({label:e,id:t,helperText:n,error:i,required:d,...l}){let s=n?`${t}-helper`:void 0,o=i?`${t}-error`:void 0;return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsxs)("label",{htmlFor:t,className:"jsx-59fec5f1f0edea5 db-input-label",children:[e,d?(0,r.jsx)("span",{className:"jsx-59fec5f1f0edea5 db-required",children:"*"}):null]}),(0,r.jsx)("input",{id:t,"aria-invalid":!!i,"aria-describedby":i?o:s,required:d,...l,className:"jsx-59fec5f1f0edea5 "+(l&&null!=l.className&&l.className||`db-input ${i?"db-input-error":""}`)}),n&&!i?(0,r.jsx)("p",{id:s,className:"jsx-59fec5f1f0edea5 db-input-helper",children:n}):null,i?(0,r.jsx)("p",{id:o,className:"jsx-59fec5f1f0edea5 db-input-error-text",children:i}):null,(0,r.jsx)(a.default,{id:"59fec5f1f0edea5",children:".db-input-label.jsx-59fec5f1f0edea5{color:var(--color-deep-aqua);margin-bottom:4px;font-weight:600;display:block}.db-required.jsx-59fec5f1f0edea5{color:var(--color-accent-red);margin-left:4px}.db-input.jsx-59fec5f1f0edea5{border:1px solid var(--color-border);width:100%;height:46px;color:var(--color-text);background:#fff;border-radius:10px;padding:0 58px 0 14px;font-size:15px;transition:border-color .12s,box-shadow .12s}.db-input.jsx-59fec5f1f0edea5:focus{border-color:var(--color-primary-teal);outline:none;box-shadow:0 0 0 3px #0096a833}.db-input.jsx-59fec5f1f0edea5::placeholder{color:var(--color-muted)}.db-input-error.jsx-59fec5f1f0edea5{border-color:var(--color-accent-red)}.db-input-helper.jsx-59fec5f1f0edea5{color:var(--color-muted);margin-top:6px;font-size:13px}.db-input-error-text.jsx-59fec5f1f0edea5{color:var(--color-accent-red);margin-top:6px;font-size:13px}"})]})}e.s(["TextInput",()=>t,"default",0,t])},20979,e=>{"use strict";var r=e.i(64467);let a=r.gql`
  mutation CreateChildAndReferral($childInput: ChildInput!) {
    createChildAndReferral(childInput: $childInput) {
      child {
        id
        name
        grade
        schoolName
        district
      }
      referral {
        id
        status
        lastCompletedStep
        nextStep
      }
      errors
    }
  }
`,t=r.gql`
  mutation UpdateReferralStep(
    $referralId: ID!
    $stepName: String!
    $stepData: JSON
  ) {
    updateReferralStep(
      referralId: $referralId
      stepName: $stepName
      stepData: $stepData
    ) {
      referral {
        id
        status
        lastCompletedStep
        lastUpdatedStepAt
        nextStep
      }
      errors
    }
  }
`,n=r.gql`
  mutation UpdateParentInfo($referralId: ID!, $parentInfo: ParentInfoInput!) {
    updateParentInfo(referralId: $referralId, parentInfo: $parentInfo) {
      user {
        id
        name
        email
        phone
        address
        languagePreference
        relationshipToChild
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,i=r.gql`
  mutation UpdateChildInfo($referralId: ID!, $childInput: ChildInput!) {
    updateChildInfo(referralId: $referralId, childInput: $childInput) {
      child {
        id
        name
        dob
        ageBand
        grade
        schoolName
        district
        state
        primaryLanguage
        pronouns
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,d=r.gql`
  mutation UpdateClinicalIntake($referralId: ID!, $intakeInput: ClinicalIntakeInput!) {
    updateClinicalIntake(referralId: $referralId, intakeInput: $intakeInput) {
      intakeResponse {
        id
        responses
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,l=r.gql`
  mutation UpdateSchedulingPreferences(
    $referralId: ID!
    $schedulingInput: SchedulingPreferenceInput!
  ) {
    updateSchedulingPreferences(referralId: $referralId, schedulingInput: $schedulingInput) {
      schedulingPreference {
        id
        timezone
        locationPreference
        frequency
        clinicianPreferences
        windows
        suggestedWindows
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,s=r.gql`
  mutation SubmitReferral($referralId: ID!) {
    submitReferral(referralId: $referralId) {
      referral {
        id
        status
        packetStatus
        submittedAt
      }
      errors
    }
  }
`,o=r.gql`
  mutation UpdateInsuranceDetails($referralId: ID!, $insuranceInput: InsuranceDetailInput!) {
    updateInsuranceDetails(referralId: $referralId, insuranceInput: $insuranceInput) {
      insuranceDetail {
        id
        insuranceStatus
        insurerName
        planName
        memberId
        groupId
        policyholderName
        coveragePhone
        coverageWebsite
        source
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,c=r.gql`
  mutation AcceptConsents($referralId: ID!, $consents: [ConsentInput!]!) {
    acceptConsents(referralId: $referralId, consents: $consents) {
      consentRecords {
        id
        consentType
        acceptedAt
        ipAddress
        userAgent
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`;e.s(["ACCEPT_CONSENTS",0,c,"CREATE_CHILD_AND_REFERRAL",0,a,"SUBMIT_REFERRAL",0,s,"UPDATE_CHILD_INFO",0,i,"UPDATE_CLINICAL_INTAKE",0,d,"UPDATE_INSURANCE_DETAILS",0,o,"UPDATE_PARENT_INFO",0,n,"UPDATE_REFERRAL_STEP",0,t,"UPDATE_SCHEDULING_PREFERENCES",0,l])},42008,(e,r,a)=>{"use strict";Object.defineProperty(a,"__esModule",{value:!0});var t={VALID_LOADERS:function(){return i},imageConfigDefault:function(){return d}};for(var n in t)Object.defineProperty(a,n,{enumerable:!0,get:t[n]});let i=["default","imgix","cloudinary","akamai","custom"],d={deviceSizes:[640,750,828,1080,1200,1920,2048,3840],imageSizes:[32,48,64,96,128,256,384],path:"/_next/image",loader:"default",loaderFile:"",domains:[],disableStaticImages:!1,minimumCacheTTL:14400,formats:["image/webp"],maximumRedirects:3,dangerouslyAllowLocalIP:!1,dangerouslyAllowSVG:!1,contentSecurityPolicy:"script-src 'none'; frame-src 'none'; sandbox;",contentDispositionType:"attachment",localPatterns:void 0,remotePatterns:[],qualities:[75],unoptimized:!1}},78361,(e,r,a)=>{"use strict";Object.defineProperty(a,"__esModule",{value:!0}),Object.defineProperty(a,"ImageConfigContext",{enumerable:!0,get:function(){return i}});let t=e.r(1646)._(e.r(73658)),n=e.r(42008),i=t.default.createContext(n.imageConfigDefault)},83121,e=>{"use strict";var r=e.i(41526),a=e.i(22366),t=e.i(73658),n=e.i(39491),i=e.i(83724),d=e.i(53949),l=e.i(56421),s=e.i(9793),o=e.i(20979);let c=function({referralId:e,stepName:r,stepData:a,enabled:n=!0}){let[i,d]=(0,t.useState)("idle"),[l]=(0,s.useMutation)(o.UPDATE_REFERRAL_STEP),c=(0,t.useRef)(a);(0,t.useEffect)(()=>{c.current=a},[a]);let f=async()=>{if(n&&e&&r)try{d("saving");let a=await l({variables:{referralId:e,stepName:r,stepData:c.current}});if(a.data?.updateReferralStep?.errors?.length)return void d("error");d("saved"),setTimeout(()=>d("idle"),1200)}catch{d("error")}};return(0,t.useEffect)(()=>{if(!n||!e||!r)return;let a=setTimeout(()=>{f()},600);return()=>clearTimeout(a)},[n,e,r,JSON.stringify(a)]),{status:i,saveNow:f}};var f=e.i(76245),p=e.i(93962),u=e.i(97679);function m(){let e=(0,n.useRouter)(),{id:s,step:o}=e.query,m=(0,t.useMemo)(()=>o||"",[o]),h=f.ONBOARDING_STEPS.includes(m);(0,t.useEffect)(()=>{o&&!h&&e.replace("/parent/dashboard")},[h,e,o]);let{referral:x,loading:I,error:g}=(0,l.default)(s),[b,S]=(0,t.useState)(""),v=b.trim().length>0,{status:j,saveNow:N}=c({referralId:x?.id,stepName:m,stepData:v?{note:b}:void 0,enabled:h&&!!x?.id&&v});(0,t.useEffect)(()=>{S("")},[m]);let A=async()=>{v&&await N();let r=(0,f.getNextStep)(m);e.push(`/parent/referrals/${s}/onboarding/${r}`)},C=async()=>{v&&await N();let r=(0,f.getPreviousStep)(m);e.push(`/parent/referrals/${s}/onboarding/${r}`)};return h?I?(0,r.jsx)(i.default,{requireRole:"parent",children:(0,r.jsx)("div",{style:{padding:"48px 24px",textAlign:"center"},children:"Loading referral…"})}):g||!x?(0,r.jsx)(i.default,{requireRole:"parent",children:(0,r.jsxs)("div",{style:{padding:"48px 24px",textAlign:"center"},children:[(0,r.jsx)("p",{children:"Unable to load this referral."}),(0,r.jsx)(p.default,{onClick:()=>e.push("/parent/dashboard"),children:"Back to dashboard"})]})}):(0,r.jsxs)(i.default,{requireRole:"parent",children:[(0,r.jsxs)(d.default,{referralId:x.id,currentStep:m,onStepSelect:r=>f.ONBOARDING_STEPS.indexOf(r)<=f.ONBOARDING_STEPS.indexOf(m)?void e.push(`/parent/referrals/${x.id}/onboarding/${r}`):void 0,children:[(0,r.jsxs)("div",{className:"jsx-444574f6f6dfea61 step-header",children:[(0,r.jsxs)("div",{className:"jsx-444574f6f6dfea61",children:[(0,r.jsxs)("p",{className:"jsx-444574f6f6dfea61 eyebrow",children:["Step ",f.ONBOARDING_STEPS.indexOf(m)+1]}),(0,r.jsx)("h2",{className:"jsx-444574f6f6dfea61",children:f.STEP_LABELS[m]}),(0,r.jsx)("p",{className:"jsx-444574f6f6dfea61 muted",children:"Placeholder content for this step. Autosave will update your progress as you type."})]}),(0,r.jsxs)("div",{"aria-live":"polite",className:"jsx-444574f6f6dfea61 save-indicator",children:["saving"===j&&"Saving…","saved"===j&&"Saved","error"===j&&"Save error","idle"===j&&""]})]}),(0,r.jsx)("div",{className:"jsx-444574f6f6dfea61 form-area",children:(0,r.jsx)(u.default,{id:"note",label:"Notes for this step (placeholder)",placeholder:"Type anything to trigger autosave…",value:b,onChange:e=>S(e.target.value),onBlur:()=>void N()})}),(0,r.jsxs)("div",{className:"jsx-444574f6f6dfea61 nav-actions",children:[(0,r.jsx)(p.default,{variant:"ghost",onClick:()=>void C(),children:"Back"}),(0,r.jsx)(p.default,{onClick:()=>void A(),children:"review"===m?"Stay on review":"Continue"})]})]}),(0,r.jsx)(a.default,{id:"444574f6f6dfea61",children:".step-header.jsx-444574f6f6dfea61{flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;margin-bottom:12px;display:flex}.eyebrow.jsx-444574f6f6dfea61{color:var(--color-primary-teal);margin:0;font-weight:700}h2.jsx-444574f6f6dfea61{color:var(--color-deep-aqua);margin:4px 0}.muted.jsx-444574f6f6dfea61{color:var(--color-muted);margin:0}.save-indicator.jsx-444574f6f6dfea61{color:var(--color-muted);font-weight:600}.form-area.jsx-444574f6f6dfea61{margin:12px 0 20px}.nav-actions.jsx-444574f6f6dfea61{flex-wrap:wrap;justify-content:space-between;gap:10px;display:flex}"})]}):null}e.s(["default",()=>m],83121)},22683,(e,r,a)=>{let t="/parent/referrals/[id]/onboarding/[step]";(window.__NEXT_P=window.__NEXT_P||[]).push([t,()=>e.r(83121)]),r.hot&&r.hot.dispose(function(){window.__NEXT_P.push([t])})},88853,e=>{e.v(r=>Promise.all(["static/chunks/ca6b9ab451866ae2.js"].map(r=>e.l(r))).then(()=>r(33811)))},91751,e=>{e.v(r=>Promise.all(["static/chunks/b0bbf6aa740a2457.js"].map(r=>e.l(r))).then(()=>r(23428)))}]);