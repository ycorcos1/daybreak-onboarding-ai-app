__turbopack_load_page_chunks__("/admin/resources/[id]", [
  "static/chunks/58d8949c564dca65.js",
  "static/chunks/382f3ba59a902a64.js",
  "static/chunks/b6758c396527f921.js",
  "static/chunks/4b1e92164ea6607d.js",
  "static/chunks/turbopack-c42b5ed838ae4337.js"
])
