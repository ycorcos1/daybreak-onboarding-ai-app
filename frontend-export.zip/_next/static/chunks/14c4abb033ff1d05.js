__turbopack_load_page_chunks__("/_app", [
  "static/chunks/1cb16968260a2fcc.js",
  "static/chunks/382f3ba59a902a64.js",
  "static/chunks/0c60ed1deda2f33d.js",
  "static/chunks/b6758c396527f921.js",
  "static/chunks/4df4bf86835ba866.js",
  "static/chunks/9077023936cbe124.js",
  "static/chunks/9bd1b022e2db7fe1.css",
  "static/chunks/turbopack-416902f10ab12a63.js"
])
