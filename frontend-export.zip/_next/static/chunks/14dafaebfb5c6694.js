(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,20979,e=>{"use strict";var a=e.i(64467);let r=a.gql`
  mutation CreateChildAndReferral($childInput: ChildInput!) {
    createChildAndReferral(childInput: $childInput) {
      child {
        id
        name
        grade
        schoolName
        district
      }
      referral {
        id
        status
        lastCompletedStep
        nextStep
      }
      errors
    }
  }
`,t=a.gql`
  mutation UpdateReferralStep(
    $referralId: ID!
    $stepName: String!
    $stepData: JSON
  ) {
    updateReferralStep(
      referralId: $referralId
      stepName: $stepName
      stepData: $stepData
    ) {
      referral {
        id
        status
        lastCompletedStep
        lastUpdatedStepAt
        nextStep
      }
      errors
    }
  }
`,d=a.gql`
  mutation UpdateParentInfo($referralId: ID!, $parentInfo: ParentInfoInput!) {
    updateParentInfo(referralId: $referralId, parentInfo: $parentInfo) {
      user {
        id
        name
        email
        phone
        address
        languagePreference
        relationshipToChild
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,l=a.gql`
  mutation UpdateChildInfo($referralId: ID!, $childInput: ChildInput!) {
    updateChildInfo(referralId: $referralId, childInput: $childInput) {
      child {
        id
        name
        dob
        ageBand
        grade
        schoolName
        district
        state
        primaryLanguage
        pronouns
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,s=a.gql`
  mutation UpdateClinicalIntake($referralId: ID!, $intakeInput: ClinicalIntakeInput!) {
    updateClinicalIntake(referralId: $referralId, intakeInput: $intakeInput) {
      intakeResponse {
        id
        responses
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,i=a.gql`
  mutation UpdateSchedulingPreferences(
    $referralId: ID!
    $schedulingInput: SchedulingPreferenceInput!
  ) {
    updateSchedulingPreferences(referralId: $referralId, schedulingInput: $schedulingInput) {
      schedulingPreference {
        id
        timezone
        locationPreference
        frequency
        clinicianPreferences
        windows
        suggestedWindows
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,n=a.gql`
  mutation SubmitReferral($referralId: ID!) {
    submitReferral(referralId: $referralId) {
      referral {
        id
        status
        packetStatus
        submittedAt
      }
      errors
    }
  }
`,o=a.gql`
  mutation UpdateInsuranceDetails($referralId: ID!, $insuranceInput: InsuranceDetailInput!) {
    updateInsuranceDetails(referralId: $referralId, insuranceInput: $insuranceInput) {
      insuranceDetail {
        id
        insuranceStatus
        insurerName
        planName
        memberId
        groupId
        policyholderName
        coveragePhone
        coverageWebsite
        source
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,c=a.gql`
  mutation AcceptConsents($referralId: ID!, $consents: [ConsentInput!]!) {
    acceptConsents(referralId: $referralId, consents: $consents) {
      consentRecords {
        id
        consentType
        acceptedAt
        ipAddress
        userAgent
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`;e.s(["ACCEPT_CONSENTS",0,c,"CREATE_CHILD_AND_REFERRAL",0,r,"SUBMIT_REFERRAL",0,n,"UPDATE_CHILD_INFO",0,l,"UPDATE_CLINICAL_INTAKE",0,s,"UPDATE_INSURANCE_DETAILS",0,o,"UPDATE_PARENT_INFO",0,d,"UPDATE_REFERRAL_STEP",0,t,"UPDATE_SCHEDULING_PREFERENCES",0,i])},97679,e=>{"use strict";var a=e.i(41526),r=e.i(22366);function t({label:e,id:t,helperText:d,error:l,required:s,...i}){let n=d?`${t}-helper`:void 0,o=l?`${t}-error`:void 0;return(0,a.jsxs)(a.Fragment,{children:[(0,a.jsxs)("label",{htmlFor:t,className:"jsx-59fec5f1f0edea5 db-input-label",children:[e,s?(0,a.jsx)("span",{className:"jsx-59fec5f1f0edea5 db-required",children:"*"}):null]}),(0,a.jsx)("input",{id:t,"aria-invalid":!!l,"aria-describedby":l?o:n,required:s,...i,className:"jsx-59fec5f1f0edea5 "+(i&&null!=i.className&&i.className||`db-input ${l?"db-input-error":""}`)}),d&&!l?(0,a.jsx)("p",{id:n,className:"jsx-59fec5f1f0edea5 db-input-helper",children:d}):null,l?(0,a.jsx)("p",{id:o,className:"jsx-59fec5f1f0edea5 db-input-error-text",children:l}):null,(0,a.jsx)(r.default,{id:"59fec5f1f0edea5",children:".db-input-label.jsx-59fec5f1f0edea5{color:var(--color-deep-aqua);margin-bottom:4px;font-weight:600;display:block}.db-required.jsx-59fec5f1f0edea5{color:var(--color-accent-red);margin-left:4px}.db-input.jsx-59fec5f1f0edea5{border:1px solid var(--color-border);width:100%;height:46px;color:var(--color-text);background:#fff;border-radius:10px;padding:0 58px 0 14px;font-size:15px;transition:border-color .12s,box-shadow .12s}.db-input.jsx-59fec5f1f0edea5:focus{border-color:var(--color-primary-teal);outline:none;box-shadow:0 0 0 3px #0096a833}.db-input.jsx-59fec5f1f0edea5::placeholder{color:var(--color-muted)}.db-input-error.jsx-59fec5f1f0edea5{border-color:var(--color-accent-red)}.db-input-helper.jsx-59fec5f1f0edea5{color:var(--color-muted);margin-top:6px;font-size:13px}.db-input-error-text.jsx-59fec5f1f0edea5{color:var(--color-accent-red);margin-top:6px;font-size:13px}"})]})}e.s(["TextInput",()=>t,"default",0,t])},3086,e=>{"use strict";var a=e.i(41526),r=e.i(97679);e.s(["default",0,function(e){return(0,a.jsx)(r.default,{...e})}])},45645,e=>{"use strict";var a=e.i(64467);let r=a.gql`
  mutation StartInsuranceUpload(
    $referralId: ID!
    $frontImageS3Key: String
    $backImageS3Key: String
  ) {
    startInsuranceUpload(
      referralId: $referralId
      frontImageS3Key: $frontImageS3Key
      backImageS3Key: $backImageS3Key
    ) {
      insuranceUpload {
        id
        frontImageS3Key
        backImageS3Key
        ocrStatus
        ocrConfidence
        updatedAt
      }
      errors
    }
  }
`,t=a.gql`
  mutation TriggerInsuranceOcr($referralId: ID!) {
    triggerInsuranceOcr(referralId: $referralId) {
      insuranceUpload {
        id
        ocrStatus
        ocrConfidence
        updatedAt
      }
      errors
    }
  }
`,d=a.gql`
  mutation RecalculateCostEstimate($referralId: ID!) {
    recalculateCostEstimate(referralId: $referralId) {
      costEstimate {
        id
        category
        ruleKey
        explanationText
        updatedAt
      }
      errors
    }
  }
`;e.s(["RECALCULATE_COST_ESTIMATE",0,d,"START_INSURANCE_UPLOAD",0,r,"TRIGGER_INSURANCE_OCR",0,t])},23569,e=>{"use strict";var a=e.i(41526),r=e.i(97679);e.s(["default",0,function({id:e,label:t,value:d,onChange:l,onBlur:s,required:i,disabled:n,error:o,helperText:c,placeholder:u}){return(0,a.jsx)(r.default,{id:e,label:t,value:d,onChange:e=>{let a=e.target.value.replace(/[^\d]/g,""),r=[a.slice(0,3),a.slice(3,6),a.slice(6,10)].filter(e=>e.length>0);l(0===r.length?"":1===r.length?r[0]:2===r.length?`${r[0]}-${r[1]}`:`${r[0]}-${r[1]}-${r[2]}`)},onBlur:s,required:i,disabled:n,error:o,helperText:c,placeholder:u??"555-123-4567",inputMode:"tel",pattern:"^\\\\d{3}-\\\\d{3}-\\\\d{4}$"})}])},42008,(e,a,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0});var t={VALID_LOADERS:function(){return l},imageConfigDefault:function(){return s}};for(var d in t)Object.defineProperty(r,d,{enumerable:!0,get:t[d]});let l=["default","imgix","cloudinary","akamai","custom"],s={deviceSizes:[640,750,828,1080,1200,1920,2048,3840],imageSizes:[32,48,64,96,128,256,384],path:"/_next/image",loader:"default",loaderFile:"",domains:[],disableStaticImages:!1,minimumCacheTTL:14400,formats:["image/webp"],maximumRedirects:3,dangerouslyAllowLocalIP:!1,dangerouslyAllowSVG:!1,contentSecurityPolicy:"script-src 'none'; frame-src 'none'; sandbox;",contentDispositionType:"attachment",localPatterns:void 0,remotePatterns:[],qualities:[75],unoptimized:!1}},78361,(e,a,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"ImageConfigContext",{enumerable:!0,get:function(){return l}});let t=e.r(1646)._(e.r(73658)),d=e.r(42008),l=t.default.createContext(d.imageConfigDefault)},43817,e=>{"use strict";var a=e.i(41526),r=e.i(22366),t=e.i(9793),d=e.i(39491),l=e.i(73658),s=e.i(83724),i=e.i(53949),n=e.i(93962),o=e.i(56421),c=e.i(76245),u=e.i(20979),p=e.i(45645),f=e.i(27941),m=e.i(3086),x=e.i(23569);let b=function({initialValues:e,onSubmit:t,disabled:d,saving:s}){let{register:i,handleSubmit:n,reset:o,control:c,formState:{errors:u,isSubmitting:p}}=(0,f.useForm)({mode:"onBlur",defaultValues:e});(0,l.useEffect)(()=>{o(e)},[e,o]);let b=n(async e=>{await t(e)});return(0,a.jsxs)("form",{onSubmit:b,className:"jsx-45f14d801d5abbb5 insurance-form",children:[(0,a.jsxs)("div",{className:"jsx-45f14d801d5abbb5 field-grid",children:[(0,a.jsx)(m.default,{id:"insurerName",label:"Insurer name",placeholder:"e.g., Blue Shield",disabled:d,error:u.insurerName?.message,...i("insurerName"),onBlur:()=>void b()}),(0,a.jsx)(m.default,{id:"planName",label:"Plan name",placeholder:"Plan name",disabled:d,error:u.planName?.message,...i("planName"),onBlur:()=>void b()}),(0,a.jsx)(m.default,{id:"memberId",label:"Member ID",placeholder:"Member ID",disabled:d,error:u.memberId?.message,...i("memberId"),onBlur:()=>void b()}),(0,a.jsx)(m.default,{id:"groupId",label:"Group ID",placeholder:"Group ID",disabled:d,error:u.groupId?.message,...i("groupId"),onBlur:()=>void b()}),(0,a.jsx)(m.default,{id:"policyholderName",label:"Policyholder name",placeholder:"Name on card",disabled:d,error:u.policyholderName?.message,...i("policyholderName"),onBlur:()=>void b()}),(0,a.jsx)(f.Controller,{control:c,name:"coveragePhone",render:({field:e})=>(0,a.jsx)(x.default,{id:"coveragePhone",label:"Coverage phone",placeholder:"(555) 123-4567",disabled:d,error:u.coveragePhone?.message,value:e.value||"",onChange:e.onChange,onBlur:()=>void b()})}),(0,a.jsx)(m.default,{id:"coverageWebsite",label:"Coverage website",placeholder:"https://insurer.example.com",disabled:d,error:u.coverageWebsite?.message,...i("coverageWebsite"),onBlur:()=>void b()})]}),(0,a.jsx)("div",{"aria-live":"polite",className:"jsx-45f14d801d5abbb5 save-status",children:(s||p)&&"Saving..."}),(0,a.jsx)(r.default,{id:"45f14d801d5abbb5",children:".insurance-form.jsx-45f14d801d5abbb5{flex-direction:column;gap:12px;display:flex}.field-grid.jsx-45f14d801d5abbb5{grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px;display:grid}.save-status.jsx-45f14d801d5abbb5{color:var(--color-muted);min-height:20px;font-weight:600}"})]})};var g=e.i(6725);let h=["image/jpeg","image/png","image/heic","image/heif"],j=function({referralId:e,fileType:t,label:d,existingKey:s,disabled:i,onUploaded:o}){let[c,u]=(0,l.useState)("idle"),[p,f]=(0,l.useState)(""),[m,x]=(0,l.useState)(0),[b,j]=(0,l.useState)(null),I=(0,l.useRef)(null);(0,l.useEffect)(()=>()=>{b&&URL.revokeObjectURL(b)},[b]);let v=(0,l.useCallback)(async a=>{let r=g.default.env.NEXT_PUBLIC_API_BASE_URL||"http://localhost:3001/graphql".replace("/graphql","")||"http://localhost:3001",d=await fetch(`${r}/api/v1/uploads/insurance/presign`,{method:"POST",headers:{"Content-Type":"application/json"},credentials:"include",body:JSON.stringify({referral_id:e,file_type:t,content_type:a.type})});if(!d.ok)throw Error((await d.json().catch(()=>({}))).error||"Unable to start upload");return d.json()},[t,e]),y=(0,l.useCallback)(async e=>{if(e&&!i){if(f(""),u("idle"),!h.includes(e.type))return void f("Please upload a JPG, PNG, or HEIC image.");if(e.size>0xa00000)return void f("File is too large. Max size is 10MB.");u("uploading"),x(0),j(URL.createObjectURL(e));try{let a=await v(e),r=new FormData;Object.entries(a.fields).forEach(([e,a])=>{r.append(e,a)}),r.append("file",e),await new Promise((e,t)=>{let d=new XMLHttpRequest;d.open("POST",a.url,!0),d.upload.onprogress=e=>{if(e.lengthComputable){let a=Math.round(e.loaded/e.total*100);x(a)}},d.onload=()=>{d.status>=200&&d.status<300?e():t(Error("Upload failed"))},d.onerror=()=>t(Error("Upload failed")),d.send(r)}),await o(a.key),u("success"),x(100)}catch(e){u("error"),f(e instanceof Error?e.message:"Upload failed")}}},[i,o,v]),S=()=>I.current?.click();return(0,a.jsxs)("div",{onDrop:e=>{e.preventDefault(),i||y(e.dataTransfer.files?.[0])},onDragOver:e=>e.preventDefault(),className:`jsx-d6d4d1da91111408 upload-card ${i?"disabled":""}`,children:[(0,a.jsxs)("div",{className:"jsx-d6d4d1da91111408 upload-header",children:[(0,a.jsx)("p",{className:"jsx-d6d4d1da91111408 upload-label",children:d}),(0,a.jsx)(n.default,{variant:"ghost",size:"sm",onClick:S,disabled:i,children:s||b?"Replace":"Upload"})]}),(0,a.jsxs)("div",{role:"group","aria-label":d,className:"jsx-d6d4d1da91111408 upload-body",children:[(0,a.jsx)("input",{ref:I,type:"file",accept:h.join(","),style:{display:"none"},onChange:e=>{y(e.target.files?.[0])},disabled:i,className:"jsx-d6d4d1da91111408"}),(0,a.jsx)("div",{onClick:S,className:"jsx-d6d4d1da91111408 dropzone",children:b?(0,a.jsx)("img",{src:b,alt:`${d} preview`,className:"jsx-d6d4d1da91111408 preview"}):s?(0,a.jsx)("div",{className:"jsx-d6d4d1da91111408 uploaded-chip",children:"Card uploaded"}):(0,a.jsxs)("div",{className:"jsx-d6d4d1da91111408 placeholder",children:[(0,a.jsx)("p",{className:"jsx-d6d4d1da91111408",children:"Drag & drop or click to upload"}),(0,a.jsxs)("p",{className:"jsx-d6d4d1da91111408 hint",children:["JPG, PNG, or HEIC. Max ",10,"MB."]})]})}),(0,a.jsxs)("div",{"aria-live":"polite",className:"jsx-d6d4d1da91111408 status",children:["uploading"===c&&`Uploading… ${m}%`,"success"===c&&"Uploaded","error"===c&&p,"idle"===c&&p]})]}),(0,a.jsx)(r.default,{id:"d6d4d1da91111408",children:".upload-card.jsx-d6d4d1da91111408{border:1px dashed var(--color-border);background:#fffaf6;border-radius:14px;flex-direction:column;gap:8px;padding:12px;display:flex}.upload-card.disabled.jsx-d6d4d1da91111408{opacity:.6;cursor:not-allowed}.upload-header.jsx-d6d4d1da91111408{justify-content:space-between;align-items:center;display:flex}.upload-label.jsx-d6d4d1da91111408{color:var(--color-deep-aqua);margin:0;font-weight:700}.upload-body.jsx-d6d4d1da91111408{flex-direction:column;gap:8px;display:flex}.dropzone.jsx-d6d4d1da91111408{border:1px solid var(--color-border);text-align:center;cursor:pointer;background:#fff;border-radius:12px;justify-content:center;align-items:center;min-height:140px;padding:12px;display:flex}.placeholder.jsx-d6d4d1da91111408 p.jsx-d6d4d1da91111408{margin:0}.hint.jsx-d6d4d1da91111408{color:var(--color-muted);font-size:13px}.preview.jsx-d6d4d1da91111408{object-fit:contain;border-radius:10px;max-height:160px}.uploaded-chip.jsx-d6d4d1da91111408{color:var(--color-deep-aqua);background:#0096a81f;border-radius:12px;padding:8px 12px;font-weight:600;display:inline-flex}.status.jsx-d6d4d1da91111408{color:var(--color-muted);min-height:20px;font-weight:600}"})]})},I=[{value:"insured",label:"My child has insurance",description:"Upload your card if you can—it helps us verify faster."},{value:"medicaid",label:"My child has Medicaid",description:"Upload your card if available, or continue without."},{value:"uninsured",label:"My child does not have insurance",description:"You can still continue without uploading a card."},{value:"not_sure",label:"I'm not sure",description:"Select this if you're unsure. You can still submit without a card."}];function v(){let e=(0,d.useRouter)(),{id:f}=e.query,m=(0,l.useMemo)(()=>f||"",[f]),{referral:x,loading:g,error:h,refetch:v}=(0,o.default)(m),[y]=(0,t.useMutation)(u.UPDATE_INSURANCE_DETAILS),[S]=(0,t.useMutation)(u.UPDATE_REFERRAL_STEP),[N]=(0,t.useMutation)(p.START_INSURANCE_UPLOAD),[C]=(0,t.useMutation)(p.TRIGGER_INSURANCE_OCR),[w]=(0,t.useMutation)(p.RECALCULATE_COST_ESTIMATE),[E,P]=(0,l.useState)({insuranceStatus:"",insurerName:"",planName:"",memberId:"",groupId:"",policyholderName:"",coveragePhone:"",coverageWebsite:""}),[A,R]=(0,l.useState)(""),[$,U]=(0,l.useState)(!1),[_,T]=(0,l.useState)(null),[D,k]=(0,l.useState)(!1),q=(0,l.useRef)(null),O=(0,l.useRef)(null),L=x?.insuranceUploads?.[0],K=L?.ocrStatus??null,M=L?.ocrConfidence??null;(0,l.useEffect)(()=>{if(!x?.insuranceDetail)return;let e=x.insuranceDetail;P(a=>({...a,insuranceStatus:e.insuranceStatus,insurerName:e.insurerName??"",planName:e.planName??"",memberId:e.memberId??"",groupId:e.groupId??"",policyholderName:e.policyholderName??"",coveragePhone:e.coveragePhone??"",coverageWebsite:e.coverageWebsite??""}))},[x?.insuranceDetail]),(0,l.useEffect)(()=>{K&&("processing"===O.current&&"complete"===K?T(M&&M<.7?"We read your card, but confidence was low. Please review the details below.":"We read your card. Please review the details below."):"failed"===K&&T("We couldn't read your card. You can still complete this step by typing the details."),O.current=K)},[K,M]),(0,l.useEffect)(()=>{if(D)return q.current=setInterval(()=>{v()},2e3),()=>{q.current&&clearInterval(q.current)}},[D,v]),(0,l.useEffect)(()=>{D&&("complete"===K||"failed"===K)&&(q.current&&clearInterval(q.current),k(!1))},[D,K]);let B=async e=>{if(m){U(!0),R("");try{let{data:a}=await y({variables:{referralId:m,insuranceInput:e}}),r=a?.updateInsuranceDetails?.errors;r?.length?R(r[0]):await w({variables:{referralId:m}})}catch(e){R("Unable to save insurance details right now.")}finally{U(!1)}}},z=async e=>{let a={...E,insuranceStatus:e};P(a),await B(a)},F=async e=>{let a={...e,insuranceStatus:E.insuranceStatus};P(a),await B(a)},G=async(e,a)=>{if(!m)return;let r={};"front"===e?(r.frontImageS3Key=a,r.backImageS3Key=L?.backImageS3Key??void 0):(r.backImageS3Key=a,r.frontImageS3Key=L?.frontImageS3Key??void 0),await N({variables:{referralId:m,frontImageS3Key:r.frontImageS3Key,backImageS3Key:r.backImageS3Key}}),await v()},W=async()=>{if(m){if(!L?.frontImageS3Key&&!L?.backImageS3Key)return void T("Please upload the front or back of your card first.");T("Reading your card…"),k(!0),await C({variables:{referralId:m}})}},H=async()=>{if(!E.insuranceStatus)return void R("Please select your insurance status to continue.");await S({variables:{referralId:m,stepName:"insurance",stepData:{completed:!0}}});let a=(0,c.getNextStep)("insurance");e.push(`/parent/referrals/${m}/onboarding/${a}`)};if(g)return(0,a.jsx)(s.default,{requireRole:"parent",children:(0,a.jsx)("div",{style:{padding:"48px 24px",textAlign:"center"},children:"Loading referral…"})});if(h||!x)return(0,a.jsx)(s.default,{requireRole:"parent",children:(0,a.jsxs)("div",{style:{padding:"48px 24px",textAlign:"center"},children:[(0,a.jsx)("p",{children:"Unable to load this referral."}),(0,a.jsx)(n.default,{onClick:()=>e.push("/parent/dashboard"),children:"Back to dashboard"})]})});let Y=["insured","medicaid"].includes(E.insuranceStatus),X=c.ONBOARDING_STEPS.indexOf("insurance")+1,J=c.ONBOARDING_STEPS.length;return(0,a.jsx)(s.default,{requireRole:"parent",children:(0,a.jsxs)(i.default,{referralId:x.id,currentStep:"insurance",onStepSelect:a=>void e.push(`/parent/referrals/${x.id}/onboarding/${a}`),children:[(0,a.jsxs)("div",{className:"jsx-40078279b93df4c step-header",children:[(0,a.jsxs)("div",{className:"jsx-40078279b93df4c",children:[(0,a.jsxs)("p",{className:"jsx-40078279b93df4c eyebrow",children:["Step ",X," of ",J]}),(0,a.jsx)("h2",{className:"jsx-40078279b93df4c",children:"Insurance information"}),(0,a.jsx)("p",{className:"jsx-40078279b93df4c muted",children:"Select your insurance status and upload your card if available. You can always enter details manually."})]}),(0,a.jsx)("div",{"aria-live":"polite",className:"jsx-40078279b93df4c save-indicator",children:$?"Saving…":A||""})]}),(0,a.jsxs)("div",{className:"jsx-40078279b93df4c card",children:[(0,a.jsx)("h3",{className:"jsx-40078279b93df4c",children:"Insurance status (required)"}),(0,a.jsx)("div",{className:"jsx-40078279b93df4c status-grid",children:I.map(e=>(0,a.jsxs)("button",{type:"button",onClick:()=>void z(e.value),"aria-pressed":E.insuranceStatus===e.value,className:`jsx-40078279b93df4c status-card ${E.insuranceStatus===e.value?"selected":""}`,children:[(0,a.jsx)("span",{className:"jsx-40078279b93df4c status-label",children:e.label}),(0,a.jsx)("span",{className:"jsx-40078279b93df4c status-desc",children:e.description})]},e.value))}),A?(0,a.jsx)("p",{className:"jsx-40078279b93df4c error",children:A}):null]}),Y?(0,a.jsxs)("div",{className:"jsx-40078279b93df4c card",children:[(0,a.jsx)("h3",{className:"jsx-40078279b93df4c",children:"Upload your card (optional but encouraged)"}),(0,a.jsx)("p",{className:"jsx-40078279b93df4c muted",children:"Upload the front and back of your insurance card. We’ll read it automatically so you can confirm the details."}),(0,a.jsxs)("div",{className:"jsx-40078279b93df4c upload-grid",children:[(0,a.jsx)(j,{referralId:m,fileType:"front",label:"Front of card",existingKey:L?.frontImageS3Key,onUploaded:e=>G("front",e)}),(0,a.jsx)(j,{referralId:m,fileType:"back",label:"Back of card",existingKey:L?.backImageS3Key,onUploaded:e=>G("back",e)})]}),(0,a.jsxs)("div",{className:"jsx-40078279b93df4c ocr-row",children:[(0,a.jsx)(n.default,{variant:"primary",size:"sm",onClick:()=>void W(),disabled:"processing"===K,children:"processing"===K?"Processing...":"Process my card"}),(0,a.jsx)("p",{"aria-live":"polite",className:"jsx-40078279b93df4c muted",children:"processing"===K?"Reading your card…":_}),M?(0,a.jsxs)("p",{className:"jsx-40078279b93df4c confidence",children:["Confidence: ",Math.round(100*M),"%"]}):null]})]}):null,(0,a.jsxs)("div",{className:"jsx-40078279b93df4c card",children:[(0,a.jsx)("h3",{className:"jsx-40078279b93df4c",children:"Review or enter details manually"}),(0,a.jsx)("p",{className:"jsx-40078279b93df4c muted",children:"If we read your card, the fields are pre-filled below. You can edit anything before continuing."}),(0,a.jsx)(b,{initialValues:E,onSubmit:F,saving:$})]}),(0,a.jsxs)("div",{className:"jsx-40078279b93df4c nav-actions",children:[(0,a.jsx)(n.default,{variant:"ghost",onClick:()=>{let a;a=(0,c.getPreviousStep)("insurance"),e.push(`/parent/referrals/${m}/onboarding/${a}`)},children:"Back"}),(0,a.jsx)(n.default,{onClick:()=>void H(),children:"Save & Continue"})]}),(0,a.jsx)(r.default,{id:"40078279b93df4c",children:".step-header.jsx-40078279b93df4c{flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;margin-bottom:12px;display:flex}.eyebrow.jsx-40078279b93df4c{color:var(--color-primary-teal);margin:0;font-weight:700}h2.jsx-40078279b93df4c{color:var(--color-deep-aqua);margin:4px 0}.muted.jsx-40078279b93df4c{color:var(--color-muted);margin:0}.save-indicator.jsx-40078279b93df4c{color:var(--color-muted);min-height:20px;font-weight:600}.card.jsx-40078279b93df4c{border:1px solid var(--color-border);background:#fff;border-radius:16px;flex-direction:column;gap:10px;padding:16px;display:flex}.status-grid.jsx-40078279b93df4c{grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px;display:grid}.status-card.jsx-40078279b93df4c{border:1px solid var(--color-border);text-align:left;cursor:pointer;background:#fff;border-radius:12px;padding:12px;transition:border-color .12s,box-shadow .12s,transform .12s}.status-card.selected.jsx-40078279b93df4c{border-color:var(--color-primary-teal);transform:translateY(-1px);box-shadow:0 8px 22px #0096a81f}.status-label.jsx-40078279b93df4c{color:var(--color-deep-aqua);font-weight:700;display:block}.status-desc.jsx-40078279b93df4c{color:var(--color-muted);font-size:14px}.error.jsx-40078279b93df4c{color:var(--color-accent-red);margin:0;font-weight:700}.upload-grid.jsx-40078279b93df4c{grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px;display:grid}.ocr-row.jsx-40078279b93df4c{flex-wrap:wrap;align-items:center;gap:12px;display:flex}.confidence.jsx-40078279b93df4c{color:var(--color-muted);margin:0;font-weight:600}.nav-actions.jsx-40078279b93df4c{flex-wrap:wrap;justify-content:space-between;gap:10px;display:flex}@media (width<=768px){.nav-actions.jsx-40078279b93df4c{flex-direction:column}}"})]})})}e.s(["default",()=>v],43817)},78074,(e,a,r)=>{let t="/parent/referrals/[id]/onboarding/insurance";(window.__NEXT_P=window.__NEXT_P||[]).push([t,()=>e.r(43817)]),a.hot&&a.hot.dispose(function(){window.__NEXT_P.push([t])})},88853,e=>{e.v(a=>Promise.all(["static/chunks/ca6b9ab451866ae2.js"].map(a=>e.l(a))).then(()=>a(33811)))},91751,e=>{e.v(a=>Promise.all(["static/chunks/b0bbf6aa740a2457.js"].map(a=>e.l(a))).then(()=>a(23428)))}]);