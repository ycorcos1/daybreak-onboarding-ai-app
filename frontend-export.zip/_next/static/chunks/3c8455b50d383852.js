__turbopack_load_page_chunks__("/admin/login", [
  "static/chunks/bba9e93bdba3b77e.js",
  "static/chunks/382f3ba59a902a64.js",
  "static/chunks/b6758c396527f921.js",
  "static/chunks/e2b2ee896b4ab52e.js",
  "static/chunks/turbopack-313539c32fff3d82.js"
])
