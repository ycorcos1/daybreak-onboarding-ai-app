__turbopack_load_page_chunks__("/parent/referrals/[id]/onboarding/review", [
  "static/chunks/5a9dcb021b999516.js",
  "static/chunks/9550e7df1660064a.js",
  "static/chunks/b6758c396527f921.js",
  "static/chunks/49611083e9fae018.js",
  "static/chunks/382f3ba59a902a64.js",
  "static/chunks/turbopack-9adc7b0ea8d5ffba.js"
])
