__turbopack_load_page_chunks__("/parent/referrals/[id]/onboarding/cost", [
  "static/chunks/eecd20682858573c.js",
  "static/chunks/9550e7df1660064a.js",
  "static/chunks/b6758c396527f921.js",
  "static/chunks/4b1e92164ea6607d.js",
  "static/chunks/382f3ba59a902a64.js",
  "static/chunks/turbopack-724dc70ada6f10b3.js"
])
