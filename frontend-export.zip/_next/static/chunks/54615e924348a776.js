__turbopack_load_page_chunks__("/auth/login", [
  "static/chunks/4cd981fc1b5015a0.js",
  "static/chunks/c743b7754a7dc85f.js",
  "static/chunks/e2b2ee896b4ab52e.js",
  "static/chunks/b6758c396527f921.js",
  "static/chunks/382f3ba59a902a64.js",
  "static/chunks/turbopack-61b95a7b82549e83.js"
])
