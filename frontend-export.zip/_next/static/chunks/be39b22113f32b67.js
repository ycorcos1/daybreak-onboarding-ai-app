(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,97679,e=>{"use strict";var a=e.i(41526),r=e.i(22366);function t({label:e,id:t,helperText:s,error:d,required:l,...i}){let c=s?`${t}-helper`:void 0,n=d?`${t}-error`:void 0;return(0,a.jsxs)(a.Fragment,{children:[(0,a.jsxs)("label",{htmlFor:t,className:"jsx-59fec5f1f0edea5 db-input-label",children:[e,l?(0,a.jsx)("span",{className:"jsx-59fec5f1f0edea5 db-required",children:"*"}):null]}),(0,a.jsx)("input",{id:t,"aria-invalid":!!d,"aria-describedby":d?n:c,required:l,...i,className:"jsx-59fec5f1f0edea5 "+(i&&null!=i.className&&i.className||`db-input ${d?"db-input-error":""}`)}),s&&!d?(0,a.jsx)("p",{id:c,className:"jsx-59fec5f1f0edea5 db-input-helper",children:s}):null,d?(0,a.jsx)("p",{id:n,className:"jsx-59fec5f1f0edea5 db-input-error-text",children:d}):null,(0,a.jsx)(r.default,{id:"59fec5f1f0edea5",children:".db-input-label.jsx-59fec5f1f0edea5{color:var(--color-deep-aqua);margin-bottom:4px;font-weight:600;display:block}.db-required.jsx-59fec5f1f0edea5{color:var(--color-accent-red);margin-left:4px}.db-input.jsx-59fec5f1f0edea5{border:1px solid var(--color-border);width:100%;height:46px;color:var(--color-text);background:#fff;border-radius:10px;padding:0 58px 0 14px;font-size:15px;transition:border-color .12s,box-shadow .12s}.db-input.jsx-59fec5f1f0edea5:focus{border-color:var(--color-primary-teal);outline:none;box-shadow:0 0 0 3px #0096a833}.db-input.jsx-59fec5f1f0edea5::placeholder{color:var(--color-muted)}.db-input-error.jsx-59fec5f1f0edea5{border-color:var(--color-accent-red)}.db-input-helper.jsx-59fec5f1f0edea5{color:var(--color-muted);margin-top:6px;font-size:13px}.db-input-error-text.jsx-59fec5f1f0edea5{color:var(--color-accent-red);margin-top:6px;font-size:13px}"})]})}e.s(["TextInput",()=>t,"default",0,t])},20979,e=>{"use strict";var a=e.i(64467);let r=a.gql`
  mutation CreateChildAndReferral($childInput: ChildInput!) {
    createChildAndReferral(childInput: $childInput) {
      child {
        id
        name
        grade
        schoolName
        district
      }
      referral {
        id
        status
        lastCompletedStep
        nextStep
      }
      errors
    }
  }
`,t=a.gql`
  mutation UpdateReferralStep(
    $referralId: ID!
    $stepName: String!
    $stepData: JSON
  ) {
    updateReferralStep(
      referralId: $referralId
      stepName: $stepName
      stepData: $stepData
    ) {
      referral {
        id
        status
        lastCompletedStep
        lastUpdatedStepAt
        nextStep
      }
      errors
    }
  }
`,s=a.gql`
  mutation UpdateParentInfo($referralId: ID!, $parentInfo: ParentInfoInput!) {
    updateParentInfo(referralId: $referralId, parentInfo: $parentInfo) {
      user {
        id
        name
        email
        phone
        address
        languagePreference
        relationshipToChild
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,d=a.gql`
  mutation UpdateChildInfo($referralId: ID!, $childInput: ChildInput!) {
    updateChildInfo(referralId: $referralId, childInput: $childInput) {
      child {
        id
        name
        dob
        ageBand
        grade
        schoolName
        district
        state
        primaryLanguage
        pronouns
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,l=a.gql`
  mutation UpdateClinicalIntake($referralId: ID!, $intakeInput: ClinicalIntakeInput!) {
    updateClinicalIntake(referralId: $referralId, intakeInput: $intakeInput) {
      intakeResponse {
        id
        responses
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,i=a.gql`
  mutation UpdateSchedulingPreferences(
    $referralId: ID!
    $schedulingInput: SchedulingPreferenceInput!
  ) {
    updateSchedulingPreferences(referralId: $referralId, schedulingInput: $schedulingInput) {
      schedulingPreference {
        id
        timezone
        locationPreference
        frequency
        clinicianPreferences
        windows
        suggestedWindows
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,c=a.gql`
  mutation SubmitReferral($referralId: ID!) {
    submitReferral(referralId: $referralId) {
      referral {
        id
        status
        packetStatus
        submittedAt
      }
      errors
    }
  }
`,n=a.gql`
  mutation UpdateInsuranceDetails($referralId: ID!, $insuranceInput: InsuranceDetailInput!) {
    updateInsuranceDetails(referralId: $referralId, insuranceInput: $insuranceInput) {
      insuranceDetail {
        id
        insuranceStatus
        insurerName
        planName
        memberId
        groupId
        policyholderName
        coveragePhone
        coverageWebsite
        source
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,o=a.gql`
  mutation AcceptConsents($referralId: ID!, $consents: [ConsentInput!]!) {
    acceptConsents(referralId: $referralId, consents: $consents) {
      consentRecords {
        id
        consentType
        acceptedAt
        ipAddress
        userAgent
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`;e.s(["ACCEPT_CONSENTS",0,o,"CREATE_CHILD_AND_REFERRAL",0,r,"SUBMIT_REFERRAL",0,c,"UPDATE_CHILD_INFO",0,d,"UPDATE_CLINICAL_INTAKE",0,l,"UPDATE_INSURANCE_DETAILS",0,n,"UPDATE_PARENT_INFO",0,s,"UPDATE_REFERRAL_STEP",0,t,"UPDATE_SCHEDULING_PREFERENCES",0,i])},43225,e=>{"use strict";var a=e.i(64467);let r=a.gql`
  query MyNotifications($unreadOnly: Boolean) {
    myNotifications(unreadOnly: $unreadOnly) {
      id
      userId
      referralId
      notificationType
      payloadJsonb
      readAt
      createdAt
    }
  }
`;e.s(["MY_NOTIFICATIONS_QUERY",0,r])},42008,(e,a,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0});var t={VALID_LOADERS:function(){return d},imageConfigDefault:function(){return l}};for(var s in t)Object.defineProperty(r,s,{enumerable:!0,get:t[s]});let d=["default","imgix","cloudinary","akamai","custom"],l={deviceSizes:[640,750,828,1080,1200,1920,2048,3840],imageSizes:[32,48,64,96,128,256,384],path:"/_next/image",loader:"default",loaderFile:"",domains:[],disableStaticImages:!1,minimumCacheTTL:14400,formats:["image/webp"],maximumRedirects:3,dangerouslyAllowLocalIP:!1,dangerouslyAllowSVG:!1,contentSecurityPolicy:"script-src 'none'; frame-src 'none'; sandbox;",contentDispositionType:"attachment",localPatterns:void 0,remotePatterns:[],qualities:[75],unoptimized:!1}},78361,(e,a,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"ImageConfigContext",{enumerable:!0,get:function(){return d}});let t=e.r(1646)._(e.r(73658)),s=e.r(42008),d=t.default.createContext(s.imageConfigDefault)},56364,e=>{"use strict";var a=e.i(41526),r=e.i(22366),t=e.i(83724),s=e.i(7282),d=e.i(50107),l=e.i(93962),i=e.i(97679),c=e.i(9793),n=e.i(9910),o=e.i(73658),u=e.i(39491),p=e.i(76245);let f={draft:"Draft",submitted:"Submitted",in_review:"In review",ready_to_schedule:"Ready to schedule",scheduled:"Scheduled",closed:"Closed",withdrawn:"Withdrawn"},b=function({referrals:e,onResume:t,onView:s}){return e.length?(0,a.jsxs)("div",{className:"jsx-6d3b24a63226d737 referral-grid",children:[e.map(e=>{let r="string"==typeof e.status?e.status.toLowerCase():e.status,i=f[r]??e.status??"Unknown",c=e.lastCompletedStep&&"string"==typeof e.lastCompletedStep?e.lastCompletedStep.toLowerCase():e.lastCompletedStep||null,n=e.nextStep||(c&&p.ONBOARDING_STEPS.includes(c)?(0,p.getNextStep)(c):p.ONBOARDING_STEPS[0]);return(0,a.jsxs)(d.default,{className:"referral-card",padding:"20px",children:[(0,a.jsxs)("div",{className:"jsx-6d3b24a63226d737 referral-header",children:[(0,a.jsxs)("div",{className:"jsx-6d3b24a63226d737",children:[(0,a.jsx)("p",{className:"jsx-6d3b24a63226d737 referral-eyebrow",children:"Child"}),(0,a.jsx)("h3",{className:"jsx-6d3b24a63226d737",children:e.child.name}),(0,a.jsxs)("p",{className:"jsx-6d3b24a63226d737 meta",children:["Grade ",e.child.grade," · ",e.child.schoolName]})]}),(0,a.jsx)("span",{className:`jsx-6d3b24a63226d737 status ${r}`,children:i})]}),(0,a.jsxs)("p",{className:"jsx-6d3b24a63226d737 meta",children:["District: ",e.child.district||"Not provided"]}),(0,a.jsxs)("p",{className:"jsx-6d3b24a63226d737 meta",children:["Last step: ",c||"Not started"]}),(0,a.jsx)("div",{className:"jsx-6d3b24a63226d737 actions",children:"draft"===r?(0,a.jsx)(l.default,{size:"sm",onClick:()=>t(e.id,n),children:"Resume onboarding"}):(0,a.jsx)(l.default,{variant:"ghost",size:"sm",onClick:()=>s?s(e.id):t(e.id,"review"),children:"View details"})})]},e.id)}),(0,a.jsx)(r.default,{id:"6d3b24a63226d737",children:".referral-grid.jsx-6d3b24a63226d737{grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:14px;display:grid}.referral-card.jsx-6d3b24a63226d737{background:#fff}.referral-header.jsx-6d3b24a63226d737{justify-content:space-between;align-items:flex-start;gap:10px;display:flex}.referral-eyebrow.jsx-6d3b24a63226d737{color:var(--color-primary-teal);margin:0;font-weight:700}h3.jsx-6d3b24a63226d737{color:var(--color-deep-aqua);margin:4px 0}.meta.jsx-6d3b24a63226d737{color:var(--color-muted);margin:2px 0;font-size:14px}.status.jsx-6d3b24a63226d737{color:var(--color-deep-aqua);background:#eef2f5;border:1px solid #d6dfe5;border-radius:999px;padding:6px 12px;font-size:13px;font-weight:600}.status.draft.jsx-6d3b24a63226d737{color:#b86800;background:#fff4ec;border-color:#ffd7b0}.status.submitted.jsx-6d3b24a63226d737,.status.in_review.jsx-6d3b24a63226d737,.status.ready_to_schedule.jsx-6d3b24a63226d737{color:#007a8c;background:#e6f7fa;border-color:#b7e5ee}.status.scheduled.jsx-6d3b24a63226d737{color:#1c8554;background:#e9f8f1;border-color:#c5ecd9}.status.withdrawn.jsx-6d3b24a63226d737{color:#b30000;background:#ffe9e9;border-color:#ffc2c2}.actions.jsx-6d3b24a63226d737{margin-top:12px}.empty-card.jsx-6d3b24a63226d737{background:#fff}"})]}):(0,a.jsxs)(d.default,{className:"empty-card",children:[(0,a.jsx)("h3",{children:"No referrals yet"}),(0,a.jsx)("p",{children:"Start a referral to begin onboarding for your child."})]})};var x=e.i(12190),m=e.i(20979),h=e.i(43225),g=e.i(47141);let j={name:"",grade:"",schoolName:"",district:"",dob:""};function I(){let{currentUser:e}=(0,s.default)(),f=(0,u.useRouter)(),[I,N]=(0,o.useState)(j),[v,S]=(0,o.useState)(null),{data:y,loading:C,error:w}=(0,n.useQuery)(x.MY_REFERRALS_QUERY),{data:_}=(0,n.useQuery)(h.MY_NOTIFICATIONS_QUERY,{variables:{unreadOnly:!0}}),[R,{loading:A}]=(0,c.useMutation)(m.CREATE_CHILD_AND_REFERRAL,{refetchQueries:[{query:x.MY_REFERRALS_QUERY}]}),E=(0,o.useMemo)(()=>y?.myReferrals??[],[y?.myReferrals]),$=async()=>{if(S(null),Object.entries(I).filter(([,e])=>!e.trim()).length)return void S("Please complete all required fields.");try{let e=await R({variables:{childInput:{name:I.name,grade:I.grade,schoolName:I.schoolName,district:I.district,dob:I.dob}}}),a=e.data?.createChildAndReferral;if(a?.errors?.length)return void S(a.errors.join(", "));let r=a?.referral?.id;r&&(N(j),f.push(`/parent/referrals/${r}/onboarding/${p.ONBOARDING_STEPS[0]}`))}catch{S("Something went wrong. Please try again.")}},P=_?.myNotifications?.length??0;return(0,a.jsxs)(t.default,{requireRole:"parent",children:[(0,a.jsxs)("div",{className:"jsx-8c455b54c3b9a494 dash",children:[(0,a.jsx)("div",{className:"jsx-8c455b54c3b9a494 dash-header",children:(0,a.jsxs)("div",{className:"jsx-8c455b54c3b9a494",children:[(0,a.jsx)("p",{className:"jsx-8c455b54c3b9a494 eyebrow",children:"Welcome"}),(0,a.jsxs)("h1",{className:"jsx-8c455b54c3b9a494 title",children:["Hi, ",e?.name||"there","!"]}),(0,a.jsx)("p",{className:"jsx-8c455b54c3b9a494 subtitle",children:"Start a referral, pick up where you left off, or review updates."})]})}),(0,a.jsxs)("div",{className:"jsx-8c455b54c3b9a494 grid",children:[(0,a.jsxs)(d.default,{className:"start-card",children:[(0,a.jsx)("h2",{className:"jsx-8c455b54c3b9a494",children:"Start a referral"}),(0,a.jsx)("p",{className:"jsx-8c455b54c3b9a494 muted",children:"One referral per child. We’ll save your progress automatically."}),(0,a.jsxs)("div",{className:"jsx-8c455b54c3b9a494 form-grid",children:[(0,a.jsx)(i.default,{id:"child-dob",label:"Date of birth",type:"date",required:!0,value:I.dob,onChange:e=>N(a=>({...a,dob:e.target.value}))}),(0,a.jsx)(i.default,{id:"child-name",label:"Child name",required:!0,value:I.name,onChange:e=>N(a=>({...a,name:e.target.value}))}),(0,a.jsx)(i.default,{id:"child-grade",label:"Grade",required:!0,value:I.grade,onChange:e=>N(a=>({...a,grade:e.target.value}))}),(0,a.jsx)(i.default,{id:"child-school",label:"School name",required:!0,value:I.schoolName,onChange:e=>N(a=>({...a,schoolName:e.target.value}))}),(0,a.jsx)(i.default,{id:"child-district",label:"District",required:!0,value:I.district,onChange:e=>N(a=>({...a,district:e.target.value}))})]}),v?(0,a.jsx)("p",{className:"jsx-8c455b54c3b9a494 error-text",children:v}):null,(0,a.jsx)("div",{className:"jsx-8c455b54c3b9a494 actions",children:(0,a.jsx)(l.default,{onClick:$,disabled:A,isFullWidth:!0,children:A?"Creating...":"Start referral"})})]}),(0,a.jsxs)(d.default,{className:"notifications",children:[(0,a.jsxs)("div",{className:"jsx-8c455b54c3b9a494 quick-row",children:[(0,a.jsxs)("div",{className:"jsx-8c455b54c3b9a494",children:[(0,a.jsx)("h3",{className:"jsx-8c455b54c3b9a494",children:"Notifications"}),(0,a.jsx)("p",{className:"jsx-8c455b54c3b9a494 muted",children:"See updates on submissions, withdrawals, and requests."})]}),P>0?(0,a.jsx)("span",{className:"jsx-8c455b54c3b9a494 badge",children:P}):null]}),(0,a.jsx)(l.default,{variant:"ghost",onClick:()=>f.push("/parent/notifications"),isFullWidth:!0,children:"View notifications"})]}),(0,a.jsxs)(d.default,{className:"resources",children:[(0,a.jsx)("h3",{className:"jsx-8c455b54c3b9a494",children:"Support resources"}),(0,a.jsx)("p",{className:"jsx-8c455b54c3b9a494 muted",children:"Articles, videos, and tools to help you and your child."}),(0,a.jsx)(l.default,{variant:"ghost",onClick:()=>f.push("/parent/resources"),isFullWidth:!0,children:"Browse resources"})]})]}),(0,a.jsxs)("section",{className:"jsx-8c455b54c3b9a494 referrals-section",children:[(0,a.jsxs)("div",{className:"jsx-8c455b54c3b9a494 referrals-header",children:[(0,a.jsx)("h2",{className:"jsx-8c455b54c3b9a494",children:"Your referrals"}),(0,a.jsx)("p",{className:"jsx-8c455b54c3b9a494 muted",children:"Resume onboarding or review submitted referrals."})]}),C&&(0,a.jsx)("p",{className:"jsx-8c455b54c3b9a494",children:"Loading referrals…"}),w&&(0,a.jsx)("p",{className:"jsx-8c455b54c3b9a494 error-text",children:"Unable to load referrals. Please refresh."}),C||w?null:(0,a.jsx)(b,{referrals:E,onResume:(e,a)=>{let r=a&&p.ONBOARDING_STEPS.includes(a)?a:p.ONBOARDING_STEPS[0];f.push(`/parent/referrals/${e}/onboarding/${r}`)},onView:e=>{f.push(`/parent/referrals/${e}`)}})]})]}),(0,a.jsx)(g.default,{}),(0,a.jsx)(r.default,{id:"8c455b54c3b9a494",children:".dash.jsx-8c455b54c3b9a494{flex-direction:column;gap:20px;max-width:1100px;margin:0 auto;padding:32px 18px 48px;display:flex}.dash-header.jsx-8c455b54c3b9a494{flex-wrap:wrap;justify-content:space-between;align-items:center;gap:16px;display:flex}.eyebrow.jsx-8c455b54c3b9a494{color:var(--color-primary-teal);margin:0 0 6px;font-weight:700}.title.jsx-8c455b54c3b9a494{margin:0 0 6px}.subtitle.jsx-8c455b54c3b9a494{color:var(--color-muted);margin:0}.grid.jsx-8c455b54c3b9a494{grid-template-columns:repeat(auto-fit,minmax(260px,1fr));align-items:start;gap:12px;display:grid}.start-card.jsx-8c455b54c3b9a494,.notifications.jsx-8c455b54c3b9a494,.resources.jsx-8c455b54c3b9a494{background:#fff}.muted.jsx-8c455b54c3b9a494{color:var(--color-muted);margin:4px 0 16px}.form-grid.jsx-8c455b54c3b9a494{grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin-bottom:12px;display:grid}.actions.jsx-8c455b54c3b9a494{margin-top:8px}.error-text.jsx-8c455b54c3b9a494{color:var(--color-accent-red);margin:6px 0}.referrals-section.jsx-8c455b54c3b9a494{flex-direction:column;gap:10px;margin-top:10px;display:flex}.quick-row.jsx-8c455b54c3b9a494{justify-content:space-between;align-items:center;gap:8px;display:flex}.badge.jsx-8c455b54c3b9a494{color:#fff;background:#ff4b4b;border-radius:999px;justify-content:center;align-items:center;min-width:28px;height:28px;padding:0 8px;font-weight:700;display:inline-flex}.referrals-header.jsx-8c455b54c3b9a494{flex-wrap:wrap;align-items:baseline;gap:10px;display:flex}@media (width<=900px){.grid.jsx-8c455b54c3b9a494{grid-template-columns:1fr}}"})]})}e.s(["default",()=>I],56364)},7776,(e,a,r)=>{let t="/parent/dashboard";(window.__NEXT_P=window.__NEXT_P||[]).push([t,()=>e.r(56364)]),a.hot&&a.hot.dispose(function(){window.__NEXT_P.push([t])})},88853,e=>{e.v(a=>Promise.all(["static/chunks/ca6b9ab451866ae2.js"].map(a=>e.l(a))).then(()=>a(33811)))},91751,e=>{e.v(a=>Promise.all(["static/chunks/b0bbf6aa740a2457.js"].map(a=>e.l(a))).then(()=>a(23428)))}]);