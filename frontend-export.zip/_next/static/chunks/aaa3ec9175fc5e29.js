__turbopack_load_page_chunks__("/_error", [
  "static/chunks/66c1e8d91a24b022.js",
  "static/chunks/b6758c396527f921.js",
  "static/chunks/382f3ba59a902a64.js",
  "static/chunks/turbopack-c5c3ac41fffbf2cd.js"
])
