__turbopack_load_page_chunks__("/parent/referrals/[id]", [
  "static/chunks/c785bd99618a6130.js",
  "static/chunks/382f3ba59a902a64.js",
  "static/chunks/b6758c396527f921.js",
  "static/chunks/4b1e92164ea6607d.js",
  "static/chunks/turbopack-9bc51530518615fc.js"
])
