__turbopack_load_page_chunks__("/", [
  "static/chunks/8308880e189e0aa6.js",
  "static/chunks/b6758c396527f921.js",
  "static/chunks/382f3ba59a902a64.js",
  "static/chunks/turbopack-9e9b4c8b0e88dace.js"
])
