__turbopack_load_page_chunks__("/parent/notifications", [
  "static/chunks/da7f651d489c5b79.js",
  "static/chunks/382f3ba59a902a64.js",
  "static/chunks/b6758c396527f921.js",
  "static/chunks/4b1e92164ea6607d.js",
  "static/chunks/turbopack-27d0ad1e63e5199b.js"
])
