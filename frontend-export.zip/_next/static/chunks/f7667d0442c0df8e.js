__turbopack_load_page_chunks__("/parent/referrals/[id]/onboarding/[step]", [
  "static/chunks/ced0c51ed05b54cd.js",
  "static/chunks/9550e7df1660064a.js",
  "static/chunks/b6758c396527f921.js",
  "static/chunks/bb660b55afbbf809.js",
  "static/chunks/382f3ba59a902a64.js",
  "static/chunks/turbopack-5f365ba99098ee95.js"
])
