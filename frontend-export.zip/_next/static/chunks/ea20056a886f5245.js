(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,20979,e=>{"use strict";var t=e.i(64467);let r=t.gql`
  mutation CreateChildAndReferral($childInput: ChildInput!) {
    createChildAndReferral(childInput: $childInput) {
      child {
        id
        name
        grade
        schoolName
        district
      }
      referral {
        id
        status
        lastCompletedStep
        nextStep
      }
      errors
    }
  }
`,a=t.gql`
  mutation UpdateReferralStep(
    $referralId: ID!
    $stepName: String!
    $stepData: JSON
  ) {
    updateReferralStep(
      referralId: $referralId
      stepName: $stepName
      stepData: $stepData
    ) {
      referral {
        id
        status
        lastCompletedStep
        lastUpdatedStepAt
        nextStep
      }
      errors
    }
  }
`,n=t.gql`
  mutation UpdateParentInfo($referralId: ID!, $parentInfo: ParentInfoInput!) {
    updateParentInfo(referralId: $referralId, parentInfo: $parentInfo) {
      user {
        id
        name
        email
        phone
        address
        languagePreference
        relationshipToChild
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,s=t.gql`
  mutation UpdateChildInfo($referralId: ID!, $childInput: ChildInput!) {
    updateChildInfo(referralId: $referralId, childInput: $childInput) {
      child {
        id
        name
        dob
        ageBand
        grade
        schoolName
        district
        state
        primaryLanguage
        pronouns
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,i=t.gql`
  mutation UpdateClinicalIntake($referralId: ID!, $intakeInput: ClinicalIntakeInput!) {
    updateClinicalIntake(referralId: $referralId, intakeInput: $intakeInput) {
      intakeResponse {
        id
        responses
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,d=t.gql`
  mutation UpdateSchedulingPreferences(
    $referralId: ID!
    $schedulingInput: SchedulingPreferenceInput!
  ) {
    updateSchedulingPreferences(referralId: $referralId, schedulingInput: $schedulingInput) {
      schedulingPreference {
        id
        timezone
        locationPreference
        frequency
        clinicianPreferences
        windows
        suggestedWindows
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,l=t.gql`
  mutation SubmitReferral($referralId: ID!) {
    submitReferral(referralId: $referralId) {
      referral {
        id
        status
        packetStatus
        submittedAt
      }
      errors
    }
  }
`,o=t.gql`
  mutation UpdateInsuranceDetails($referralId: ID!, $insuranceInput: InsuranceDetailInput!) {
    updateInsuranceDetails(referralId: $referralId, insuranceInput: $insuranceInput) {
      insuranceDetail {
        id
        insuranceStatus
        insurerName
        planName
        memberId
        groupId
        policyholderName
        coveragePhone
        coverageWebsite
        source
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`,c=t.gql`
  mutation AcceptConsents($referralId: ID!, $consents: [ConsentInput!]!) {
    acceptConsents(referralId: $referralId, consents: $consents) {
      consentRecords {
        id
        consentType
        acceptedAt
        ipAddress
        userAgent
      }
      referral {
        id
        lastCompletedStep
        lastUpdatedStepAt
      }
      errors
    }
  }
`;e.s(["ACCEPT_CONSENTS",0,c,"CREATE_CHILD_AND_REFERRAL",0,r,"SUBMIT_REFERRAL",0,l,"UPDATE_CHILD_INFO",0,s,"UPDATE_CLINICAL_INTAKE",0,i,"UPDATE_INSURANCE_DETAILS",0,o,"UPDATE_PARENT_INFO",0,n,"UPDATE_REFERRAL_STEP",0,a,"UPDATE_SCHEDULING_PREFERENCES",0,d])},3308,e=>{"use strict";var t=e.i(41526),r=e.i(22366);e.s(["default",0,function({message:e}){return e?(0,t.jsxs)("div",{role:"alert","aria-live":"assertive",className:"jsx-3a06f6b875d5b277 validation-error",children:[e,(0,t.jsx)(r.default,{id:"3a06f6b875d5b277",children:".validation-error.jsx-3a06f6b875d5b277{color:var(--color-accent-red);border:1px solid var(--color-accent-red);background:#ff4b4b1a;border-radius:12px;padding:10px 12px;font-weight:600}"})]}):null}])},42008,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0});var a={VALID_LOADERS:function(){return s},imageConfigDefault:function(){return i}};for(var n in a)Object.defineProperty(r,n,{enumerable:!0,get:a[n]});let s=["default","imgix","cloudinary","akamai","custom"],i={deviceSizes:[640,750,828,1080,1200,1920,2048,3840],imageSizes:[32,48,64,96,128,256,384],path:"/_next/image",loader:"default",loaderFile:"",domains:[],disableStaticImages:!1,minimumCacheTTL:14400,formats:["image/webp"],maximumRedirects:3,dangerouslyAllowLocalIP:!1,dangerouslyAllowSVG:!1,contentSecurityPolicy:"script-src 'none'; frame-src 'none'; sandbox;",contentDispositionType:"attachment",localPatterns:void 0,remotePatterns:[],qualities:[75],unoptimized:!1}},78361,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"ImageConfigContext",{enumerable:!0,get:function(){return s}});let a=e.r(1646)._(e.r(73658)),n=e.r(42008),s=a.default.createContext(n.imageConfigDefault)},43018,e=>{"use strict";var t=e.i(41526),r=e.i(22366),a=e.i(9793),n=e.i(39491),s=e.i(73658),i=e.i(83724),d=e.i(53949),l=e.i(93962),o=e.i(56421),c=e.i(76245),p=e.i(20979),u=e.i(3308);let f=["terms_of_use","privacy_policy","non_emergency_acknowledgment","telehealth_consent","guardian_authorization"],h={terms_of_use:"TERMS_OF_USE",privacy_policy:"PRIVACY_POLICY",non_emergency_acknowledgment:"NON_EMERGENCY_ACKNOWLEDGMENT",telehealth_consent:"TELEHEALTH_CONSENT",guardian_authorization:"GUARDIAN_AUTHORIZATION"};function m(){let e=(0,n.useRouter)(),{id:m}=e.query,x=(0,s.useMemo)(()=>m||"",[m]),{referral:I,loading:_,error:b,refetch:v}=(0,o.default)(x),[j]=(0,a.useMutation)(p.ACCEPT_CONSENTS),[y,S]=(0,s.useState)(""),[C,N]=(0,s.useState)("idle"),[A,P]=(0,s.useState)({terms_of_use:!1,privacy_policy:!1,non_emergency_acknowledgment:!1,telehealth_consent:!1,guardian_authorization:!1});(0,s.useEffect)(()=>{if(!I?.consentRecords)return;let e={terms_of_use:!1,privacy_policy:!1,non_emergency_acknowledgment:!1,telehealth_consent:!1,guardian_authorization:!1};I.consentRecords.forEach(t=>{f.includes(t.consentType)&&(e[t.consentType]=!0)}),P(e)},[I]);let E=f.every(e=>A[e]),R=async t=>{if(x){if(!E){S("Please accept all required consents to continue."),N("error");return}S(""),N("saving");try{let r=new Date().toISOString(),a="undefined"!=typeof navigator?navigator.userAgent:void 0,{data:n}=await j({variables:{referralId:x,consents:f.map(e=>({consentType:h[e],acceptedAt:r,ipAddress:null,userAgent:a}))},refetchQueries:["Referral"],awaitRefetchQueries:!0}),s=n?.acceptConsents?.errors,i=n?.acceptConsents?.consentRecords??[];if(s?.length||i.length<f.length){S("We couldn’t save all consents. Please try again. If this continues, refresh and retry."),N("error");return}if(await v(),P({terms_of_use:!0,privacy_policy:!0,non_emergency_acknowledgment:!0,telehealth_consent:!0,guardian_authorization:!0}),N("saved"),setTimeout(()=>N("idle"),1200),t){let t=(0,c.getNextStep)("consent");e.push(`/parent/referrals/${x}/onboarding/${t}`)}}catch{S("Unable to save consents right now. Please try again."),N("error")}}},T=e=>{P(t=>({...t,[e]:!t[e]}))};return((0,s.useEffect)(()=>{E&&R()},[E]),_)?(0,t.jsx)(i.default,{requireRole:"parent",children:(0,t.jsx)("div",{style:{padding:"48px 24px",textAlign:"center"},children:"Loading referral…"})}):b||!I?(0,t.jsx)(i.default,{requireRole:"parent",children:(0,t.jsxs)("div",{style:{padding:"48px 24px",textAlign:"center"},children:[(0,t.jsx)("p",{children:"Unable to load this referral."}),(0,t.jsx)(l.default,{onClick:()=>e.push("/parent/dashboard"),children:"Back to dashboard"})]})}):(0,t.jsx)(i.default,{requireRole:"parent",children:(0,t.jsxs)(d.default,{referralId:I.id,currentStep:"consent",onStepSelect:t=>"consent"===t?void 0:void e.push(`/parent/referrals/${I.id}/onboarding/${t}`),children:[(0,t.jsxs)("div",{className:"jsx-f7155035d5c11058 step-header",children:[(0,t.jsxs)("div",{className:"jsx-f7155035d5c11058",children:[(0,t.jsx)("p",{className:"jsx-f7155035d5c11058 eyebrow",children:"Step 8 of 9"}),(0,t.jsx)("h2",{className:"jsx-f7155035d5c11058",children:"Review and consent"}),(0,t.jsx)("p",{className:"jsx-f7155035d5c11058 muted",children:"Please review and accept all required consents. This site is not for emergencies."})]}),(0,t.jsxs)("div",{"aria-live":"polite",className:"jsx-f7155035d5c11058 save-indicator",children:["saving"===C&&"Saving…","saved"===C&&"Saved","error"===C&&"Save error"]})]}),y?(0,t.jsx)(u.default,{message:y}):null,(0,t.jsxs)("div",{className:"jsx-f7155035d5c11058 consent-list",children:[(0,t.jsx)(g,{title:"Terms of Use",description:"I have read and agree to Daybreak's Terms of Use.",checked:A.terms_of_use,onChange:()=>T("terms_of_use"),linkLabel:"Read Terms of Use",linkHref:"#"}),(0,t.jsx)(g,{title:"Privacy Policy",description:"I have read and agree to Daybreak's Privacy Policy and understand how my data will be used.",checked:A.privacy_policy,onChange:()=>T("privacy_policy"),linkLabel:"Read Privacy Policy",linkHref:"#"}),(0,t.jsx)(g,{title:"Non-emergency acknowledgment",description:"I understand this site is not for emergencies. For emergencies, I will call 911 or go to the nearest ER.",checked:A.non_emergency_acknowledgment,onChange:()=>T("non_emergency_acknowledgment"),emphasis:!0}),(0,t.jsx)(g,{title:"Telehealth consent",description:"I consent to receiving mental health services via telehealth where appropriate.",checked:A.telehealth_consent,onChange:()=>T("telehealth_consent")}),(0,t.jsx)(g,{title:"Guardian authorization",description:"I confirm that I am the legal guardian of this child and have the authority to seek care on their behalf.",checked:A.guardian_authorization,onChange:()=>T("guardian_authorization")})]}),(0,t.jsxs)("div",{className:"jsx-f7155035d5c11058 actions",children:[(0,t.jsx)(l.default,{type:"button",variant:"ghost",onClick:()=>{let t=(0,c.getPreviousStep)("consent");e.push(`/parent/referrals/${x}/onboarding/${t}`)},children:"Back"}),(0,t.jsx)(l.default,{type:"button",disabled:!E,onClick:()=>void R(!0),children:"Save & Continue"})]}),(0,t.jsx)(r.default,{id:"f7155035d5c11058",children:".step-header.jsx-f7155035d5c11058{flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;margin-bottom:12px;display:flex}.eyebrow.jsx-f7155035d5c11058{color:var(--color-primary-teal);margin:0;font-weight:700}h2.jsx-f7155035d5c11058{color:var(--color-deep-aqua);margin:4px 0}.muted.jsx-f7155035d5c11058{color:var(--color-muted);margin:0}.save-indicator.jsx-f7155035d5c11058{color:var(--color-muted);font-weight:600}.consent-list.jsx-f7155035d5c11058{grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:14px;margin:12px 0;display:grid}.actions.jsx-f7155035d5c11058{justify-content:flex-end;gap:12px;margin-top:8px;display:flex}"})]})})}function g({title:e,description:a,checked:n,onChange:s,linkLabel:i,linkHref:d,emphasis:l}){return(0,t.jsxs)("div",{className:`jsx-8178f2f9b8dc4e4d consent-card ${l?"emphasis":""}`,children:[(0,t.jsxs)("label",{className:"jsx-8178f2f9b8dc4e4d",children:[(0,t.jsx)("input",{type:"checkbox",checked:n,onChange:s,className:"jsx-8178f2f9b8dc4e4d"}),(0,t.jsxs)("div",{className:"jsx-8178f2f9b8dc4e4d content",children:[(0,t.jsx)("h3",{className:"jsx-8178f2f9b8dc4e4d",children:e}),(0,t.jsx)("p",{className:"jsx-8178f2f9b8dc4e4d",children:a}),i&&d?(0,t.jsx)("a",{href:d,target:"_blank",rel:"noreferrer",className:"jsx-8178f2f9b8dc4e4d",children:i}):null]})]}),(0,t.jsx)(r.default,{id:"8178f2f9b8dc4e4d",children:".consent-card.jsx-8178f2f9b8dc4e4d{background:var(--color-warm-beige);border:1px solid var(--color-border);border-radius:16px;padding:14px}.consent-card.emphasis.jsx-8178f2f9b8dc4e4d{border-color:var(--color-accent-red)}label.jsx-8178f2f9b8dc4e4d{cursor:pointer;align-items:flex-start;gap:10px;display:flex}input[type=checkbox].jsx-8178f2f9b8dc4e4d{width:18px;height:18px;margin-top:6px}.content.jsx-8178f2f9b8dc4e4d h3.jsx-8178f2f9b8dc4e4d{margin:0 0 4px}.content.jsx-8178f2f9b8dc4e4d p.jsx-8178f2f9b8dc4e4d{color:var(--color-text);margin:0 0 6px}a.jsx-8178f2f9b8dc4e4d{color:var(--color-primary-teal);font-weight:600}"})]})}e.s(["default",()=>m])},98484,(e,t,r)=>{let a="/parent/referrals/[id]/onboarding/consent";(window.__NEXT_P=window.__NEXT_P||[]).push([a,()=>e.r(43018)]),t.hot&&t.hot.dispose(function(){window.__NEXT_P.push([a])})},88853,e=>{e.v(t=>Promise.all(["static/chunks/ca6b9ab451866ae2.js"].map(t=>e.l(t))).then(()=>t(33811)))},91751,e=>{e.v(t=>Promise.all(["static/chunks/b0bbf6aa740a2457.js"].map(t=>e.l(t))).then(()=>t(23428)))}]);