__turbopack_load_page_chunks__("/parent/dashboard", [
  "static/chunks/be39b22113f32b67.js",
  "static/chunks/c6b12185b031536b.js",
  "static/chunks/bb660b55afbbf809.js",
  "static/chunks/b6758c396527f921.js",
  "static/chunks/382f3ba59a902a64.js",
  "static/chunks/turbopack-4163a6ed02e35883.js"
])
