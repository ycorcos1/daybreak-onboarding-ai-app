__turbopack_load_page_chunks__("/parent/referrals/[id]/details", [
  "static/chunks/9c8b50c02042cf0c.js",
  "static/chunks/382f3ba59a902a64.js",
  "static/chunks/b6758c396527f921.js",
  "static/chunks/4b1e92164ea6607d.js",
  "static/chunks/turbopack-f7d116fd6ef6edfe.js"
])
