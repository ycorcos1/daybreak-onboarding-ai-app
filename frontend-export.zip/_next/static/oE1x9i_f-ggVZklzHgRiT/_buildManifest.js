self.__BUILD_MANIFEST = {
  "/": [
    "static/chunks/df8b6d91d24f193a.js"
  ],
  "/_error": [
    "static/chunks/aaa3ec9175fc5e29.js"
  ],
  "/admin/chats": [
    "static/chunks/cde769a2aa7e52db.js"
  ],
  "/admin/chats/[id]": [
    "static/chunks/c96212576f24b225.js"
  ],
  "/admin/login": [
    "static/chunks/3c8455b50d383852.js"
  ],
  "/admin/referrals": [
    "static/chunks/97b3bb7969e73459.js"
  ],
  "/admin/referrals/[id]": [
    "static/chunks/b0487a35e03351ca.js"
  ],
  "/admin/resources": [
    "static/chunks/4a2966bbc7bee93e.js"
  ],
  "/admin/resources/[id]": [
    "static/chunks/26eefd547a8f1b56.js"
  ],
  "/admin/resources/new": [
    "static/chunks/0610735c8f31347a.js"
  ],
  "/auth/login": [
    "static/chunks/54615e924348a776.js"
  ],
  "/auth/signup": [
    "static/chunks/8831682dfa2031f3.js"
  ],
  "/parent/dashboard": [
    "static/chunks/0db22beb4897c71c.js"
  ],
  "/parent/notifications": [
    "static/chunks/92bc1a4b41276784.js"
  ],
  "/parent/referrals/[id]": [
    "static/chunks/edd5e4f0c516ec86.js"
  ],
  "/parent/referrals/[id]/details": [
    "static/chunks/9711ebc90aa242a4.js"
  ],
  "/parent/referrals/[id]/onboarding/[step]": [
    "static/chunks/f7667d0442c0df8e.js"
  ],
  "/parent/referrals/[id]/onboarding/child-info": [
    "static/chunks/3e70e878e887b6cf.js"
  ],
  "/parent/referrals/[id]/onboarding/consent": [
    "static/chunks/3eaff6e14ca538dd.js"
  ],
  "/parent/referrals/[id]/onboarding/cost": [
    "static/chunks/afe2c9ba52f8b9b6.js"
  ],
  "/parent/referrals/[id]/onboarding/insurance": [
    "static/chunks/fd48ccea43a9fdc8.js"
  ],
  "/parent/referrals/[id]/onboarding/intake": [
    "static/chunks/6c1514ed685cb404.js"
  ],
  "/parent/referrals/[id]/onboarding/parent-info": [
    "static/chunks/231713d4387a9b11.js"
  ],
  "/parent/referrals/[id]/onboarding/review": [
    "static/chunks/d83567d1a9284433.js"
  ],
  "/parent/referrals/[id]/onboarding/scheduling": [
    "static/chunks/854ceb2723bf5567.js"
  ],
  "/parent/referrals/[id]/onboarding/screener": [
    "static/chunks/bc2a1ba194c761d0.js"
  ],
  "/parent/resources": [
    "static/chunks/7c16a664275caacd.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error",
    "/admin/chats",
    "/admin/chats/[id]",
    "/admin/login",
    "/admin/referrals",
    "/admin/referrals/[id]",
    "/admin/resources",
    "/admin/resources/new",
    "/admin/resources/[id]",
    "/api/hello",
    "/auth/login",
    "/auth/signup",
    "/parent/dashboard",
    "/parent/notifications",
    "/parent/referrals/[id]",
    "/parent/referrals/[id]/details",
    "/parent/referrals/[id]/onboarding/child-info",
    "/parent/referrals/[id]/onboarding/consent",
    "/parent/referrals/[id]/onboarding/cost",
    "/parent/referrals/[id]/onboarding/insurance",
    "/parent/referrals/[id]/onboarding/intake",
    "/parent/referrals/[id]/onboarding/parent-info",
    "/parent/referrals/[id]/onboarding/review",
    "/parent/referrals/[id]/onboarding/scheduling",
    "/parent/referrals/[id]/onboarding/screener",
    "/parent/referrals/[id]/onboarding/[step]",
    "/parent/resources"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()